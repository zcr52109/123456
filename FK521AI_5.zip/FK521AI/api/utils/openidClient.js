let openIdClientPromise;
let openIdPassportPromise;

async function loadOpenIdClient() {
  if (!openIdClientPromise) {
    openIdClientPromise = import('openid-client');
  }

  const module = await openIdClientPromise;
  return module.default ?? module;
}

async function loadOpenIdPassport() {
  if (!openIdPassportPromise) {
    openIdPassportPromise = import('openid-client/passport');
  }

  const module = await openIdPassportPromise;
  return module.default ?? module;
}

async function getOpenIdPassportStrategy() {
  const module = await loadOpenIdPassport();
  return module.Strategy ?? module.default?.Strategy;
}

module.exports = {
  loadOpenIdClient,
  loadOpenIdPassport,
  getOpenIdPassportStrategy,
};
