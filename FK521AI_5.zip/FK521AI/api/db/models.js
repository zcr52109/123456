const mongoose = require('mongoose');
const { createModels } = require('@fk521ai/data-schemas');
const models = createModels(mongoose);

module.exports = { ...models };
