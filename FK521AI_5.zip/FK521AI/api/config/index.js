const { EventSource } = require('eventsource');
const { Time } = require('fk521ai-data-provider');
const {
  MCPManager,
  FlowStateManager,
  MCPServersRegistry,
  OAuthReconnectionManager,
} = require('@fk521ai/api');
const logger = require('./winston');

global.EventSource = EventSource;

/** @type {MCPManager} */
let flowManager = null;

/**
 * @param {Keyv} flowsCache
 * @returns {FlowStateManager}
 */
function getFlowStateManager(flowsCache) {
  if (!flowManager) {
    flowManager = new FlowStateManager(flowsCache, {
      ttl: Time.ONE_MINUTE * 3,
    });
  }
  return flowManager;
}

function getSafeSingleton(getter, label) {
  try {
    return getter();
  } catch (error) {
    if (error instanceof Error && error.message.includes('has not been initialized')) {
      logger.warn(`[${label}] disabled or not initialized; returning null.`);
      return null;
    }
    throw error;
  }
}

module.exports = {
  logger,
  createMCPServersRegistry: MCPServersRegistry.createInstance,
  getMCPServersRegistry: () => getSafeSingleton(MCPServersRegistry.getInstance, 'MCPServersRegistry'),
  createMCPManager: MCPManager.createInstance,
  getMCPManager: () => getSafeSingleton(MCPManager.getInstance, 'MCPManager'),
  getFlowStateManager,
  createOAuthReconnectionManager: OAuthReconnectionManager.createInstance,
  getOAuthReconnectionManager: () =>
    getSafeSingleton(OAuthReconnectionManager.getInstance, 'OAuthReconnectionManager'),
};
