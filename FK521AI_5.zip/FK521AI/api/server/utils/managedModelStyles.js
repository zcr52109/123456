const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..', '..', '..');
const defaultConfigPath = path.resolve(projectRoot, 'runtime', 'admin', 'managed-model-styles.json');
const defaultStyleFilesDir = path.resolve(projectRoot, 'runtime', 'admin', 'style-files');

let cachedMtimeMs = null;
let cachedValue = null;

function getManagedModelStylesPath() {
  return process.env.FK521_MANAGED_MODEL_STYLES_PATH || defaultConfigPath;
}

function getManagedModelStyleFilesDir() {
  return process.env.FK521_MANAGED_MODEL_STYLE_FILES_DIR || defaultStyleFilesDir;
}

function ensureStorageFile() {
  const filePath = getManagedModelStylesPath();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, '[]\n', 'utf8');
  }
  return filePath;
}

function ensureStyleFilesDir() {
  const dir = getManagedModelStyleFilesDir();
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function slugify(value = '') {
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
}

function uniqueId(base, used) {
  let candidate = base || `style-${Date.now()}`;
  let index = 2;
  while (used.has(candidate)) {
    candidate = `${base}-${index}`;
    index += 1;
  }
  used.add(candidate);
  return candidate;
}

function sanitizeContent(value) {
  return String(value || '').replace(/\r\n/g, '\n').trim();
}

async function writeFileAtomic(filePath, content) {
  const dir = path.dirname(filePath);
  await fsp.mkdir(dir, { recursive: true });
  const tempPath = path.join(
    dir,
    `.${path.basename(filePath)}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`,
  );
  await fsp.writeFile(tempPath, content, 'utf8');
  await fsp.rename(tempPath, filePath);
}

async function safeReadFile(filePath) {
  try {
    return await fsp.readFile(filePath, 'utf8');
  } catch (_error) {
    return '';
  }
}

async function safeUnlink(filePath) {
  if (!filePath) {
    return;
  }
  await fsp.rm(filePath, { force: true }).catch(() => undefined);
}

function resolveStoredFilePath(storage = {}) {
  if (storage.absolutePath) {
    return path.resolve(String(storage.absolutePath));
  }
  if (storage.relativePath) {
    return path.resolve(getManagedModelStyleFilesDir(), String(storage.relativePath));
  }
  if (storage.fileName) {
    return path.resolve(getManagedModelStyleFilesDir(), String(storage.fileName));
  }
  return null;
}

async function persistStyleFile(item = {}) {
  const filesDir = ensureStyleFilesDir();
  const safeId = slugify(item.id || item.name || 'style') || `style-${Date.now()}`;
  const safeName = slugify(item.name || item.id || 'style') || safeId;
  const fileName = `${safeId}-${safeName}.txt`.slice(0, 120);
  const absolutePath = path.join(filesDir, fileName);
  const content = sanitizeContent(item.content);

  await writeFileAtomic(absolutePath, `${content}\n`);
  const stat = await fsp.stat(absolutePath);

  return {
    kind: 'local',
    fileName,
    relativePath: fileName,
    absolutePath,
    bytes: stat.size,
    contentSha1: require('crypto').createHash('sha1').update(content).digest('hex'),
  };
}

async function hydrateStyle(item = {}) {
  const hydrated = { ...item };
  const content = sanitizeContent(item.content);
  if (content) {
    hydrated.content = content;
    return hydrated;
  }

  const storedPath = resolveStoredFilePath(item.storage || {});
  if (!storedPath) {
    hydrated.content = '';
    return hydrated;
  }

  hydrated.content = sanitizeContent(await safeReadFile(storedPath));
  hydrated.storage = {
    ...(item.storage || {}),
    absolutePath: storedPath,
  };
  return hydrated;
}

function normalizeManagedModelStyle(item = {}, used = new Set()) {
  const idBase = slugify(item.id || item.name || 'style');
  const content = sanitizeContent(item.content);
  return {
    id: uniqueId(idBase, used),
    name: String(item.name || '未命名风格').trim() || '未命名风格',
    category: String(item.category || 'general').trim() || 'general',
    description: String(item.description || '').trim(),
    content,
    storage: item.storage && typeof item.storage === 'object' ? { ...item.storage } : undefined,
    enabled: item.enabled !== false,
    createdAt: item.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

function normalizeManagedModelStyles(items = []) {
  const used = new Set();
  return items
    .filter((item) => item && typeof item === 'object')
    .map((item) => normalizeManagedModelStyle(item, used));
}

function readManagedModelStyles() {
  try {
    const filePath = ensureStorageFile();
    const stats = fs.statSync(filePath);
    if (cachedValue && cachedMtimeMs === stats.mtimeMs) {
      return cachedValue;
    }
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    cachedValue = Array.isArray(parsed)
      ? parsed.map((item) => {
          const content = sanitizeContent(item.content);
          const storage = item.storage && typeof item.storage === 'object' ? { ...item.storage } : undefined;
          const resolvedPath = resolveStoredFilePath(storage || {});
          return {
            ...item,
            content: content || (resolvedPath && fs.existsSync(resolvedPath) ? sanitizeContent(fs.readFileSync(resolvedPath, 'utf8')) : ''),
            storage: storage
              ? {
                  ...storage,
                  absolutePath: resolvedPath || storage.absolutePath,
                }
              : undefined,
          };
        })
      : [];
    cachedMtimeMs = stats.mtimeMs;
    return cachedValue;
  } catch (_error) {
    cachedValue = [];
    cachedMtimeMs = null;
    return [];
  }
}

async function writeManagedModelStyles(items = []) {
  const normalized = normalizeManagedModelStyles(items);
  const previous = readManagedModelStyles();
  const previousStorageById = new Map(previous.map((item) => [item.id, item.storage]));

  const persisted = [];
  for (const item of normalized) {
    const storage = await persistStyleFile(item);
    persisted.push({
      ...item,
      storage,
      content: item.content,
    });
  }

  const nextIds = new Set(persisted.map((item) => item.id));
  const staleFiles = previous
    .filter((item) => !nextIds.has(item.id))
    .map((item) => resolveStoredFilePath(previousStorageById.get(item.id) || item.storage || {}))
    .filter(Boolean);

  const filePath = ensureStorageFile();
  const toWrite = persisted.map((item) => ({
    ...item,
    storage: item.storage
      ? {
          ...item.storage,
          absolutePath: undefined,
        }
      : undefined,
  }));

  fs.writeFileSync(filePath, `${JSON.stringify(toWrite, null, 2)}\n`, 'utf8');
  cachedValue = persisted;
  cachedMtimeMs = fs.statSync(filePath).mtimeMs;

  await Promise.all(staleFiles.map((file) => safeUnlink(file)));
  return persisted;
}

async function upsertManagedModelStyle(item = {}) {
  const current = readManagedModelStyles();
  const filtered = current.filter((entry) => entry.id !== item.id);
  return await writeManagedModelStyles([...filtered, item]);
}

async function removeManagedModelStyle(id) {
  const current = readManagedModelStyles();
  const target = current.find((entry) => entry.id === id);
  const next = current.filter((entry) => entry.id !== id);
  await writeManagedModelStyles(next);
  await safeUnlink(resolveStoredFilePath(target?.storage || {}));
  return next;
}

function getStyleText(styleIds = []) {
  if (!Array.isArray(styleIds) || styleIds.length === 0) {
    return '';
  }
  const stylesById = new Map(readManagedModelStyles().map((style) => [style.id, style]));
  return styleIds
    .map((id) => stylesById.get(id))
    .filter((style) => style?.enabled !== false && style?.content)
    .map((style) => `【${style.name}】\n${style.content}`)
    .join('\n\n');
}

module.exports = {
  getManagedModelStylesPath,
  getManagedModelStyleFilesDir,
  readManagedModelStyles,
  writeManagedModelStyles,
  upsertManagedModelStyle,
  removeManagedModelStyle,
  normalizeManagedModelStyles,
  getStyleText,
  hydrateStyle,
  resolveStoredFilePath,
};
