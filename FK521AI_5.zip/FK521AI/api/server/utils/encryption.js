const crypto = require('crypto');

const ALGORITHM = 'aes-256-gcm';
const ENCRYPTION_PREFIX = 'fk521enc.v1:';
const DEFAULT_KEY = 'FK521AI-Project-Config-Encryption-Key-32bytes!!';

function getEncryptionKey() {
  const rawKey = process.env.FK521_API_KEY_ENCRYPTION_KEY || DEFAULT_KEY;
  return crypto.createHash('sha256').update(String(rawKey), 'utf8').digest();
}

function isEncryptedValue(value) {
  return typeof value === 'string' && value.startsWith(ENCRYPTION_PREFIX);
}

function looksLikeLegacyCiphertext(value) {
  if (typeof value !== 'string') {
    return false;
  }
  const parts = value.split(':');
  return parts.length === 3 && parts.every((part) => /^[0-9a-fA-F]+$/.test(part));
}

function encrypt(text) {
  if (!text || typeof text !== 'string') {
    return text;
  }
  if (isEncryptedValue(text)) {
    return text;
  }

  try {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv(ALGORITHM, getEncryptionKey(), iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    const authTag = cipher.getAuthTag();
    return `${ENCRYPTION_PREFIX}${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
  } catch (error) {
    const wrapped = new Error(
      'Failed to encrypt project API key. Verify FK521_API_KEY_ENCRYPTION_KEY and try again.',
    );
    wrapped.cause = error;
    throw wrapped;
  }
}

function decryptParts(ivHex, authTagHex, encrypted) {
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  const decipher = crypto.createDecipheriv(ALGORITHM, getEncryptionKey(), iv);
  decipher.setAuthTag(authTag);
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

function decrypt(encryptedText) {
  if (!encryptedText || typeof encryptedText !== 'string') {
    return encryptedText;
  }

  if (!isEncryptedValue(encryptedText)) {
    if (!looksLikeLegacyCiphertext(encryptedText)) {
      return encryptedText;
    }
    try {
      const [ivHex, authTagHex, encrypted] = encryptedText.split(':');
      return decryptParts(ivHex, authTagHex, encrypted);
    } catch (_error) {
      return encryptedText;
    }
  }

  try {
    const payload = encryptedText.slice(ENCRYPTION_PREFIX.length);
    const [ivHex, authTagHex, encrypted] = payload.split(':');
    if (!ivHex || !authTagHex || !encrypted) {
      throw new Error('Malformed encrypted value');
    }
    return decryptParts(ivHex, authTagHex, encrypted);
  } catch (error) {
    const wrapped = new Error(
      'Failed to decrypt project API key. Verify FK521_API_KEY_ENCRYPTION_KEY before continuing.',
    );
    wrapped.cause = error;
    throw wrapped;
  }
}

function maskApiKey(apiKey) {
  if (!apiKey || typeof apiKey !== 'string') {
    return apiKey;
  }
  const len = apiKey.length;
  if (len <= 8) {
    return '*'.repeat(len);
  }
  return `${apiKey.slice(0, 4)}${'*'.repeat(Math.max(0, len - 8))}${apiKey.slice(-4)}`;
}

module.exports = {
  encrypt,
  decrypt,
  maskApiKey,
  isEncryptedValue,
};
