const path = require('path');
const XLSX = require('xlsx');
const {
  normalizeProjectApis,
  normalizeProvider,
  normalizeAliasList,
  resolveProviderBaseURL,
} = require('./projectApiConfig');

function normalizeHeader(value = '') {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[\s_\-（）()]+/g, '');
}

const FIELD_MAP = Object.freeze({
  name: 'name',
  模型名称: 'name',
  模型名: 'name',
  model: 'name',
  modelname: 'name',
  label: 'label',
  展示名称: 'label',
  displayname: 'label',
  provider: 'provider',
  供应商: 'provider',
  提供商: 'provider',
  平台: 'provider',
  vendor: 'provider',
  version: 'version',
  版本: 'version',
  aliases: 'aliases',
  alias: 'aliases',
  别名: 'aliases',
  变体: 'aliases',
  variants: 'aliases',
  baserurl: 'baseURL',
  baseurl: 'baseURL',
  endpoint: 'baseURL',
  接口地址: 'baseURL',
  apiurl: 'baseURL',
  apikey: 'apiKey',
  key: 'apiKey',
  密钥: 'apiKey',
  enabled: 'enabled',
  启用: 'enabled',
  avatar: 'avatarURL',
  avatarurl: 'avatarURL',
  icon: 'avatarURL',
  iconurl: 'avatarURL',
  description: 'description',
  描述: 'description',
});

function parseBoolean(value, fallback = true) {
  if (value === undefined || value === null || String(value).trim() === '') {
    return fallback;
  }
  const normalized = String(value).trim().toLowerCase();
  if (['1', 'true', 'yes', 'y', 'on', 'enabled', '启用', '是'].includes(normalized)) {
    return true;
  }
  if (['0', 'false', 'no', 'n', 'off', 'disabled', '禁用', '否'].includes(normalized)) {
    return false;
  }
  return fallback;
}

function mapRowKeys(row = {}) {
  const mapped = {};
  for (const [rawKey, value] of Object.entries(row || {})) {
    const normalizedKey = normalizeHeader(rawKey);
    const targetKey = FIELD_MAP[normalizedKey] || FIELD_MAP[String(rawKey).trim()] || rawKey;
    mapped[targetKey] = value;
  }
  return mapped;
}

function toRowsFromWorkbook(buffer) {
  const workbook = XLSX.read(buffer, { type: 'buffer' });
  const rows = [];
  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) {
      continue;
    }
    const jsonRows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    for (const row of jsonRows) {
      rows.push(mapRowKeys(row));
    }
  }
  return rows;
}

function toRowsFromText(content = '') {
  const trimmed = String(content || '').trim();
  if (!trimmed) {
    return [];
  }

  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        return parsed.map((row) => mapRowKeys(row));
      }
      if (parsed && typeof parsed === 'object') {
        return [mapRowKeys(parsed)];
      }
    } catch (_error) {
      // fall through
    }
  }

  const lines = trimmed
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length === 0) {
    return [];
  }

  const delimiter = [',', '\t', ';', '|'].find((candidate) => lines[0].includes(candidate));
  if (delimiter) {
    const [headerLine, ...bodyLines] = lines;
    const headers = headerLine.split(delimiter).map((header) => header.trim());
    return bodyLines.map((line) => {
      const columns = line.split(delimiter).map((column) => column.trim());
      const row = {};
      headers.forEach((header, index) => {
        row[header] = columns[index] || '';
      });
      return mapRowKeys(row);
    });
  }

  return lines.map((line) => {
    const parts = line.split(/[|｜]/).map((part) => part.trim()).filter(Boolean);
    return mapRowKeys({
      provider: parts[0] || 'custom',
      name: parts[1] || parts[0] || '',
      version: parts[2] || '',
      aliases: parts.slice(3).join(';'),
    });
  });
}

function parseImportFile({ buffer, filename = '', mimeType = '' }) {
  const ext = path.extname(String(filename || '')).toLowerCase();
  const normalizedMime = String(mimeType || '').toLowerCase();

  if (['.xlsx', '.xls', '.csv'].includes(ext) || normalizedMime.includes('spreadsheet') || normalizedMime.includes('csv')) {
    return toRowsFromWorkbook(buffer);
  }

  return toRowsFromText(buffer.toString('utf8'));
}

function buildImportItem(row = {}, index = 0) {
  const name = String(row.name || row.modelName || row.model || '').trim();
  if (!name) {
    return null;
  }

  const provider = normalizeProvider(row.provider || 'custom');
  const label = String(row.label || row.displayName || name).trim() || name;
  const version = String(row.version || '').trim();
  const enabled = parseBoolean(row.enabled, true);
  const apiKey = String(row.apiKey || '').trim();
  const baseURL = resolveProviderBaseURL(provider, String(row.baseURL || '').trim());
  const avatarURL = String(row.avatarURL || '').trim();
  const description = String(row.description || '').trim();
  const aliases = normalizeAliasList(row.aliases, [name, label]);

  return {
    id: `${provider || 'custom'}-${name}-${version || 'v'}-${index}`
      .toLowerCase()
      .replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '-')
      .replace(/^-+|-+$/g, ''),
    name: label,
    provider,
    enabled,
    description,
    baseURL,
    apiKey,
    models: enabled ? [name] : [],
    modelConfigs: [
      {
        id: `${provider || 'custom'}-${name}-${version || 'model'}-${index}`
          .toLowerCase()
          .replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '-')
          .replace(/^-+|-+$/g, ''),
        name,
        label,
        version,
        aliases,
        provider,
        enabled,
        avatarURL,
        description,
        default: true,
      },
    ],
    defaultModel: name,
  };
}

function mergeImportedProjectApis(existingItems = [], importedRows = []) {
  const baseItems = normalizeProjectApis(existingItems);
  const importedItems = importedRows
    .map((row, index) => buildImportItem(row, index))
    .filter(Boolean);

  const merged = [...baseItems];
  const summary = {
    totalRows: importedRows.length,
    acceptedRows: importedItems.length,
    created: 0,
    updated: 0,
    skipped: importedRows.length - importedItems.length,
  };

  for (const imported of importedItems) {
    const importedModel = imported.modelConfigs?.[0];
    const matchIndex = merged.findIndex((item) => {
      const itemModel = Array.isArray(item.modelConfigs) ? item.modelConfigs[0] : null;
      return (
        normalizeProvider(item.provider || 'custom') === normalizeProvider(imported.provider || 'custom') &&
        String(itemModel?.name || item.defaultModel || '').trim().toLowerCase() === String(importedModel?.name || '').trim().toLowerCase() &&
        String(itemModel?.version || '').trim().toLowerCase() === String(importedModel?.version || '').trim().toLowerCase()
      );
    });

    if (matchIndex === -1) {
      merged.push(imported);
      summary.created += 1;
      continue;
    }

    const current = merged[matchIndex];
    const currentModel = Array.isArray(current.modelConfigs) && current.modelConfigs[0] ? current.modelConfigs[0] : {};
    const nextAliases = normalizeAliasList(
      [...(currentModel.aliases || []), ...(importedModel.aliases || [])],
      [importedModel.name, importedModel.label, currentModel.name, currentModel.label],
    );

    merged[matchIndex] = {
      ...current,
      name: imported.name || current.name,
      provider: imported.provider || current.provider,
      description: imported.description || current.description,
      baseURL: imported.baseURL || current.baseURL,
      apiKey: imported.apiKey || current.apiKey,
      enabled: current.enabled === true || imported.enabled === true,
      models: imported.enabled ? [importedModel.name] : current.models,
      defaultModel: importedModel.name || current.defaultModel,
      modelConfigs: [
        {
          ...currentModel,
          ...importedModel,
          id: currentModel.id || importedModel.id,
          aliases: nextAliases,
          enabled: current.enabled === true || imported.enabled === true,
          avatarURL: importedModel.avatarURL || currentModel.avatarURL,
          styleFileIds: Array.from(new Set([...(currentModel.styleFileIds || []), ...(importedModel.styleFileIds || [])])),
          default: true,
        },
      ],
    };
    summary.updated += 1;
  }

  return {
    items: normalizeProjectApis(merged),
    summary,
  };
}

module.exports = {
  parseImportFile,
  mergeImportedProjectApis,
};
