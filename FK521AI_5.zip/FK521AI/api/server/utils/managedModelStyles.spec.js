const fs = require('fs');
const os = require('os');
const path = require('path');

describe('managedModelStyles persistence', () => {
  let tempDir;
  let configPath;
  let styleFilesDir;
  let managedModelStyles;

  beforeEach(() => {
    jest.resetModules();
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fk521-style-'));
    configPath = path.join(tempDir, 'managed-model-styles.json');
    styleFilesDir = path.join(tempDir, 'style-files');
    process.env.FK521_MANAGED_MODEL_STYLES_PATH = configPath;
    process.env.FK521_MANAGED_MODEL_STYLE_FILES_DIR = styleFilesDir;
    managedModelStyles = require('./managedModelStyles');
  });

  afterEach(() => {
    delete process.env.FK521_MANAGED_MODEL_STYLES_PATH;
    delete process.env.FK521_MANAGED_MODEL_STYLE_FILES_DIR;
    fs.rmSync(tempDir, { recursive: true, force: true });
  });

  it('writes uploaded style content to a real txt file and removes it on delete', async () => {
    const styles = await managedModelStyles.upsertManagedModelStyle({
      id: 'style-1',
      name: '示例风格',
      content: 'hello world',
      enabled: true,
    });

    expect(styles).toHaveLength(1);
    const stored = styles[0];
    const storedPath = managedModelStyles.resolveStoredFilePath(stored.storage);
    expect(storedPath).toBeTruthy();
    expect(fs.existsSync(storedPath)).toBe(true);
    expect(fs.readFileSync(storedPath, 'utf8')).toContain('hello world');

    await managedModelStyles.removeManagedModelStyle('style-1');
    expect(fs.existsSync(storedPath)).toBe(false);
  });
});
