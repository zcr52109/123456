const DEFAULT_PORT = Number(process.env.PORT) || 3080;
const DEFAULT_HOST = process.env.HOST || 'localhost';

function stripTrailingSlash(value = '') {
  return String(value || '').trim().replace(/\/$/, '');
}

function safeConfiguredUrl(value = '') {
  const raw = String(value || '').trim();
  if (!raw) {
    return '';
  }

  try {
    const parsed = new URL(raw);
    const pathname = parsed.pathname === '/' ? '' : parsed.pathname.replace(/\/$/, '');
    return stripTrailingSlash(`${parsed.origin}${pathname}`);
  } catch (_error) {
    return stripTrailingSlash(raw);
  }
}

function getRequestBaseUrl(req) {
  const configuredServer = safeConfiguredUrl(process.env.DOMAIN_SERVER);
  if (configuredServer) {
    return configuredServer;
  }

  const configuredClient = safeConfiguredUrl(process.env.DOMAIN_CLIENT);
  if (configuredClient) {
    return configuredClient;
  }

  const forwardedProto = String(req?.headers?.['x-forwarded-proto'] || '')
    .split(',')[0]
    .trim();
  const forwardedHost = String(req?.headers?.['x-forwarded-host'] || '')
    .split(',')[0]
    .trim();
  const host = forwardedHost || String(req?.headers?.host || '').trim();
  const protocol = forwardedProto || req?.protocol || 'http';

  if (host) {
    return stripTrailingSlash(`${protocol}://${host}`);
  }

  return stripTrailingSlash(`http://${DEFAULT_HOST}:${DEFAULT_PORT}`);
}

module.exports = {
  getRequestBaseUrl,
};
