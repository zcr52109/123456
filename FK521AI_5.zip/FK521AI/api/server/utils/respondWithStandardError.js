function defaultMessageForStatus(status) {
  if (status === 400) {
    return 'Bad Request';
  }
  if (status === 401) {
    return 'Authentication required';
  }
  if (status === 403) {
    return 'Forbidden';
  }
  if (status === 404) {
    return 'Not Found';
  }
  if (status === 409) {
    return 'Conflict';
  }
  if (status >= 500) {
    return 'Internal Server Error';
  }
  return 'Request failed';
}

function defaultCodeForStatus(status) {
  if (status === 400) {
    return 'BAD_REQUEST';
  }
  if (status === 401) {
    return 'AUTHENTICATION_REQUIRED';
  }
  if (status === 403) {
    return 'FORBIDDEN';
  }
  if (status === 404) {
    return 'NOT_FOUND';
  }
  if (status === 409) {
    return 'CONFLICT';
  }
  if (status >= 500) {
    return 'INTERNAL_SERVER_ERROR';
  }
  return 'REQUEST_FAILED';
}

function respondWithStandardError(res, status, options = {}) {
  const message = options.message || defaultMessageForStatus(status);
  const error = options.error || message;
  const error_code = options.error_code || defaultCodeForStatus(status);

  const payload = {
    status,
    error,
    message,
    error_code,
  };

  if (options.reason !== undefined) {
    payload.reason = options.reason;
  }

  if (options.decision_id !== undefined) {
    payload.decision_id = options.decision_id;
  }

  if (options.policy_version !== undefined) {
    payload.policy_version = options.policy_version;
  }

  if (options.remediation !== undefined) {
    payload.remediation = options.remediation;
  }

  if (options.details !== undefined) {
    payload.details = options.details;
  }

  return res.status(status).json(payload);
}


function respondWithInternalError(res, message = 'Internal Server Error', error_code = 'INTERNAL_SERVER_ERROR', details) {
  return respondWithStandardError(res, 500, { message, error_code, details });
}

module.exports = {
  respondWithStandardError,
  respondWithInternalError,
  defaultMessageForStatus,
  defaultCodeForStatus,
};
