const fs = require('fs');
const path = require('path');
const { isEnabled } = require('@fk521ai/api');

const projectRoot = path.resolve(__dirname, '..', '..', '..');
const defaultConfigPath = path.resolve(projectRoot, 'runtime', 'admin', 'system-settings.json');

let cachedMtimeMs = null;
let cachedValue = null;


function getSystemSettingsPath() {
  return process.env.FK521_SYSTEM_SETTINGS_PATH || defaultConfigPath;
}

function ensureStorageFile() {
  const configPath = getSystemSettingsPath();
  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  if (!fs.existsSync(configPath)) {
    fs.writeFileSync(configPath, '{}\n', 'utf8');
  }
  return configPath;
}

function readSystemSettingsRaw() {
  try {
    const filePath = ensureStorageFile();
    const stats = fs.statSync(filePath);
    if (cachedValue && cachedMtimeMs === stats.mtimeMs) {
      return cachedValue;
    }
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    cachedValue = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    cachedMtimeMs = stats.mtimeMs;
    return cachedValue;
  } catch (error) {
    cachedValue = {};
    cachedMtimeMs = null;
    return {};
  }
}

function toInt(value, fallback) {
  const parsed = Number.parseInt(String(value ?? ''), 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function normalizeSystemSettings(input = {}) {
  const auth = input.auth && typeof input.auth === 'object' ? input.auth : {};
  const email = input.email && typeof input.email === 'object' ? input.email : {};
  const ui = input.ui && typeof input.ui === 'object' ? input.ui : {};

  const emailLoginEnabled =
    auth.allowEmailLogin !== undefined
      ? auth.allowEmailLogin === true
      : process.env.ALLOW_EMAIL_LOGIN === undefined || isEnabled(process.env.ALLOW_EMAIL_LOGIN);

  return {
    auth: {
      allowRegistration:
        auth.allowRegistration !== undefined
          ? auth.allowRegistration === true
          : isEnabled(process.env.ALLOW_REGISTRATION),
      allowEmailLogin: emailLoginEnabled,
      allowPasswordReset:
        auth.allowPasswordReset !== undefined
          ? auth.allowPasswordReset === true
          : isEnabled(process.env.ALLOW_PASSWORD_RESET),
      allowSocialLogin: false,
      minPasswordLength: Math.max(6, Math.min(128, toInt(auth.minPasswordLength, toInt(process.env.MIN_PASSWORD_LENGTH, 8)))),
    },
    email: {
      provider: String(email.provider || 'smtp').trim().toLowerCase() || 'smtp',
      fromName: String(email.fromName || process.env.EMAIL_FROM_NAME || process.env.APP_TITLE || 'FK521AI').trim(),
      fromEmail: String(email.fromEmail || process.env.EMAIL_FROM || '').trim(),
      service: String(email.service || process.env.EMAIL_SERVICE || '').trim(),
      host: String(email.host || process.env.EMAIL_HOST || '').trim(),
      port: Math.max(1, Math.min(65535, toInt(email.port, toInt(process.env.EMAIL_PORT, 25)))),
      encryption: String(email.encryption || process.env.EMAIL_ENCRYPTION || 'none').trim().toLowerCase(),
      username: String(email.username || process.env.EMAIL_USERNAME || '').trim(),
      password: String(email.password || process.env.EMAIL_PASSWORD || '').trim(),
      allowSelfSigned:
        email.allowSelfSigned !== undefined
          ? email.allowSelfSigned === true
          : isEnabled(process.env.EMAIL_ALLOW_SELFSIGNED),
      encryptionHostname: String(
        email.encryptionHostname || process.env.EMAIL_ENCRYPTION_HOSTNAME || '',
      ).trim(),
    },
    ui: {
      sidebarWidth: Math.max(220, Math.min(420, toInt(ui.sidebarWidth, 260))),
      showModelSelector: ui.showModelSelector === true,
      showMultiConvoButton: false,
      showThinkingByDefault: ui.showThinkingByDefault === true,
    },
    updatedAt: new Date().toISOString(),
  };
}

function readSystemSettings() {
  return normalizeSystemSettings(readSystemSettingsRaw());
}

function writeSystemSettings(input = {}) {
  const normalized = normalizeSystemSettings(input);
  const filePath = ensureStorageFile();
  fs.writeFileSync(filePath, `${JSON.stringify(normalized, null, 2)}\n`, 'utf8');
  cachedValue = normalized;
  cachedMtimeMs = fs.statSync(filePath).mtimeMs;
  return normalized;
}

function hasEmailConfig(settings = readSystemSettings()) {
  const email = settings.email || {};

  const hasMailgunConfig =
    !!process.env.MAILGUN_API_KEY && !!process.env.MAILGUN_DOMAIN && !!email.fromEmail;

  const hasSMTPConfig = (!!email.service || !!email.host) && !!email.fromEmail;

  if (!hasMailgunConfig && !hasSMTPConfig) {
    return false;
  }

  const hasUsername = !!email.username;
  const hasPassword = !!email.password;
  if (hasUsername !== hasPassword) {
    return false;
  }

  return true;
}

function getStartupAdminUI(settings = readSystemSettings()) {
  return {
    sidebarWidth: settings.ui?.sidebarWidth,
    showModelSelector: settings.ui?.showModelSelector,
    showMultiConvoButton: settings.ui?.showMultiConvoButton,
    showThinkingByDefault: settings.ui?.showThinkingByDefault,
  };
}

module.exports = {
  getSystemSettingsPath,
  readSystemSettings,
  writeSystemSettings,
  normalizeSystemSettings,
  hasEmailConfig,
  getStartupAdminUI,
};
