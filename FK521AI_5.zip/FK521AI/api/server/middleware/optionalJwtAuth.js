const cookies = require('cookie');
const passport = require('passport');
const { isEnabled, tenantContextMiddleware } = require('@fk521ai/api');
const { getUserFromCookies } = require('./authFromCookies');

const hasBearerToken = (req) => /^Bearer\s+/i.test(req.headers?.authorization || '');

const shouldFallbackToAlternateStrategy = (error) => {
  if (!error) {
    return true;
  }

  const message = String(error.message || '').toLowerCase();
  const name = String(error.name || '').toLowerCase();

  return (
    name.includes('jwt') ||
    name.includes('token') ||
    message.includes('jwt') ||
    message.includes('token') ||
    message.includes('unknown authentication strategy')
  );
};

const authenticateWithStrategy = (strategy, req, res, next) =>
  new Promise((resolve) => {
    passport.authenticate(strategy, { session: false }, (err, user) => {
      resolve({ err, user, strategy });
    })(req, res, next);
  });

const getStrategies = (req) => {
  const cookieHeader = req.headers.cookie;
  const tokenProvider = cookieHeader ? cookies.parse(cookieHeader).token_provider : null;
  const openIdEnabled = isEnabled(process.env.OPENID_REUSE_TOKENS);

  const preferredStrategy =
    tokenProvider === 'openid' && openIdEnabled ? 'openidJwt' : 'jwt';

  const alternateStrategy =
    preferredStrategy === 'openidJwt' ? 'jwt' : openIdEnabled ? 'openidJwt' : null;

  return { preferredStrategy, alternateStrategy };
};

// This middleware does not require authentication,
// but if the user is authenticated, it will set the user object
// and establish tenant ALS context.
const optionalJwtAuth = (req, res, next) => {
  const handleAuthentication = async () => {
    const { preferredStrategy, alternateStrategy } = getStrategies(req);
    let authResult = await authenticateWithStrategy(preferredStrategy, req, res, next);

    if (
      !authResult.user &&
      alternateStrategy &&
      hasBearerToken(req) &&
      shouldFallbackToAlternateStrategy(authResult.err)
    ) {
      const alternateResult = await authenticateWithStrategy(alternateStrategy, req, res, next);
      if (alternateResult.user || alternateResult.err || !authResult.err) {
        authResult = alternateResult;
      }
    }

    if (authResult.err) {
      return next(authResult.err);
    }
    if (authResult.user) {
      req.user = authResult.user;
      return tenantContextMiddleware(req, res, next);
    }
    try {
      const cookieUser = await getUserFromCookies(req);
      if (cookieUser) {
        req.user = cookieUser;
        return tenantContextMiddleware(req, res, next);
      }
    } catch (cookieError) {
      return next(cookieError);
    }
    next();
  };

  handleAuthentication().catch(next);
};

module.exports = optionalJwtAuth;
