const { logger } = require('@fk521ai/data-schemas');
const { readSystemSettings } = require('~/server/utils/adminSystemConfig');

function validatePasswordReset(req, res, next) {
  const settings = readSystemSettings();
  if (settings.auth.allowPasswordReset) {
    next();
  } else {
    logger.warn(`Password reset attempt while not allowed. IP: ${req.ip}`);
    res.status(403).send('Password reset is not allowed.');
  }
}

module.exports = validatePasswordReset;
