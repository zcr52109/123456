const { readSystemSettings } = require('~/server/utils/adminSystemConfig');

function validateRegistration(req, res, next) {
  if (req.invite) {
    return next();
  }

  const settings = readSystemSettings();
  const allowRegistration = settings?.auth?.allowRegistration !== false;

  if (allowRegistration) {
    return next();
  }

  return res.status(403).json({
    message: 'Registration is not allowed.',
  });
}

module.exports = validateRegistration;
