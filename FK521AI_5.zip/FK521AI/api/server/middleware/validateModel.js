const { handleError } = require('@fk521ai/api');
const { ViolationTypes } = require('fk521ai-data-provider');
const { getModelsConfig } = require('~/server/controllers/ModelController');
const { getEndpointsConfig } = require('~/server/services/Config');
const { logViolation } = require('~/cache');
const { getPlatformAssistantName } = require('~/server/services/Platform/identity');
const {
  findProjectApiByName,
  findManagedModelConfig,
} = require('~/server/utils/projectApiConfig');

const MAX_MODEL_STRING_LENGTH = 256;
const MODEL_PATTERN = /^[a-zA-Z0-9][a-zA-Z0-9_.:/@+-]*$/;

function normalizeModelKey(value = '') {
  return String(value || '').trim().toLowerCase();
}

function applyResolvedModel(req, resolvedModel, fallbackModel) {
  if (resolvedModel?.name) {
    req.body.model = resolvedModel.name;

    if (resolvedModel.label) {
      req.body.modelLabel = resolvedModel.label;
    }

    if (resolvedModel.version) {
      req.body.modelVersion = resolvedModel.version;
    }
  }

  if (fallbackModel?.name && !String(req.body.fallbackModel || '').trim()) {
    req.body.fallbackModel = fallbackModel.name;
  }
}

function resolveAvailableModel(availableModels = [], requestedModel = '') {
  const normalizedRequested = normalizeModelKey(requestedModel);
  if (!normalizedRequested || !Array.isArray(availableModels)) {
    return null;
  }

  return (
    availableModels.find((model) => normalizeModelKey(model) === normalizedRequested) ?? null
  );
}

/**
 * Validates the model of the request.
 *
 * @async
 * @param {ServerRequest} req - The Express request object.
 * @param {Express.Response} res - The Express response object.
 * @param {Function} next - The Express next function.
 */
const validateModel = async (req, res, next) => {
  const { endpoint } = req.body;
  const rawModel = req.body.model;

  if (!rawModel || typeof rawModel !== 'string') {
    return handleError(res, { text: 'Model not provided' });
  }

  const model = rawModel.trim();
  if (!model || model.length > MAX_MODEL_STRING_LENGTH || !MODEL_PATTERN.test(model)) {
    return handleError(res, { text: 'Invalid model identifier' });
  }

  req.body.model = model;

  const endpointsConfig = await getEndpointsConfig(req);
  const endpointConfig = endpointsConfig?.[endpoint];
  const userFacingModelLabel =
    String(req.body?.modelLabel || req.body?.endpointOption?.modelLabel || '').trim() ||
    String(endpointConfig?.modelDisplayLabel || '').trim() ||
    getPlatformAssistantName();
  const userFacingModelVersion =
    String(req.body?.modelVersion || req.body?.endpointOption?.modelVersion || '').trim() ||
    String(endpointConfig?.modelVersion || '').trim() ||
    '';

  if (!req.body.modelLabel) {
    req.body.modelLabel = userFacingModelLabel;
  }

  if (req.body.endpointOption && !req.body.endpointOption.modelLabel) {
    req.body.endpointOption.modelLabel = userFacingModelLabel;
  }

  if (userFacingModelVersion) {
    if (!req.body.modelVersion) {
      req.body.modelVersion = userFacingModelVersion;
    }

    if (req.body.endpointOption && !req.body.endpointOption.modelVersion) {
      req.body.endpointOption.modelVersion = userFacingModelVersion;
    }
  }

  if (endpointConfig?.userProvide) {
    return next();
  }

  const managedEndpoint = findProjectApiByName(endpoint);
  if (managedEndpoint) {
    const resolvedModel = findManagedModelConfig(managedEndpoint, model);
    const fallbackModel = findManagedModelConfig(managedEndpoint, '');
    applyResolvedModel(req, resolvedModel, fallbackModel);
    return next();
  }

  const modelsConfig = await getModelsConfig(req);

  if (!modelsConfig) {
    return handleError(res, { text: 'Models not loaded' });
  }

  const availableModels = modelsConfig[endpoint];
  if (!availableModels) {
    return handleError(res, { text: 'Endpoint models not loaded' });
  }

  const resolvedAvailableModel = resolveAvailableModel(availableModels, model);
  if (resolvedAvailableModel) {
    req.body.model = resolvedAvailableModel;
    return next();
  }

  const { ILLEGAL_MODEL_REQ_SCORE: score = 1 } = process.env ?? {};

  const type = ViolationTypes.ILLEGAL_MODEL_REQUEST;
  const errorMessage = {
    type,
  };

  await logViolation(req, res, type, errorMessage, score);
  return handleError(res, { text: 'Illegal model request' });
};

module.exports = validateModel;
