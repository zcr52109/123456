/**
 * Integration test: verifies that requireJwtAuth chains tenantContextMiddleware
 * after successful passport authentication, so ALS tenant context is set for
 * all downstream middleware and route handlers.
 */

const { getTenantId } = require('@fk521ai/data-schemas');

let defaultPassportErrors = {};
let defaultPassportUsers = {};
let passportCalls = [];

jest.mock('passport', () => ({
  authenticate: jest.fn((strategy, _options, callback) => {
    return (req, _res, _next) => {
      passportCalls.push(strategy);

      const err = req._mockPassportErrors?.[strategy] ?? defaultPassportErrors[strategy] ?? null;
      const user = req._mockPassportUsers?.[strategy] ?? defaultPassportUsers[strategy] ?? null;

      callback(err, user);
    };
  }),
}));

jest.mock('@fk521ai/api', () => {
  const { tenantStorage } = require('@fk521ai/data-schemas');
  return {
    isEnabled: jest.fn(() => false),
    tenantContextMiddleware: (req, _res, next) => {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return next();
      }
      return tenantStorage.run({ tenantId }, async () => next());
    },
  };
});

jest.mock('../authFromCookies', () => ({
  getUserFromCookies: jest.fn(async () => null),
}));

jest.mock('~/server/utils/respondWithStandardError', () => ({
  respondWithStandardError: jest.fn((res, status, payload) => res.status(status).json(payload)),
}));

const { isEnabled } = require('@fk521ai/api');
const { getUserFromCookies } = require('../authFromCookies');
const { respondWithStandardError } = require('~/server/utils/respondWithStandardError');
const requireJwtAuth = require('../requireJwtAuth');

function mockReq({ headers = {}, mockPassportUsers, mockPassportErrors } = {}) {
  return {
    headers,
    _mockPassportUsers: mockPassportUsers,
    _mockPassportErrors: mockPassportErrors,
  };
}

function mockRes() {
  return {
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis(),
  };
}

async function invokeMiddleware(req, res = mockRes()) {
  const result = { nextCalled: false, error: undefined, tenantId: undefined };

  requireJwtAuth(req, res, (error) => {
    result.nextCalled = true;
    result.error = error;
    result.tenantId = getTenantId();
  });

  await new Promise((resolve) => setImmediate(resolve));
  return { req, res, ...result };
}

describe('requireJwtAuth tenant context chaining', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    defaultPassportErrors = {};
    defaultPassportUsers = {};
    passportCalls = [];
    isEnabled.mockReturnValue(false);
    getUserFromCookies.mockResolvedValue(null);
  });

  it('forwards passport errors to next() without entering tenant middleware', async () => {
    defaultPassportErrors.jwt = new Error('JWT signature invalid');

    const { nextCalled, error, tenantId } = await invokeMiddleware(mockReq());

    expect(nextCalled).toBe(true);
    expect(error).toBeInstanceOf(Error);
    expect(error.message).toBe('JWT signature invalid');
    expect(tenantId).toBeUndefined();
  });

  it('sets ALS tenant context after preferred jwt authentication succeeds', async () => {
    const { nextCalled, error, tenantId } = await invokeMiddleware(
      mockReq({
        mockPassportUsers: {
          jwt: { tenantId: 'tenant-abc', role: 'user' },
        },
      }),
    );

    expect(nextCalled).toBe(true);
    expect(error).toBeUndefined();
    expect(tenantId).toBe('tenant-abc');
    expect(passportCalls).toEqual(['jwt']);
  });

  it('falls back to jwt strategy when openid cookie is stale but bearer token is a valid app JWT', async () => {
    isEnabled.mockReturnValue(true);

    const { nextCalled, error, tenantId } = await invokeMiddleware(
      mockReq({
        headers: {
          cookie: 'token_provider=openid',
          authorization: 'Bearer local-app-jwt',
        },
        mockPassportUsers: {
          jwt: { tenantId: 'tenant-local', role: 'user' },
        },
      }),
    );

    expect(nextCalled).toBe(true);
    expect(error).toBeUndefined();
    expect(tenantId).toBe('tenant-local');
    expect(passportCalls).toEqual(['openidJwt', 'jwt']);
  });

  it('uses cookie-based fallback when bearer auth does not resolve a user', async () => {
    getUserFromCookies.mockResolvedValue({ tenantId: 'tenant-cookie', role: 'user' });

    const { nextCalled, error, tenantId } = await invokeMiddleware(
      mockReq({
        headers: {
          authorization: 'Bearer invalid-or-missing-user',
        },
      }),
    );

    expect(nextCalled).toBe(true);
    expect(error).toBeUndefined();
    expect(tenantId).toBe('tenant-cookie');
  });

  it('returns 401 when neither bearer auth nor cookie auth resolves a user', async () => {
    const { nextCalled, res } = await invokeMiddleware(
      mockReq({
        headers: {
          authorization: 'Bearer invalid-or-missing-user',
        },
      }),
    );

    expect(nextCalled).toBe(false);
    expect(respondWithStandardError).toHaveBeenCalledWith(
      res,
      401,
      expect.objectContaining({
        message: 'Authentication required',
        error: 'Unauthorized',
        error_code: 'AUTHENTICATION_REQUIRED',
      }),
    );
  });

  it('does not attempt alternate strategy without a bearer token', async () => {
    isEnabled.mockReturnValue(true);

    await invokeMiddleware(
      mockReq({
        headers: { cookie: 'token_provider=openid' },
      }),
    );

    expect(passportCalls).toEqual(['openidJwt']);
  });
});
