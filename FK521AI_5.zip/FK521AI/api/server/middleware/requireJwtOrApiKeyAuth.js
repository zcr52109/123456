const { createRequireApiKeyAuth, tenantContextMiddleware } = require('@fk521ai/api');
const db = require('~/models');
const requireJwtAuth = require('./requireJwtAuth');

const AGENT_API_KEY_PREFIX = 'sk-';

const requireApiKeyAuth = createRequireApiKeyAuth({
  validateAgentApiKey: db.validateAgentApiKey,
  findUser: db.findUser,
});

const getBearerToken = (req) => {
  const authHeader = req.headers?.authorization;
  if (!authHeader || !/^Bearer\s+/i.test(authHeader)) {
    return null;
  }
  return authHeader.replace(/^Bearer\s+/i, '').trim();
};

/**
 * Accepts either a standard JWT/session auth flow or an agent API key.
 *
 * Agent API keys are prefixed with `sk-`, so we can route them to the API key
 * validator without interfering with the existing JWT bearer-token flow.
 */
const requireJwtOrApiKeyAuth = (req, res, next) => {
  const token = getBearerToken(req);

  if (token?.toLowerCase().startsWith(AGENT_API_KEY_PREFIX)) {
    return requireApiKeyAuth(req, res, (error) => {
      if (error) {
        return next(error);
      }
      return tenantContextMiddleware(req, res, next);
    });
  }

  return requireJwtAuth(req, res, next);
};

module.exports = requireJwtOrApiKeyAuth;
