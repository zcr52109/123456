const requireJwtAuth = jest.fn((req, res, next) => {
  req.authPath = 'jwt';
  next();
});

const tenantContextMiddleware = jest.fn((req, res, next) => next());
const requireApiKeyAuth = jest.fn((req, res, next) => {
  req.user = { id: 'user_api', role: 'USER', tenantId: 'tenant_api' };
  req.apiKeyId = 'key_123';
  next();
});
const createRequireApiKeyAuth = jest.fn(() => requireApiKeyAuth);

jest.mock('./requireJwtAuth', () => requireJwtAuth);
jest.mock('~/models', () => ({
  validateAgentApiKey: jest.fn(),
  findUser: jest.fn(),
}));
jest.mock('@fk521ai/api', () => ({
  createRequireApiKeyAuth,
  tenantContextMiddleware,
}));

const requireJwtOrApiKeyAuth = require('./requireJwtOrApiKeyAuth');

const createReq = (authorization) => ({
  headers: authorization ? { authorization } : {},
});

const createRes = () => ({});

describe('requireJwtOrApiKeyAuth', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('routes agent API keys to API key auth and establishes tenant context', () => {
    const req = createReq('Bearer sk-test_123');
    const next = jest.fn();

    requireJwtOrApiKeyAuth(req, createRes(), next);

    expect(requireApiKeyAuth).toHaveBeenCalledTimes(1);
    expect(tenantContextMiddleware).toHaveBeenCalledTimes(1);
    expect(requireJwtAuth).not.toHaveBeenCalled();
    expect(req.apiKeyId).toBe('key_123');
  });

  it('routes JWT bearer tokens to the existing JWT auth middleware', () => {
    const req = createReq('Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.payload.signature');
    const next = jest.fn();

    requireJwtOrApiKeyAuth(req, createRes(), next);

    expect(requireJwtAuth).toHaveBeenCalledTimes(1);
    expect(requireApiKeyAuth).not.toHaveBeenCalled();
    expect(tenantContextMiddleware).not.toHaveBeenCalled();
    expect(req.authPath).toBe('jwt');
  });

  it('falls back to JWT auth when no bearer token is present', () => {
    const req = createReq();
    const next = jest.fn();

    requireJwtOrApiKeyAuth(req, createRes(), next);

    expect(requireJwtAuth).toHaveBeenCalledTimes(1);
    expect(requireApiKeyAuth).not.toHaveBeenCalled();
    expect(tenantContextMiddleware).not.toHaveBeenCalled();
    expect(req.authPath).toBe('jwt');
  });
});
