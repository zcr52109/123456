const cookies = require('cookie');
const jwt = require('jsonwebtoken');
const { logger } = require('@fk521ai/data-schemas');
const { isEnabled } = require('@fk521ai/api');
const { getUserById, findSession, updateUser } = require('~/models');
const { SystemRoles } = require('fk521ai-data-provider');

function parseCookies(req) {
  const cookieHeader = req.headers.cookie;
  return cookieHeader ? cookies.parse(cookieHeader) : {};
}

async function finalizeUser(user) {
  if (!user) {
    return null;
  }
  user.id = user._id.toString();
  if (!user.role) {
    user.role = SystemRoles.USER;
    await updateUser(user.id, { role: user.role });
  }
  return user;
}

async function getFK521AIUserFromRefreshCookie(req) {
  const parsedCookies = parseCookies(req);
  const refreshToken = parsedCookies.refreshToken;
  if (!refreshToken) {
    return null;
  }

  let payload;
  try {
    payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
  } catch (error) {
    logger.debug('[authFromCookies] Invalid FK521AI refresh token', error?.message || error);
    return null;
  }

  if (!payload?.id) {
    return null;
  }

  const session = await findSession({ userId: payload.id, refreshToken }, { lean: false });
  if (!session || session.expiration <= new Date()) {
    return null;
  }

  const user = await getUserById(payload.id, '-password -__v -totpSecret -backupCodes');
  return finalizeUser(user);
}

async function getOpenIdUserFromCookies(req) {
  if (!isEnabled(process.env.OPENID_REUSE_TOKENS)) {
    return null;
  }

  const parsedCookies = parseCookies(req);
  if (parsedCookies.token_provider !== 'openid') {
    return null;
  }

  const signedUserId = parsedCookies.openid_user_id;
  if (!signedUserId) {
    return null;
  }

  let payload;
  try {
    payload = jwt.verify(signedUserId, process.env.JWT_REFRESH_SECRET);
  } catch (error) {
    logger.debug('[authFromCookies] Invalid OpenID signed user cookie', error?.message || error);
    return null;
  }

  if (!payload?.id) {
    return null;
  }

  const user = await getUserById(payload.id, '-password -__v -totpSecret -backupCodes');
  if (!user) {
    return null;
  }

  const sessionTokens = req.session?.openidTokens;
  const refreshToken = sessionTokens?.refreshToken || parsedCookies.refreshToken;
  const accessToken = sessionTokens?.accessToken || parsedCookies.openid_access_token;
  const idToken = sessionTokens?.idToken || parsedCookies.openid_id_token;

  user.federatedTokens = {
    access_token: accessToken,
    id_token: idToken,
    refresh_token: refreshToken,
  };

  return finalizeUser(user);
}

async function getUserFromCookies(req) {
  const parsedCookies = parseCookies(req);
  if (parsedCookies.token_provider === 'openid') {
    const openIdUser = await getOpenIdUserFromCookies(req);
    if (openIdUser) {
      return openIdUser;
    }
  }

  return getFK521AIUserFromRefreshCookie(req);
}

module.exports = {
  getUserFromCookies,
};
