const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const { getSandboxOwnership, chownPathBestEffort } = require('./isolation');

const projectRoot = path.resolve(__dirname, '..', '..', '..', '..');
const sandboxBaseDir = process.env.FK521_SANDBOX_BASE_DIR
  ? path.resolve(process.env.FK521_SANDBOX_BASE_DIR)
  : path.resolve(projectRoot, 'runtime', 'sandboxes');
const DEFAULT_TENANT_SEGMENT = 'default-tenant';
const DEFAULT_USER_SEGMENT = 'anonymous';

function sanitizeSegment(value, fallback = 'default') {
  const input = String(value ?? '').trim();
  const normalized = input.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/_+/g, '_');
  return normalized || fallback;
}

function getConversationKey(conversationId) {
  return sanitizeSegment(conversationId, 'new');
}

function buildSandboxScope(authContext = {}) {
  const user = authContext?.user || {};
  const tenantSegment = sanitizeSegment(
    authContext?.tenantId ?? user?.tenantId ?? DEFAULT_TENANT_SEGMENT,
    DEFAULT_TENANT_SEGMENT,
  );
  const userSegment = sanitizeSegment(
    authContext?.userId ?? user?.id ?? user?._id ?? authContext?.principalId ?? DEFAULT_USER_SEGMENT,
    DEFAULT_USER_SEGMENT,
  );

  return {
    tenantSegment,
    userSegment,
    principalId: String(authContext?.principalId ?? user?.id ?? user?._id ?? DEFAULT_USER_SEGMENT),
  };
}

function getConversationRoot(conversationId, authContext = {}) {
  const scope = buildSandboxScope(authContext);
  return path.join(
    sandboxBaseDir,
    'tenants',
    scope.tenantSegment,
    'users',
    scope.userSegment,
    'conversations',
    getConversationKey(conversationId),
  );
}

function getConversationPaths(conversationId, authContext = {}) {
  const rootDir = getConversationRoot(conversationId, authContext);
  const userDataDir = path.join(rootDir, 'user-data');
  const workspaceDir = path.join(userDataDir, 'workspace');
  const uploadsDir = path.join(userDataDir, 'uploads');
  const outputsDir = path.join(userDataDir, 'outputs');
  const tasksDir = path.join(workspaceDir, 'tasks');
  const projectsDir = path.join(workspaceDir, 'projects');

  return {
    rootDir,
    userDataDir,
    workspaceDir,
    uploadsDir,
    outputsDir,
    tasksDir,
    projectsDir,
  };
}

function hardenDirectory(dirPath, ownership = null) {
  try {
    fs.chmodSync(dirPath, 0o700);
  } catch (_error) {
    // Best-effort hardening; ignore platforms/filesystems that do not support chmod semantics.
  }

  chownPathBestEffort(dirPath, ownership);
}

function ensureConversationSandbox(conversationId, authContext = {}) {
  const paths = getConversationPaths(conversationId, authContext);
  const ownership = getSandboxOwnership(buildSandboxScope(authContext));
  for (const dir of Object.values(paths)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    hardenDirectory(dir, ownership);
  }
  return paths;
}

function getWorkspaceDir(conversationId, authContext = {}) {
  return ensureConversationSandbox(conversationId, authContext).workspaceDir;
}

function getTaskDir(conversationId, taskId, authContext = {}) {
  const { tasksDir } = ensureConversationSandbox(conversationId, authContext);
  const safeTaskId = sanitizeSegment(taskId, 'task');
  const taskDir = path.join(tasksDir, safeTaskId);
  fs.mkdirSync(taskDir, { recursive: true, mode: 0o700 });
  hardenDirectory(taskDir, getSandboxOwnership(buildSandboxScope(authContext)));
  return taskDir;
}

function toSandboxUploadPath(filename) {
  return `/workspace/uploads/${filename}`;
}

function toSandboxOutputPath(relativePath) {
  const cleaned = String(relativePath || '').replace(/^\/+/, '');
  if (!cleaned) {
    return '/workspace';
  }
  if (cleaned.startsWith('outputs/')) {
    return `/workspace/${cleaned}`;
  }
  if (cleaned.startsWith('workspace/tasks/')) {
    return `/workspace/workdir/${cleaned.slice('workspace/'.length)}`;
  }
  return `/workspace/${cleaned}`;
}

function createSandboxPathError(message, code = 'SANDBOX_PATH_INVALID', reason = 'INVALID_PATH') {
  const error = new Error(message);
  error.code = code;
  error.reason = reason;
  return error;
}

function normalizeRelativeSandboxPath(relativePath) {
  const requested = String(relativePath ?? '').trim();
  if (!requested) {
    throw createSandboxPathError('缺少 sandbox 文件路径', 'SANDBOX_PATH_REQUIRED', 'PATH_REQUIRED');
  }

  const normalized = path.posix.normalize(requested.replace(/\\/g, '/').replace(/^\/+/, ''));
  if (
    normalized === '.' ||
    normalized === '' ||
    normalized.startsWith('../') ||
    normalized === '..' ||
    normalized.includes('/../')
  ) {
    throw createSandboxPathError('非法的 sandbox 文件路径', 'SANDBOX_PATH_TRAVERSAL', 'PATH_TRAVERSAL');
  }

  return normalized;
}

function classifySandboxRelativePath(relativePath) {
  const normalized = normalizeRelativeSandboxPath(relativePath);

  if (normalized === 'outputs' || normalized.startsWith('outputs/')) {
    return { normalizedPath: normalized, rootId: 'outputs', downloadAllowed: true };
  }

  if (normalized === 'workspace/tasks' || normalized.startsWith('workspace/tasks/')) {
    return { normalizedPath: normalized, rootId: 'workspace_tasks', downloadAllowed: true };
  }

  if (normalized === 'uploads' || normalized.startsWith('uploads/')) {
    return { normalizedPath: normalized, rootId: 'uploads', downloadAllowed: false };
  }

  if (normalized === 'workspace' || normalized.startsWith('workspace/')) {
    return { normalizedPath: normalized, rootId: 'workspace', downloadAllowed: false };
  }

  return { normalizedPath: normalized, rootId: null, downloadAllowed: false };
}

async function resolveConversationFile(conversationId, relativePath, options = {}) {
  const { userDataDir } = ensureConversationSandbox(conversationId, options.authContext || {});
  const allowedRoots = options.allowedRoots ?? ['outputs', 'workspace_tasks'];
  const classification = classifySandboxRelativePath(relativePath);

  if (!classification.rootId || !allowedRoots.includes(classification.rootId)) {
    throw createSandboxPathError(
      `sandbox 文件根目录不允许访问: ${classification.normalizedPath}`,
      'SANDBOX_ROOT_NOT_ALLOWED',
      'ROOT_NOT_ALLOWED',
    );
  }

  const resolved = path.resolve(userDataDir, classification.normalizedPath);
  const userDataRealPath = await fsp.realpath(userDataDir).catch(() => path.resolve(userDataDir));
  const requestedRealPath = await fsp.realpath(resolved);

  if (
    requestedRealPath !== userDataRealPath &&
    !requestedRealPath.startsWith(userDataRealPath + path.sep)
  ) {
    throw createSandboxPathError(
      `sandbox 文件路径越界: ${classification.normalizedPath}`,
      'SANDBOX_SYMLINK_ESCAPE',
      'SYMLINK_ESCAPE',
    );
  }

  return {
    normalizedPath: classification.normalizedPath,
    absolutePath: requestedRealPath,
    classification,
  };
}

module.exports = {
  sandboxBaseDir,
  sanitizeSegment,
  buildSandboxScope,
  getConversationKey,
  getConversationRoot,
  getConversationPaths,
  ensureConversationSandbox,
  getWorkspaceDir,
  getTaskDir,
  toSandboxUploadPath,
  toSandboxOutputPath,
  normalizeRelativeSandboxPath,
  classifySandboxRelativePath,
  resolveConversationFile,
};
