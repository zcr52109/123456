const { execFile } = require('child_process');
const { promisify } = require('util');
const path = require('path');
const { readDifyConsoleConfig } = require('~/server/utils/difyConsoleConfig');
const { createSandboxAccessError, assertAdmin } = require('./requester');
const { normalizeMultilineList, resolveAllowedPath } = require('./hostFilesystemAccess');

const execFileAsync = promisify(execFile);
const DEFAULT_MAX_ROWS = Number(process.env.FK521_DATABASE_MAX_ROWS || 500);

function getDatabasePolicy() {
  const config = readDifyConsoleConfig();
  const sandboxTools = config.sandboxTools || {};
  const accessEnabled =
    String(process.env.FK521_ALLOW_DATABASE_CONNECT || '').trim().toLowerCase() === 'true' ||
    sandboxTools.allowDatabaseConnect === true;
  const writeEnabled =
    String(process.env.FK521_DATABASE_ENABLE_WRITE || '').trim().toLowerCase() === 'true' ||
    sandboxTools.databaseWriteEnabled === true;
  const allowedHosts = [
    ...normalizeMultilineList(process.env.FK521_DATABASE_ALLOWED_HOSTS || ''),
    ...normalizeMultilineList(sandboxTools.allowedDatabaseHosts || ''),
  ].map((entry) => entry.toLowerCase());
  const allowedSqliteRoots = [
    ...normalizeMultilineList(process.env.FK521_DATABASE_SQLITE_ALLOWED_ROOTS || ''),
    ...normalizeMultilineList(sandboxTools.allowedSqliteRoots || ''),
  ].map((entry) => path.resolve(entry));

  return {
    accessEnabled,
    writeEnabled,
    allowedHosts: [...new Set(allowedHosts)],
    allowedSqliteRoots: [...new Set(allowedSqliteRoots)],
  };
}

function assertDatabaseEnabled() {
  const policy = getDatabasePolicy();
  if (!policy.accessEnabled) {
    throw createSandboxAccessError('数据库连接能力未启用', 'DATABASE_CONNECT_DISABLED', 403);
  }
  return policy;
}

function normalizeDriver(value = '') {
  const input = String(value || '').trim().toLowerCase();
  if (['postgres', 'postgresql', 'pg'].includes(input)) {
    return 'postgresql';
  }
  if (['mysql', 'mysql2'].includes(input)) {
    return 'mysql';
  }
  if (['sqlite', 'sqlite3'].includes(input)) {
    return 'sqlite';
  }
  return input;
}

function normalizeParams(params) {
  if (params == null) {
    return [];
  }
  if (Array.isArray(params)) {
    return params;
  }
  if (typeof params === 'object') {
    return params;
  }
  return [params];
}

function isReadOnlyStatement(statement = '') {
  const normalized = String(statement || '')
    .trim()
    .replace(/^\(+/, '')
    .toLowerCase();
  return /^(select|with|pragma\s+table_info|pragma\s+index_list|show|describe|explain)/.test(normalized);
}

async function executeSqlite({ filename, query, params, readOnly, maxRows, allowedRoots }) {
  if (!allowedRoots.length) {
    throw createSandboxAccessError('SQLite 白名单根目录为空，拒绝访问', 'DATABASE_SQLITE_ROOTS_EMPTY', 403);
  }
  const resolved = resolveAllowedPath(filename, allowedRoots);
  const script = String.raw`
import json, sqlite3, sys
filename, query, params_json, read_only, max_rows = sys.argv[1:6]
params = json.loads(params_json)
read_only = read_only.lower() in ('1', 'true', 'yes', 'on')
max_rows = int(max_rows)
uri = filename
if read_only:
    uri = f"file:{filename}?mode=ro"
conn = sqlite3.connect(uri, uri=read_only)
conn.row_factory = sqlite3.Row
try:
    cur = conn.execute(query, params if isinstance(params, (list, tuple)) else params)
    columns = [item[0] for item in (cur.description or [])]
    rows = [dict(row) for row in cur.fetchmany(max_rows + 1)] if columns else []
    truncated = len(rows) > max_rows
    if truncated:
        rows = rows[:max_rows]
    payload = {
        'driver': 'sqlite',
        'columns': columns,
        'rows': rows,
        'rowCount': len(rows),
        'truncated': truncated,
        'changes': conn.total_changes,
    }
    if not read_only:
        conn.commit()
    print(json.dumps(payload, default=str))
finally:
    conn.close()
`;

  const { stdout } = await execFileAsync(
    'python3',
    ['-c', script, resolved.absolutePath, query, JSON.stringify(params), readOnly ? 'true' : 'false', String(maxRows)],
    { maxBuffer: 20 * 1024 * 1024 },
  );

  return {
    ...JSON.parse(String(stdout || '{}')),
    connection: {
      filename: resolved.absolutePath,
      allowedRoot: resolved.allowedRoot,
    },
  };
}

async function executePostgres({ connection = {}, query, params, readOnly, maxRows, allowedHosts }) {
  const host = String(connection.host || '').trim().toLowerCase();
  if (!allowedHosts.includes(host)) {
    throw createSandboxAccessError('PostgreSQL 主机不在白名单内', 'DATABASE_HOST_NOT_ALLOWED', 403, {
      host,
    });
  }

  let pg;
  try {
    pg = require('pg');
  } catch (_error) {
    throw createSandboxAccessError('未安装 PostgreSQL 驱动，请安装 pg 依赖', 'DATABASE_DRIVER_NOT_INSTALLED', 500, {
      driver: 'pg',
    });
  }

  const client = new pg.Client(connection);
  await client.connect();
  try {
    if (readOnly) {
      await client.query('BEGIN READ ONLY');
    }
    const result = await client.query(query, Array.isArray(params) ? params : []);
    if (readOnly) {
      await client.query('ROLLBACK');
    }
    const rows = Array.isArray(result.rows) ? result.rows.slice(0, maxRows) : [];
    return {
      driver: 'postgresql',
      columns: Array.isArray(result.fields) ? result.fields.map((field) => field.name) : [],
      rows,
      rowCount: rows.length,
      truncated: Array.isArray(result.rows) ? result.rows.length > rows.length : false,
      changes: typeof result.rowCount === 'number' ? result.rowCount : 0,
      connection: {
        host,
        port: connection.port || 5432,
        database: connection.database,
      },
    };
  } finally {
    try {
      await client.end();
    } catch (_error) {
      // noop
    }
  }
}

async function executeMySql({ connection = {}, query, params, readOnly, maxRows, allowedHosts }) {
  const host = String(connection.host || '').trim().toLowerCase();
  if (!allowedHosts.includes(host)) {
    throw createSandboxAccessError('MySQL 主机不在白名单内', 'DATABASE_HOST_NOT_ALLOWED', 403, {
      host,
    });
  }

  let mysql;
  try {
    mysql = require('mysql2/promise');
  } catch (_error) {
    throw createSandboxAccessError('未安装 MySQL 驱动，请安装 mysql2 依赖', 'DATABASE_DRIVER_NOT_INSTALLED', 500, {
      driver: 'mysql2',
    });
  }

  const conn = await mysql.createConnection(connection);
  try {
    if (readOnly) {
      await conn.query('SET SESSION TRANSACTION READ ONLY');
      await conn.beginTransaction();
    }
    const [rows, fields] = await conn.execute(query, Array.isArray(params) ? params : []);
    if (readOnly) {
      await conn.rollback();
    }
    const rowArray = Array.isArray(rows) ? rows.slice(0, maxRows) : [];
    return {
      driver: 'mysql',
      columns: Array.isArray(fields) ? fields.map((field) => field.name) : [],
      rows: rowArray,
      rowCount: rowArray.length,
      truncated: Array.isArray(rows) ? rows.length > rowArray.length : false,
      changes: Array.isArray(rows) ? rowArray.length : Number(rows?.affectedRows || 0),
      connection: {
        host,
        port: connection.port || 3306,
        database: connection.database,
      },
    };
  } finally {
    try {
      await conn.end();
    } catch (_error) {
      // noop
    }
  }
}

async function databaseConnect({
  requester,
  driver,
  connection = {},
  query,
  params = [],
  readOnly = true,
  maxRows = DEFAULT_MAX_ROWS,
} = {}) {
  const policy = assertDatabaseEnabled();

  if (!String(query || '').trim()) {
    throw createSandboxAccessError('数据库操作缺少 query', 'DATABASE_QUERY_REQUIRED', 400);
  }

  const normalizedDriver = normalizeDriver(driver);
  const normalizedParams = normalizeParams(params);
  const effectiveReadOnly = readOnly !== false;

  if (!effectiveReadOnly) {
    assertAdmin(requester, 'database_connect_write');
    if (!policy.writeEnabled) {
      throw createSandboxAccessError('数据库写入未启用', 'DATABASE_WRITE_DISABLED', 403);
    }
  }

  if (effectiveReadOnly && !isReadOnlyStatement(query)) {
    throw createSandboxAccessError('只读数据库连接仅允许 SELECT/SHOW/EXPLAIN/PRAGMA 类语句', 'DATABASE_READ_ONLY_VIOLATION', 400);
  }

  const rowLimit = Math.max(1, Math.min(Number(maxRows) || DEFAULT_MAX_ROWS, DEFAULT_MAX_ROWS));

  if (normalizedDriver === 'sqlite') {
    if (!String(connection.filename || connection.path || '').trim()) {
      throw createSandboxAccessError('SQLite 连接缺少 filename/path', 'DATABASE_SQLITE_PATH_REQUIRED', 400);
    }
    return await executeSqlite({
      filename: connection.filename || connection.path,
      query,
      params: normalizedParams,
      readOnly: effectiveReadOnly,
      maxRows: rowLimit,
      allowedRoots: policy.allowedSqliteRoots,
    });
  }

  if (normalizedDriver === 'postgresql') {
    return await executePostgres({
      connection,
      query,
      params: normalizedParams,
      readOnly: effectiveReadOnly,
      maxRows: rowLimit,
      allowedHosts: policy.allowedHosts,
    });
  }

  if (normalizedDriver === 'mysql') {
    return await executeMySql({
      connection,
      query,
      params: normalizedParams,
      readOnly: effectiveReadOnly,
      maxRows: rowLimit,
      allowedHosts: policy.allowedHosts,
    });
  }

  throw createSandboxAccessError('不支持的数据库驱动', 'DATABASE_DRIVER_UNSUPPORTED', 400, {
    driver: normalizedDriver,
  });
}

module.exports = {
  DEFAULT_MAX_ROWS,
  databaseConnect,
  getDatabasePolicy,
  isReadOnlyStatement,
  normalizeDriver,
  normalizeParams,
};
