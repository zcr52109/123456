const {
  normalizeAllowedDomains,
  normalizeAllowedPrefixes,
  isHostnameAllowed,
  isPrefixAllowed,
} = require('./webFetch');

describe('webFetch network policy helpers', () => {
  test('normalizes domain and prefix lists', () => {
    expect(normalizeAllowedDomains('API.GITHUB.COM\nregistry.npmjs.org')).toEqual([
      'api.github.com',
      'registry.npmjs.org',
    ]);
    expect(normalizeAllowedPrefixes('https://api.github.com/\nhttps://registry.npmjs.org/')).toEqual([
      'https://api.github.com/',
      'https://registry.npmjs.org/',
    ]);
  });

  test('matches allowed hostnames and url prefixes', () => {
    expect(isHostnameAllowed('sub.api.github.com', ['api.github.com'])).toBe(true);
    expect(isHostnameAllowed('example.com', ['api.github.com'])).toBe(false);
    expect(isPrefixAllowed('https://api.github.com/repos/openai/openai', ['https://api.github.com/'])).toBe(true);
    expect(isPrefixAllowed('https://example.com', ['https://api.github.com/'])).toBe(false);
  });
});
