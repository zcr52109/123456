const crypto = require('crypto');
const fs = require('fs/promises');
const path = require('path');
const { readDifyConsoleConfig } = require('~/server/utils/difyConsoleConfig');
const { assertAdmin, createSandboxAccessError } = require('./requester');

function normalizeMultilineList(value = '') {
  return String(value || '')
    .split(/\r?\n/)
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function getHostFilesystemPolicy() {
  const config = readDifyConsoleConfig();
  const sandboxTools = config.sandboxTools || {};

  const allowedPaths = [
    ...normalizeMultilineList(process.env.FK521_HOST_FS_ALLOWED_PATHS || ''),
    ...normalizeMultilineList(sandboxTools.hostFilesystemAllowedPaths || ''),
  ].map((entry) => path.resolve(entry));

  const writeEnabled =
    String(process.env.FK521_HOST_FS_ENABLE_WRITE || '').trim().toLowerCase() === 'true' ||
    sandboxTools.hostFilesystemWriteEnabled === true;

  const accessEnabled =
    String(process.env.FK521_ALLOW_HOST_FILESYSTEM_ACCESS || '').trim().toLowerCase() === 'true' ||
    sandboxTools.allowHostFilesystemAccess === true;

  return {
    accessEnabled,
    writeEnabled,
    allowedPaths: [...new Set(allowedPaths)],
  };
}

function assertHostFilesystemEnabled() {
  const policy = getHostFilesystemPolicy();
  if (!policy.accessEnabled) {
    throw createSandboxAccessError('宿主机文件系统访问未启用', 'HOST_FS_DISABLED', 403);
  }
  if (!policy.allowedPaths.length) {
    throw createSandboxAccessError('宿主机文件系统白名单为空，拒绝访问', 'HOST_FS_NO_ALLOWED_PATHS', 403);
  }
  return policy;
}

function resolveAllowedPath(targetPath, allowedPaths = []) {
  const resolved = path.resolve(String(targetPath || ''));
  const matchedRoot = allowedPaths.find((allowedPath) => {
    return resolved === allowedPath || resolved.startsWith(`${allowedPath}${path.sep}`);
  });

  if (!matchedRoot) {
    throw createSandboxAccessError('目标路径不在宿主机白名单内', 'HOST_FS_PATH_NOT_ALLOWED', 403, {
      path: resolved,
    });
  }

  return {
    absolutePath: resolved,
    allowedRoot: matchedRoot,
  };
}

async function computeSha256(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash('sha256').update(data).digest('hex');
}

async function hostFilesystemAccess({
  requester,
  operation = 'stat',
  path: targetPath,
  range = null,
  encoding = 'utf8',
  content = null,
  overwrite = false,
} = {}) {
  assertAdmin(requester, 'host_filesystem_access');
  const policy = assertHostFilesystemEnabled();

  if (!String(targetPath || '').trim()) {
    throw createSandboxAccessError('缺少宿主机路径', 'HOST_FS_PATH_REQUIRED', 400);
  }

  const resolved = resolveAllowedPath(targetPath, policy.allowedPaths);
  const op = String(operation || 'stat').trim().toLowerCase();

  if (op === 'list') {
    const entries = await fs.readdir(resolved.absolutePath, { withFileTypes: true });
    return {
      operation: 'list',
      path: resolved.absolutePath,
      allowedRoot: resolved.allowedRoot,
      entries: await Promise.all(entries.map(async (entry) => {
        const fullPath = path.join(resolved.absolutePath, entry.name);
        const stat = await fs.stat(fullPath);
        return {
          name: entry.name,
          path: fullPath,
          type: entry.isDirectory() ? 'directory' : 'file',
          size: entry.isDirectory() ? null : stat.size,
          mtime: stat.mtime.toISOString(),
        };
      })),
    };
  }

  if (op === 'stat') {
    const stat = await fs.stat(resolved.absolutePath);
    return {
      operation: 'stat',
      path: resolved.absolutePath,
      allowedRoot: resolved.allowedRoot,
      exists: true,
      type: stat.isDirectory() ? 'directory' : 'file',
      size: stat.isDirectory() ? null : stat.size,
      mtime: stat.mtime.toISOString(),
      sha256: stat.isFile() ? await computeSha256(resolved.absolutePath) : null,
    };
  }

  if (op === 'read') {
    const handle = await fs.open(resolved.absolutePath, 'r');
    try {
      const stat = await handle.stat();
      if (!stat.isFile()) {
        throw createSandboxAccessError('宿主机目标不是文件', 'HOST_FS_NOT_A_FILE', 400, {
          path: resolved.absolutePath,
        });
      }
      const start = Math.max(0, Number(range?.start ?? 0) || 0);
      const endExclusive = range?.end == null
        ? stat.size
        : Math.min(stat.size, Math.max(start, Number(range.end) || 0));
      const length = Math.max(0, endExclusive - start);
      const buffer = Buffer.alloc(length);
      await handle.read(buffer, 0, length, start);
      return {
        operation: 'read',
        path: resolved.absolutePath,
        allowedRoot: resolved.allowedRoot,
        encoding: encoding === 'base64' ? 'base64' : 'utf8',
        bytes: buffer.length,
        totalBytes: stat.size,
        content: encoding === 'base64' ? buffer.toString('base64') : buffer.toString('utf8'),
      };
    } finally {
      await handle.close();
    }
  }

  if (op === 'mkdir') {
    if (!policy.writeEnabled) {
      throw createSandboxAccessError('宿主机文件系统写入未启用', 'HOST_FS_WRITE_DISABLED', 403);
    }
    await fs.mkdir(resolved.absolutePath, { recursive: true });
    return {
      operation: 'mkdir',
      path: resolved.absolutePath,
      allowedRoot: resolved.allowedRoot,
      created: true,
    };
  }

  if (op === 'write') {
    if (!policy.writeEnabled) {
      throw createSandboxAccessError('宿主机文件系统写入未启用', 'HOST_FS_WRITE_DISABLED', 403);
    }
    if (content == null) {
      throw createSandboxAccessError('宿主机写入缺少 content', 'HOST_FS_CONTENT_REQUIRED', 400);
    }

    const exists = await fs.stat(resolved.absolutePath).then(() => true).catch(() => false);
    if (exists && overwrite !== true) {
      throw createSandboxAccessError('宿主机目标文件已存在且未允许覆盖', 'HOST_FS_EXISTS', 409, {
        path: resolved.absolutePath,
      });
    }

    await fs.mkdir(path.dirname(resolved.absolutePath), { recursive: true });
    const buffer = encoding === 'base64'
      ? Buffer.from(String(content || ''), 'base64')
      : Buffer.from(String(content || ''), 'utf8');
    await fs.writeFile(resolved.absolutePath, buffer);
    return {
      operation: 'write',
      path: resolved.absolutePath,
      allowedRoot: resolved.allowedRoot,
      bytes: buffer.length,
      sha256: await computeSha256(resolved.absolutePath),
      overwritten: exists,
    };
  }

  throw createSandboxAccessError('不支持的宿主机文件系统操作', 'HOST_FS_OPERATION_UNSUPPORTED', 400, {
    operation: op,
  });
}

module.exports = {
  getHostFilesystemPolicy,
  hostFilesystemAccess,
  normalizeMultilineList,
  resolveAllowedPath,
};
