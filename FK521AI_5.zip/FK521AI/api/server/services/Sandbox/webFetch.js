const dns = require('dns').promises;
const net = require('net');
const { URL } = require('url');
const fetch = require('node-fetch');
const { readDifyConsoleConfig } = require('~/server/utils/difyConsoleConfig');
const { createSandboxAccessError } = require('./requester');

const PRIVATE_CIDR_PATTERNS = Object.freeze([
  /^127\./,
  /^10\./,
  /^192\.168\./,
  /^169\.254\./,
  /^172\.(1[6-9]|2\d|3[0-1])\./,
  /^0\./,
]);

function isPrivateIPv4(host = '') {
  return PRIVATE_CIDR_PATTERNS.some((pattern) => pattern.test(host));
}

function isPrivateIPv6(host = '') {
  const value = String(host || '').toLowerCase();
  return value === '::1' || value.startsWith('fc') || value.startsWith('fd') || value.startsWith('fe80:');
}

function normalizeList(value = '') {
  return String(value || '')
    .split(/\r?\n/)
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function normalizeAllowedDomains(value = '') {
  return normalizeList(value).map((entry) => entry.toLowerCase());
}

function normalizeAllowedPrefixes(value = '') {
  return normalizeList(value);
}

function isHostnameAllowed(hostname, allowedDomains = []) {
  if (!allowedDomains.length) {
    return false;
  }
  const normalized = String(hostname || '').trim().toLowerCase();
  return allowedDomains.some((domain) => normalized === domain || normalized.endsWith(`.${domain}`));
}

function isPrefixAllowed(urlValue, allowedPrefixes = []) {
  if (!allowedPrefixes.length) {
    return false;
  }
  return allowedPrefixes.some((prefix) => String(urlValue || '').startsWith(prefix));
}

async function assertSafeRemote(urlObject) {
  const hostname = String(urlObject.hostname || '').trim().toLowerCase();
  if (!hostname) {
    throw createSandboxAccessError('目标地址缺少主机名', 'WEB_FETCH_HOST_REQUIRED', 400);
  }
  if (['localhost', 'host.docker.internal'].includes(hostname)) {
    throw createSandboxAccessError('禁止访问本地或宿主机地址', 'WEB_FETCH_LOCALHOST_BLOCKED', 403);
  }
  const isIp = net.isIP(hostname);
  if (isIp === 4 && isPrivateIPv4(hostname)) {
    throw createSandboxAccessError('禁止访问私有 IPv4 地址', 'WEB_FETCH_PRIVATE_IPV4', 403);
  }
  if (isIp === 6 && isPrivateIPv6(hostname)) {
    throw createSandboxAccessError('禁止访问私有 IPv6 地址', 'WEB_FETCH_PRIVATE_IPV6', 403);
  }

  if (!isIp) {
    const records = await dns.lookup(hostname, { all: true }).catch(() => []);
    if (!records.length) {
      throw createSandboxAccessError('目标域名解析失败', 'WEB_FETCH_DNS_LOOKUP_FAILED', 400, { hostname });
    }
    for (const record of records) {
      const address = String(record.address || '');
      if ((record.family === 4 && isPrivateIPv4(address)) || (record.family === 6 && isPrivateIPv6(address))) {
        throw createSandboxAccessError('禁止访问解析到私网地址的域名', 'WEB_FETCH_PRIVATE_RESOLUTION', 403, {
          hostname,
          address,
        });
      }
    }
  }
}

async function readLimitedBody(response, maxFetchBytes, fetchTimeoutMs, controller) {
  const chunks = [];
  let totalBytes = 0;
  let truncated = false;

  return await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      controller.abort();
      reject(createSandboxAccessError('web_fetch 响应读取超时', 'WEB_FETCH_READ_TIMEOUT', 504));
    }, fetchTimeoutMs);

    response.body.on('data', (chunk) => {
      totalBytes += chunk.length;
      if (totalBytes > maxFetchBytes) {
        truncated = true;
        chunks.push(chunk.subarray(0, Math.max(0, maxFetchBytes - (totalBytes - chunk.length))));
        controller.abort();
        return;
      }
      chunks.push(chunk);
    });

    response.body.on('error', (error) => {
      clearTimeout(timer);
      if (truncated || error?.name === 'AbortError') {
        resolve({ buffer: Buffer.concat(chunks), totalBytes, truncated: true });
        return;
      }
      reject(error);
    });

    response.body.on('end', () => {
      clearTimeout(timer);
      resolve({ buffer: Buffer.concat(chunks), totalBytes, truncated });
    });
  });
}

async function webFetch({ url, method = 'GET', headers = {}, body = null }) {
  const config = readDifyConsoleConfig();
  const toolsConfig = config.sandboxTools || {};

  if (toolsConfig.allowWebFetch !== true) {
    throw createSandboxAccessError('外部网络访问未启用', 'WEB_FETCH_DISABLED', 403);
  }

  const maxFetchBytes = Number(toolsConfig.maxFetchBytes || 524288);
  const fetchTimeoutMs = Number(toolsConfig.fetchTimeoutMs || 12000);
  const parsed = new URL(String(url || ''));
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw createSandboxAccessError('仅支持 http/https 网页访问', 'WEB_FETCH_PROTOCOL_UNSUPPORTED', 400);
  }

  const requestedUrl = parsed.toString();
  await assertSafeRemote(parsed);

  const contentLengthHint = Number(headers['content-length'] || headers['Content-Length'] || 0);
  if (Number.isFinite(contentLengthHint) && contentLengthHint > maxFetchBytes) {
    throw createSandboxAccessError('请求体超过上限', 'WEB_FETCH_REQUEST_TOO_LARGE', 413, {
      maxFetchBytes,
      contentLengthHint,
    });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), fetchTimeoutMs);
  try {
    const response = await fetch(requestedUrl, {
      method: String(method || 'GET').toUpperCase(),
      headers,
      body,
      redirect: 'manual',
      follow: 0,
      compress: false,
      size: maxFetchBytes,
      signal: controller.signal,
    });

    if (response.status >= 300 && response.status < 400) {
      throw createSandboxAccessError('web_fetch 禁止自动跟随重定向', 'WEB_FETCH_REDIRECT_BLOCKED', 403, {
        location: response.headers.get('location') || null,
      });
    }

    const responseLength = Number(response.headers.get('content-length') || 0);
    if (Number.isFinite(responseLength) && responseLength > maxFetchBytes) {
      throw createSandboxAccessError('响应大小超过上限', 'WEB_FETCH_RESPONSE_TOO_LARGE', 413, {
        maxFetchBytes,
        responseLength,
      });
    }

    const { buffer, totalBytes, truncated } = await readLimitedBody(
      response,
      maxFetchBytes,
      fetchTimeoutMs,
      controller,
    );

    const contentType = String(response.headers.get('content-type') || '').toLowerCase();
    const isText = contentType.includes('json') || contentType.includes('text') || contentType.includes('xml') || contentType.includes('html') || !contentType;

    return {
      url: requestedUrl,
      status: response.status,
      ok: response.ok,
      contentType,
      bytes: buffer.length,
      totalBytes,
      truncated,
      encoding: isText ? 'utf8' : 'base64',
      body: isText ? buffer.toString('utf8') : buffer.toString('base64'),
      headers: Object.fromEntries(response.headers.entries()),
      policy: {
        networkPolicy: 'public_remote_only',
        maxFetchBytes,
        fetchTimeoutMs,
      },
    };
  } finally {
    clearTimeout(timer);
  }
}

module.exports = {
  webFetch,
  normalizeAllowedDomains,
  normalizeAllowedPrefixes,
  isHostnameAllowed,
  isPrefixAllowed,
};
