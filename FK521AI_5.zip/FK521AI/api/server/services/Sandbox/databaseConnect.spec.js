const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { databaseConnect, isReadOnlyStatement, normalizeDriver } = require('./databaseConnect');

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fk521-db-'));
const dbPath = path.join(tempDir, 'sample.sqlite');

beforeAll(() => {
  execFileSync('python3', ['-c', `
import sqlite3, sys
conn = sqlite3.connect(sys.argv[1])
conn.execute('create table items (id integer primary key, name text)')
conn.execute('insert into items(name) values (?)', ('alpha',))
conn.execute('insert into items(name) values (?)', ('beta',))
conn.commit()
conn.close()
`, dbPath]);
  process.env.FK521_ALLOW_DATABASE_CONNECT = 'true';
  process.env.FK521_DATABASE_SQLITE_ALLOWED_ROOTS = tempDir;
});

afterAll(() => {
  fs.rmSync(tempDir, { recursive: true, force: true });
  delete process.env.FK521_ALLOW_DATABASE_CONNECT;
  delete process.env.FK521_DATABASE_SQLITE_ALLOWED_ROOTS;
});

describe('databaseConnect', () => {
  test('normalizes driver names and read-only statements', () => {
    expect(normalizeDriver('pg')).toBe('postgresql');
    expect(normalizeDriver('mysql2')).toBe('mysql');
    expect(isReadOnlyStatement('SELECT * FROM items')).toBe(true);
    expect(isReadOnlyStatement('INSERT INTO items(name) VALUES (\'x\')')).toBe(false);
  });

  test('executes read-only sqlite queries through the controlled connector', async () => {
    const result = await databaseConnect({
      requester: { isAdmin: false },
      driver: 'sqlite',
      connection: { filename: dbPath },
      query: 'SELECT id, name FROM items WHERE name = ?',
      params: ['alpha'],
      readOnly: true,
      maxRows: 10,
    });

    expect(result.driver).toBe('sqlite');
    expect(result.rows).toEqual([{ id: 1, name: 'alpha' }]);
    expect(result.connection.filename).toBe(dbPath);
  });
});
