const crypto = require('crypto');

function parseBooleanEnv(value, fallback = false) {
  if (value == null || value === '') {
    return fallback;
  }
  const normalized = String(value).trim().toLowerCase();
  if (['1', 'true', 'yes', 'on'].includes(normalized)) {
    return true;
  }
  if (['0', 'false', 'no', 'off'].includes(normalized)) {
    return false;
  }
  return fallback;
}

function parseIntegerEnv(value, fallback) {
  const parsed = Number.parseInt(String(value ?? ''), 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function normalizePositiveInteger(value, fallback, minimum = 1) {
  const parsed = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed) || parsed < minimum) {
    return fallback;
  }
  return parsed;
}

function hashToOffset(seed, span) {
  const digest = crypto.createHash('sha256').update(String(seed || '')).digest();
  return digest.readUInt32BE(0) % span;
}

function deriveScopedId({ seed, base, span, minimum = 1 } = {}) {
  const normalizedBase = normalizePositiveInteger(base, 100000, minimum);
  const normalizedSpan = normalizePositiveInteger(span, 50000, 1);
  return normalizedBase + hashToOffset(seed, normalizedSpan);
}

function getSandboxOwnership(scope = {}) {
  const seed = `${scope.tenantSegment || 'default-tenant'}:${scope.userSegment || 'anonymous'}`;
  const base = parseIntegerEnv(process.env.FK521_SANDBOX_UID_BASE, 100000);
  const span = parseIntegerEnv(process.env.FK521_SANDBOX_UID_SPAN, 50000);
  const gidBase = parseIntegerEnv(process.env.FK521_SANDBOX_GID_BASE, base);
  const gidSpan = parseIntegerEnv(process.env.FK521_SANDBOX_GID_SPAN, span);

  return {
    uid: deriveScopedId({ seed: `uid:${seed}`, base, span, minimum: 1000 }),
    gid: deriveScopedId({ seed: `gid:${seed}`, base: gidBase, span: gidSpan, minimum: 1000 }),
  };
}

function getSandboxIsolationConfig(scope = {}) {
  const runtime = String(process.env.FK521_SANDBOX_RUNTIME || '').trim();
  const usernsMode = String(process.env.FK521_SANDBOX_DOCKER_USERNS_MODE || '').trim();
  const pidsLimit = normalizePositiveInteger(process.env.FK521_SANDBOX_PIDS_LIMIT, 256, 16);

  return {
    ownership: getSandboxOwnership(scope),
    runtime,
    usernsMode,
    pidsLimit,
    expectRootless: parseBooleanEnv(process.env.FK521_SANDBOX_EXPECT_ROOTLESS, true),
    expectUsernsRemap: parseBooleanEnv(process.env.FK521_SANDBOX_EXPECT_USERNS_REMAP, true),
    internalBridge: parseBooleanEnv(process.env.FK521_SANDBOX_INTERNAL_BRIDGE, true),
    allowHostGateway: parseBooleanEnv(process.env.FK521_SANDBOX_BRIDGE_ADD_HOST, false),
    seccompProfile: String(process.env.FK521_SANDBOX_SECCOMP_PROFILE || 'default').trim() || 'default',
    runtimeClassHint: runtime || 'runc',
  };
}

function chownPathBestEffort(targetPath, ownership) {
  if (!targetPath || !ownership) {
    return;
  }

  try {
    require('fs').chownSync(targetPath, ownership.uid, ownership.gid);
  } catch (_error) {
    // Best-effort only. This can fail on non-POSIX filesystems or rootless hosts.
  }
}

module.exports = {
  parseBooleanEnv,
  parseIntegerEnv,
  normalizePositiveInteger,
  deriveScopedId,
  getSandboxOwnership,
  getSandboxIsolationConfig,
  chownPathBestEffort,
};
