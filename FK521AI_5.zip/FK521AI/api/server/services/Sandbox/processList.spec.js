const { parsePsOutput, collectDescendants } = require('./processList');

describe('processList helpers', () => {
  test('parsePsOutput parses ps rows', () => {
    const rows = parsePsOutput('101 1 S 00:10 0.1 1024 node\n102 101 R 00:01 5.0 2048 python\n');
    expect(rows).toEqual([
      { pid: 101, parentPid: 1, state: 'S', elapsedTime: '00:10', cpuPercent: 0.1, rssKb: 1024, name: 'node' },
      { pid: 102, parentPid: 101, state: 'R', elapsedTime: '00:01', cpuPercent: 5, rssKb: 2048, name: 'python' },
    ]);
  });

  test('collectDescendants returns nested children of the root pid', () => {
    const descendants = collectDescendants([
      { pid: 10, parentPid: 1 },
      { pid: 11, parentPid: 10 },
      { pid: 12, parentPid: 11 },
      { pid: 20, parentPid: 2 },
    ], 10);

    expect(descendants.map((item) => item.pid)).toEqual([11, 12]);
  });
});
