const fs = require('fs/promises');
const path = require('path');
const net = require('net');
const { URL } = require('url');
const mime = require('mime');
const {
  resolveVirtualWorkspacePath,
  createWorkspaceError,
} = require('./workspaceFs');

const DEFAULT_MAX_SCAN_BYTES = Number(process.env.FK521_CONTENT_SCAN_MAX_BYTES || 1024 * 1024);
const DEFAULT_MAX_FINDINGS = Number(process.env.FK521_CONTENT_SCAN_MAX_FINDINGS || 200);

const SENSITIVE_WORD_PATTERNS = Object.freeze([
  { name: 'password_word', pattern: /\b(password|passwd|pwd)\b/gi, severity: 'medium' },
  { name: 'secret_word', pattern: /\b(secret|client_secret|app_secret)\b/gi, severity: 'medium' },
  { name: 'token_word', pattern: /\b(access[_-]?token|refresh[_-]?token|bearer)\b/gi, severity: 'medium' },
  { name: 'private_key_word', pattern: /\b(private key|ssh-rsa|ssh-ed25519)\b/gi, severity: 'high' },
]);

const SECRET_PATTERNS = Object.freeze([
  {
    name: 'private_key_block',
    type: 'secret',
    severity: 'critical',
    pattern: /-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z0-9 ]*PRIVATE KEY-----/g,
  },
  {
    name: 'openai_key',
    type: 'secret',
    severity: 'high',
    pattern: /\bsk-[A-Za-z0-9_-]{20,}\b/g,
  },
  {
    name: 'aws_access_key',
    type: 'secret',
    severity: 'high',
    pattern: /\b(A3T|AKIA|ASIA|AGPA|AIDA|ANPA|ANVA|AROA|ABIA)[A-Z0-9]{16}\b/g,
  },
  {
    name: 'generic_assignment_secret',
    type: 'secret',
    severity: 'high',
    pattern:
      /\b(?:api[_-]?key|secret|token|password|passwd|authorization)\b\s*[:=]\s*["']?[A-Za-z0-9_\-\/+=]{8,}["']?/gi,
  },
  {
    name: 'jwt',
    type: 'secret',
    severity: 'medium',
    pattern: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9._-]{10,}\.[A-Za-z0-9._-]{10,}\b/g,
  },
]);

const ID_PATTERNS = Object.freeze([
  {
    name: 'cn_mainland_id',
    type: 'pii',
    severity: 'high',
    pattern: /\b[1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx]\b/g,
  },
  {
    name: 'email_address',
    type: 'pii',
    severity: 'medium',
    pattern: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,
  },
  {
    name: 'phone_number',
    type: 'pii',
    severity: 'medium',
    pattern: /(?<!\w)(?:\+?\d{1,3}[ -]?)?(?:\(?\d{2,4}\)?[ -]?)?\d{3,4}[ -]?\d{4}(?!\w)/g,
  },
  {
    name: 'credit_card_like',
    type: 'pii',
    severity: 'high',
    pattern: /\b(?:\d[ -]*?){13,19}\b/g,
  },
]);

const HIGH_RISK_CODE_PATTERNS = Object.freeze([
  { name: 'python_eval', pattern: /\beval\s*\(/g, severity: 'high' },
  { name: 'python_exec', pattern: /\bexec\s*\(/g, severity: 'high' },
  { name: 'python_os_system', pattern: /\bos\.system\s*\(/g, severity: 'high' },
  { name: 'python_subprocess', pattern: /\bsubprocess\.(?:Popen|run|call|check_output|check_call)\s*\(/g, severity: 'high' },
  { name: 'node_child_process', pattern: /\bchild_process\.(?:exec|execSync|spawn|spawnSync|fork)\s*\(/g, severity: 'high' },
  { name: 'js_function_ctor', pattern: /\bnew\s+Function\s*\(/g, severity: 'high' },
  { name: 'pickle_loads', pattern: /\bpickle\.loads\s*\(/g, severity: 'medium' },
  { name: 'yaml_load', pattern: /\byaml\.load\s*\(/g, severity: 'medium' },
]);

const OBFUSCATION_PATTERNS = Object.freeze([
  {
    name: 'base64_blob',
    type: 'obfuscation',
    severity: 'medium',
    pattern: /\b(?:[A-Za-z0-9+/]{80,}={0,2})\b/g,
  },
  {
    name: 'hex_blob',
    type: 'obfuscation',
    severity: 'medium',
    pattern: /\b(?:0x)?[A-Fa-f0-9]{64,}\b/g,
  },
  {
    name: 'unicode_escape_run',
    type: 'obfuscation',
    severity: 'medium',
    pattern: /(?:\\u[0-9a-fA-F]{4}){8,}/g,
  },
  {
    name: 'percent_encoding_run',
    type: 'obfuscation',
    severity: 'medium',
    pattern: /(?:%[0-9A-Fa-f]{2}){12,}/g,
  },
  {
    name: 'from_char_code',
    type: 'obfuscation',
    severity: 'medium',
    pattern: /String\.fromCharCode\s*\(/g,
  },
]);

const SUSPICIOUS_URL_HOSTS = new Set([
  'bit.ly',
  'tinyurl.com',
  'goo.gl',
  't.co',
  'is.gd',
  'ow.ly',
  'buff.ly',
  'lnkd.in',
  'cutt.ly',
  'rebrand.ly',
]);

const SUSPICIOUS_URL_PATH_PATTERNS = Object.freeze([
  /(?:%2e|%2f|\.\.)/i,
  /(?:javascript:|data:)/i,
  /(?:cmd=|exec=|token=|api[_-]?key=|password=)/i,
]);

function isBinaryBuffer(buffer) {
  const sample = buffer.subarray(0, Math.min(buffer.length, 2048));
  if (sample.includes(0)) {
    return true;
  }

  let suspicious = 0;
  for (const byte of sample) {
    if ((byte < 9 || (byte > 13 && byte < 32)) && byte !== 27) {
      suspicious += 1;
    }
  }

  return sample.length > 0 && suspicious / sample.length > 0.1;
}

function truncateValue(value, max = 180) {
  const text = String(value || '');
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function indexToLineCol(text, index) {
  const safeIndex = Math.max(0, Number(index) || 0);
  const prefix = text.slice(0, safeIndex);
  const lines = prefix.split('\n');
  return {
    line: lines.length,
    column: (lines[lines.length - 1] || '').length + 1,
  };
}

function extractContext(text, index, matchLength) {
  const start = Math.max(0, index - 80);
  const end = Math.min(text.length, index + matchLength + 80);
  return truncateValue(text.slice(start, end).replace(/\s+/g, ' ').trim(), 240);
}

function pushFinding(findings, finding, maxFindings) {
  if (findings.length >= maxFindings) {
    return;
  }
  findings.push(finding);
}

function scanPatternSet({ text, findings, definitions, type, maxFindings }) {
  for (const definition of definitions) {
    definition.pattern.lastIndex = 0;
    let match;
    while ((match = definition.pattern.exec(text)) !== null) {
      const { line, column } = indexToLineCol(text, match.index);
      pushFinding(
        findings,
        {
          type: definition.type || type,
          subtype: definition.name,
          severity: definition.severity,
          match: truncateValue(match[0]),
          line,
          column,
          context: extractContext(text, match.index, match[0].length),
        },
        maxFindings,
      );
      if (findings.length >= maxFindings) {
        return;
      }
      if (match.index === definition.pattern.lastIndex) {
        definition.pattern.lastIndex += 1;
      }
    }
  }
}

function scanUrls({ text, findings, maxFindings }) {
  const urlRegex = /https?:\/\/[^\s"'`<>]+/gi;
  let match;
  while ((match = urlRegex.exec(text)) !== null) {
    let parsed;
    try {
      parsed = new URL(match[0]);
    } catch (_error) {
      continue;
    }

    const hostname = String(parsed.hostname || '').toLowerCase();
    const reasons = [];
    if (SUSPICIOUS_URL_HOSTS.has(hostname)) {
      reasons.push('shortener');
    }
    if (parsed.username || parsed.password) {
      reasons.push('userinfo');
    }
    if (hostname.startsWith('xn--')) {
      reasons.push('punycode');
    }
    if (net.isIP(hostname)) {
      reasons.push('ip_literal');
    }
    if (parsed.protocol === 'http:') {
      reasons.push('plaintext_http');
    }
    if ((parsed.search || '').length > 180) {
      reasons.push('long_query');
    }
    if (SUSPICIOUS_URL_PATH_PATTERNS.some((pattern) => pattern.test(parsed.pathname) || pattern.test(parsed.search))) {
      reasons.push('encoded_or_sensitive_path');
    }

    if (!reasons.length) {
      continue;
    }

    const { line, column } = indexToLineCol(text, match.index);
    pushFinding(
      findings,
      {
        type: 'url',
        subtype: 'suspicious_url',
        severity: reasons.includes('userinfo') || reasons.includes('punycode') ? 'high' : 'medium',
        match: truncateValue(match[0]),
        line,
        column,
        context: extractContext(text, match.index, match[0].length),
        reasons,
      },
      maxFindings,
    );
    if (findings.length >= maxFindings) {
      return;
    }
  }
}

function summarizeFindings(findings = []) {
  const counts = {};
  const severities = { critical: 0, high: 0, medium: 0, low: 0 };
  for (const finding of findings) {
    counts[finding.type] = (counts[finding.type] || 0) + 1;
    severities[finding.severity] = (severities[finding.severity] || 0) + 1;
  }
  const riskLevel = severities.critical > 0 ? 'critical' : severities.high > 0 ? 'high' : severities.medium > 0 ? 'medium' : severities.low > 0 ? 'low' : 'none';
  return { counts, severities, riskLevel };
}

function dedupeFindings(findings = []) {
  const seen = new Set();
  return findings.filter((finding) => {
    const key = [finding.type, finding.subtype, finding.line, finding.column, finding.match].join('|');
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}

async function readScanInput({ conversationId, text, targetPath, maxBytes }) {
  if (typeof text === 'string' && text.length > 0) {
    const buffer = Buffer.from(text, 'utf8');
    return {
      source: 'inline_text',
      path: null,
      mimeType: 'text/plain',
      bytes: buffer.length,
      truncated: buffer.length > maxBytes,
      buffer: buffer.subarray(0, maxBytes),
    };
  }

  const resolved = resolveVirtualWorkspacePath(conversationId, targetPath, { forWrite: false });
  if (resolved.isWorkspaceRoot) {
    throw createWorkspaceError('content_scan 只能扫描具体文件，不能直接扫描工作区根目录', 'CONTENT_SCAN_PATH_REQUIRED', 400, {
      path: targetPath,
    });
  }

  const buffer = await fs.readFile(resolved.absolutePath);
  return {
    source: 'workspace_file',
    path: resolved.virtualPath,
    mimeType: mime.getType(path.basename(resolved.absolutePath)) || 'application/octet-stream',
    bytes: buffer.length,
    truncated: buffer.length > maxBytes,
    buffer: buffer.subarray(0, maxBytes),
  };
}

async function contentScan({ conversationId, path: targetPath, text, maxBytes = DEFAULT_MAX_SCAN_BYTES, maxFindings = DEFAULT_MAX_FINDINGS }) {
  if (!(typeof text === 'string' && text.length > 0) && !String(targetPath || '').trim()) {
    throw createWorkspaceError('content_scan 需要 path 或 text 之一', 'CONTENT_SCAN_INPUT_REQUIRED', 400);
  }

  const source = await readScanInput({
    conversationId,
    text,
    targetPath,
    maxBytes: Math.max(1024, Number(maxBytes) || DEFAULT_MAX_SCAN_BYTES),
  });

  const binary = isBinaryBuffer(source.buffer);
  if (binary) {
    return {
      source: source.source,
      path: source.path,
      mimeType: source.mimeType,
      bytes: source.bytes,
      scannedBytes: source.buffer.length,
      truncated: source.truncated,
      binary: true,
      findings: [],
      summary: {
        counts: {},
        severities: { critical: 0, high: 0, medium: 0, low: 0 },
      },
      warnings: ['检测到二进制内容；content_scan 仅对文本/代码做轻量扫描'],
    };
  }

  const textContent = source.buffer.toString('utf8');
  const findings = [];

  scanPatternSet({ text: textContent, findings, definitions: SENSITIVE_WORD_PATTERNS, type: 'keyword', maxFindings });
  scanPatternSet({ text: textContent, findings, definitions: SECRET_PATTERNS, type: 'secret', maxFindings });
  scanPatternSet({ text: textContent, findings, definitions: ID_PATTERNS, type: 'pii', maxFindings });
  scanPatternSet({ text: textContent, findings, definitions: HIGH_RISK_CODE_PATTERNS, type: 'code', maxFindings });
  scanPatternSet({ text: textContent, findings, definitions: OBFUSCATION_PATTERNS, type: 'obfuscation', maxFindings });
  scanUrls({ text: textContent, findings, maxFindings });

  const normalizedFindings = dedupeFindings(findings).slice(0, maxFindings);

  return {
    source: source.source,
    path: source.path,
    mimeType: source.mimeType,
    bytes: source.bytes,
    scannedBytes: source.buffer.length,
    truncated: source.truncated,
    binary: false,
    findings: normalizedFindings,
    summary: summarizeFindings(normalizedFindings),
    warnings: source.truncated
      ? [`扫描内容已截断到 ${source.buffer.length} 字节；若需要更高覆盖率可提高 maxBytes`]
      : [],
  };
}

module.exports = {
  DEFAULT_MAX_SCAN_BYTES,
  DEFAULT_MAX_FINDINGS,
  contentScan,
  isBinaryBuffer,
};
