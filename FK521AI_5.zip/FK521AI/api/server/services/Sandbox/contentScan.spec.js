const { contentScan } = require('./contentScan');

describe('contentScan', () => {
  test('detects secrets and risky code in inline text', async () => {
    const result = await contentScan({
      conversationId: 'spec-conv',
      text: 'password = "supersecret123"\nexec("print(1)")\nhttps://bit.ly/example',
      maxFindings: 20,
    });

    expect(result.binary).toBe(false);
    expect(result.findings.some((finding) => finding.subtype === 'generic_assignment_secret')).toBe(true);
    expect(result.findings.some((finding) => finding.subtype === 'python_exec')).toBe(true);
    expect(result.findings.some((finding) => finding.subtype === 'suspicious_url')).toBe(true);
  });
});
