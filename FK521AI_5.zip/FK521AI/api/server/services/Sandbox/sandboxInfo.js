const fs = require('fs/promises');
const path = require('path');
const { ensureConversationSandbox, buildSandboxScope } = require('./paths');
const { WORKSPACE_VIRTUAL_PATHS } = require('~/server/services/Platform/runtimeContext');
const { getRuntimePolicySnapshot } = require('~/server/services/RuntimePolicy');
const { assertAdmin } = require('./requester');
const { getSandboxIsolationConfig } = require('./isolation');

const DEFAULT_TIMEOUT_MS = Number(process.env.FK521_SANDBOX_TIMEOUT_MS || 20000);

async function safeReadText(filePath) {
  try {
    return (await fs.readFile(filePath, 'utf8')).trim();
  } catch (_error) {
    return '';
  }
}

async function readCgroupMemory() {
  const currentRaw = await safeReadText('/sys/fs/cgroup/memory.current');
  const maxRaw = await safeReadText('/sys/fs/cgroup/memory.max');

  const current = /^\d+$/.test(currentRaw) ? Number(currentRaw) : null;
  const limit = /^\d+$/.test(maxRaw) ? Number(maxRaw) : null;
  return {
    currentBytes: current,
    limitBytes: limit,
    availableBytes: current != null && limit != null ? Math.max(0, limit - current) : null,
    source: current != null || limit != null ? 'cgroup_v2' : 'process_only',
  };
}

async function statFsBytes(targetPath) {
  if (typeof fs.statfs !== 'function') {
    return null;
  }
  try {
    const stats = await fs.statfs(targetPath);
    return {
      totalBytes: Number(stats.blocks || 0) * Number(stats.bsize || 0),
      availableBytes: Number(stats.bavail || 0) * Number(stats.bsize || 0),
      files: Number(stats.files || 0),
      filesFree: Number(stats.ffree || 0),
    };
  } catch (_error) {
    return null;
  }
}

function classifyRatio(ratio) {
  if (ratio == null || !Number.isFinite(ratio)) {
    return 'unknown';
  }
  if (ratio <= 0.1) {
    return 'critical';
  }
  if (ratio <= 0.2) {
    return 'low';
  }
  if (ratio <= 0.4) {
    return 'constrained';
  }
  return 'sufficient';
}

function classifyTimeout(remainingMs) {
  if (!Number.isFinite(remainingMs)) {
    return 'unknown';
  }
  if (remainingMs <= 5_000) {
    return 'critical';
  }
  if (remainingMs <= 15_000) {
    return 'low';
  }
  if (remainingMs <= 60_000) {
    return 'constrained';
  }
  return 'sufficient';
}

function resolveDeadline() {
  const explicitDeadlineMs = Number(process.env.FK521_SANDBOX_DEADLINE_AT_MS || 0);
  if (Number.isFinite(explicitDeadlineMs) && explicitDeadlineMs > 0) {
    return {
      configuredTimeoutMs: DEFAULT_TIMEOUT_MS,
      countdownAvailable: true,
      remainingTimeoutMs: Math.max(0, explicitDeadlineMs - Date.now()),
      source: 'FK521_SANDBOX_DEADLINE_AT_MS',
    };
  }

  return {
    configuredTimeoutMs: DEFAULT_TIMEOUT_MS,
    countdownAvailable: false,
    remainingTimeoutMs: DEFAULT_TIMEOUT_MS,
    source: 'configured_default',
  };
}

async function sandboxInfo({ conversationId, requester } = {}) {
  assertAdmin(requester, 'sandbox_info');

  const sandboxPaths = ensureConversationSandbox(conversationId, { user: requester?.user });
  const policy = getRuntimePolicySnapshot();
  const isolation = getSandboxIsolationConfig(buildSandboxScope({ user: requester?.user }));
  const cgroupMemory = await readCgroupMemory();

  const workspaceDisk = await statFsBytes(sandboxPaths.workspaceDir);
  const uploadsDisk = await statFsBytes(sandboxPaths.uploadsDir);
  const outputsDisk = await statFsBytes(sandboxPaths.outputsDir);
  const timeout = resolveDeadline();

  const diskRatios = [workspaceDisk, uploadsDisk, outputsDisk]
    .filter(Boolean)
    .map((item) => (item.totalBytes > 0 ? item.availableBytes / item.totalBytes : null))
    .filter((value) => value != null);
  const memoryRatio =
    cgroupMemory.limitBytes && cgroupMemory.availableBytes != null
      ? cgroupMemory.availableBytes / cgroupMemory.limitBytes
      : null;

  return {
    runtime: {
      kind: 'conversation_isolated_workspace',
      conversationId: String(conversationId),
      hostVisibility: false,
      adminOnly: true,
    },
    workspace: {
      virtualRoots: Object.values(WORKSPACE_VIRTUAL_PATHS),
      status: 'available',
    },
    disk: {
      status: classifyRatio(diskRatios.length ? Math.min(...diskRatios) : null),
      source: 'statfs',
      note: 'desensitized',
    },
    memory: {
      status: classifyRatio(memoryRatio),
      source: cgroupMemory.source,
      note: 'desensitized',
    },
    timeout: {
      status: classifyTimeout(timeout.remainingTimeoutMs),
      countdownAvailable: timeout.countdownAvailable,
      source: timeout.source,
      note: 'desensitized',
    },
    policy: {
      policyVersion: policy.policyVersion,
      policySnapshotId: policy.snapshotId,
      routerModel: policy.routerModel,
    },
    security: {
      singleDirectionDataFlow: true,
      sideChannelHardened: true,
      realtimePolicyCheckPerCall: true,
      forbiddenCapabilities: ['shell_exec', 'system_command', 'network_bind'],
      runtimeClass: isolation.runtimeClassHint,
      usernsMode: isolation.usernsMode || 'daemon-default',
      expectRootless: isolation.expectRootless,
      expectUsernsRemap: isolation.expectUsernsRemap,
      perUserUidGid: true,
      networkIsolation: isolation.internalBridge ? 'per_task_internal_bridge' : 'per_task_bridge',
    },
    paths: {
      workspaceRoot: path.basename(sandboxPaths.workspaceDir),
      uploadsRoot: path.basename(sandboxPaths.uploadsDir),
      outputsRoot: path.basename(sandboxPaths.outputsDir),
    },
  };
}

module.exports = {
  sandboxInfo,
  classifyRatio,
  classifyTimeout,
};
