const { getSandboxIsolationConfig, getSandboxOwnership } = require('./isolation');

describe('Sandbox isolation helpers', () => {
  afterEach(() => {
    delete process.env.FK521_SANDBOX_UID_BASE;
    delete process.env.FK521_SANDBOX_UID_SPAN;
    delete process.env.FK521_SANDBOX_GID_BASE;
    delete process.env.FK521_SANDBOX_GID_SPAN;
    delete process.env.FK521_SANDBOX_RUNTIME;
    delete process.env.FK521_SANDBOX_DOCKER_USERNS_MODE;
    delete process.env.FK521_SANDBOX_INTERNAL_BRIDGE;
  });

  test('derives stable per-user ownership in unprivileged range', () => {
    const ownershipA = getSandboxOwnership({ tenantSegment: 'tenant-a', userSegment: 'user-a' });
    const ownershipB = getSandboxOwnership({ tenantSegment: 'tenant-a', userSegment: 'user-a' });
    const ownershipC = getSandboxOwnership({ tenantSegment: 'tenant-a', userSegment: 'user-b' });

    expect(ownershipA).toEqual(ownershipB);
    expect(ownershipA.uid).toBeGreaterThanOrEqual(1000);
    expect(ownershipA.gid).toBeGreaterThanOrEqual(1000);
    expect(ownershipC.uid).not.toBe(ownershipA.uid);
  });

  test('reads runtime and network hardening flags from environment', () => {
    process.env.FK521_SANDBOX_RUNTIME = 'runsc';
    process.env.FK521_SANDBOX_DOCKER_USERNS_MODE = 'host';
    process.env.FK521_SANDBOX_INTERNAL_BRIDGE = 'true';

    const config = getSandboxIsolationConfig({ tenantSegment: 'tenant-a', userSegment: 'user-a' });

    expect(config.runtime).toBe('runsc');
    expect(config.runtimeClassHint).toBe('runsc');
    expect(config.usernsMode).toBe('host');
    expect(config.internalBridge).toBe(true);
  });
});
