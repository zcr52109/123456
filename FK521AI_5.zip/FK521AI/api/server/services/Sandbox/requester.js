const { SystemRoles } = require('fk521ai-data-provider');

function createSandboxAccessError(message, code = 'SANDBOX_ACCESS_DENIED', status = 403, details = {}) {
  const error = new Error(message);
  error.code = code;
  error.status = status;
  error.details = details;
  return error;
}

function isAdminUser(user = null) {
  const primaryRole = String(user?.role || '').trim().toUpperCase();
  if (primaryRole && primaryRole === SystemRoles.ADMIN) {
    return true;
  }

  const roles = Array.isArray(user?.roles) ? user.roles : [];
  return roles.some((role) => String(role || '').trim().toUpperCase() === SystemRoles.ADMIN);
}

function buildRequesterContext(req = null) {
  const user = req?.user || null;
  return {
    req,
    user,
    principalId: String(user?.id || user?._id || 'anonymous'),
    isAuthenticated: Boolean(user?.id || user?._id),
    isAdmin: isAdminUser(user),
  };
}

function assertAdmin(requester = null, action = 'admin_only_tool') {
  if (requester?.isAdmin) {
    return true;
  }

  throw createSandboxAccessError('该接口仅管理员可用', 'SANDBOX_ADMIN_REQUIRED', 403, {
    action,
  });
}

module.exports = {
  createSandboxAccessError,
  isAdminUser,
  buildRequesterContext,
  assertAdmin,
};
