const fs = require('fs');
const fsp = require('fs/promises');
const os = require('os');
const path = require('path');

jest.mock('mime-types', () => ({ lookup: jest.fn(() => 'text/plain') }), { virtual: true });
jest.mock('@fk521ai/data-schemas', () => ({ logger: { error: jest.fn() } }), { virtual: true });
jest.mock('./runtimeContract', () => ({
  SANDBOX_PATHS: {
    uploads: '/workspace/uploads',
    workspace: '/workspace/workdir',
    projects: '/workspace/projects',
    outputs: '/workspace/outputs',
    manifests: '/workspace/manifests',
    runtimeCapabilities: '/runtime/capabilities.json',
    capabilityManifest: '/workspace/manifests/.sandbox-capabilities.json',
  },
}));

const { collectGeneratedFiles, buildSandboxIdentity, createTaskUploadShortcuts } = require('./dockerExecutor');

describe('Sandbox docker executor helpers', () => {


  test('buildSandboxIdentity derives isolated per-task network identity and stable per-user uid/gid mapping', () => {
    const identity = buildSandboxIdentity({
      conversationId: 'convo-1',
      taskId: 'task-1',
      authContext: { user: { id: 'user-1', tenantId: 'tenant-1' } },
    });

    expect(identity.containerName).toMatch(/^fk521ai-sbx-/);
    expect(identity.networkName).toMatch(/^fk521ai-sbx-net-/);
    expect(identity.containerUid).toBeGreaterThanOrEqual(1000);
    expect(identity.containerGid).toBeGreaterThanOrEqual(1000);
    expect(identity.labels['fk521.sandbox.tenant']).toBe('tenant-1');
    expect(identity.labels['fk521.sandbox.user']).toBe('user-1');
    expect(identity.environment.FK521_SANDBOX_USER_ID).toBe('user-1');
    expect(identity.environment.FK521_SANDBOX_TENANT_ID).toBe('tenant-1');

    const sameUserOtherTask = buildSandboxIdentity({
      conversationId: 'convo-1',
      taskId: 'task-2',
      authContext: { user: { id: 'user-1', tenantId: 'tenant-1' } },
    });

    expect(sameUserOtherTask.networkName).not.toBe(identity.networkName);
    expect(sameUserOtherTask.containerUid).toBe(identity.containerUid);
    expect(sameUserOtherTask.containerGid).toBe(identity.containerGid);
  });


  test('createTaskUploadShortcuts exposes uploads in the task working directory', async () => {
    const tempRoot = await fsp.mkdtemp(path.join(os.tmpdir(), 'fk521-task-uploads-'));
    const uploadsDir = path.join(tempRoot, 'uploads');
    const taskDir = path.join(tempRoot, 'task');

    try {
      await fsp.mkdir(uploadsDir, { recursive: true });
      await fsp.mkdir(taskDir, { recursive: true });
      await fsp.writeFile(path.join(uploadsDir, 'project.zip'), 'zip-bytes');
      await fsp.writeFile(path.join(taskDir, 'main.py'), 'print("ok")');

      const shortcuts = await createTaskUploadShortcuts({ uploadsDir, taskDir });
      const shortcutNames = shortcuts.map((shortcut) => shortcut.filename);

      expect(shortcutNames).toContain('uploads');
      expect(shortcutNames).toContain('project.zip');
      const fileShortcut = fs.lstatSync(path.join(taskDir, 'project.zip'));
      expect(fileShortcut.isSymbolicLink() || fileShortcut.isFile()).toBe(true);

      const uploadShortcut = fs.lstatSync(path.join(taskDir, 'uploads'));
      expect(uploadShortcut.isSymbolicLink() || uploadShortcut.isDirectory()).toBe(true);
    } finally {
      await fsp.rm(tempRoot, { recursive: true, force: true });
    }
  });

  test('collectGeneratedFiles preserves taskId in workspace task download paths', () => {
    const files = collectGeneratedFiles({
      beforeTaskFiles: [],
      beforeOutputFiles: [],
      afterTaskFiles: [
        {
          fullPath: '/tmp/task/result.json',
          relativePath: 'result.json',
          mtimeMs: 100,
          size: 12,
        },
      ],
      afterOutputFiles: [],
      entryFilename: 'main.py',
      taskId: 'task-123',
    });

    expect(files).toHaveLength(1);
    expect(files[0].sandboxRelativePath).toBe('workspace/tasks/task-123/result.json');
  });
});
