const fs = require('fs');
const fsp = require('fs/promises');
const os = require('os');
const path = require('path');

jest.mock('~/models', () => ({
  getFiles: jest.fn(),
}));

jest.mock('@fk521ai/data-schemas', () => ({
  logger: {
    warn: jest.fn(),
  },
}));

jest.mock('./runtimeContract', () => ({
  SANDBOX_PATHS: {
    uploads: '/workspace/uploads',
    projects: '/workspace/projects',
    outputs: '/workspace/outputs',
  },
  ensureSandboxCapabilityManifest: jest.fn().mockResolvedValue(undefined),
}));

jest.mock('./projectArchives', () => ({
  prepareProjectArchives: jest.fn().mockResolvedValue({
    projectArchives: [],
    archiveFailures: [],
  }),
  buildProjectArchivesContext: jest.fn(() => ''),
}));

const { getFiles } = require('~/models');

describe('syncConversationFilesToSandbox', () => {
  let tempRoot;
  let uploadsRoot;

  beforeEach(async () => {
    jest.resetModules();
    getFiles.mockReset();
    tempRoot = await fsp.mkdtemp(path.join(os.tmpdir(), 'fk521-uploads-'));
    uploadsRoot = path.join(tempRoot, 'uploads');
    await fsp.mkdir(uploadsRoot, { recursive: true });
    process.env.FK521_SANDBOX_BASE_DIR = path.join(tempRoot, 'sandboxes');

    jest.doMock('~/config/paths', () => ({
      uploads: uploadsRoot,
      publicPath: path.join(tempRoot, 'public'),
      imageOutput: path.join(tempRoot, 'public', 'images'),
    }));
  });

  afterEach(async () => {
    delete process.env.FK521_SANDBOX_BASE_DIR;
    await fsp.rm(tempRoot, { recursive: true, force: true });
    jest.resetModules();
  });

  it('copies /uploads/... files into the workspace sandbox', async () => {
    const userDir = path.join(uploadsRoot, 'user-1');
    await fsp.mkdir(userDir, { recursive: true });
    const storedFile = path.join(userDir, '测试.zip');
    await fsp.writeFile(storedFile, 'zip-bytes');

    getFiles.mockResolvedValue([
      {
        file_id: 'file-1',
        filename: '测试.zip',
        filepath: '/uploads/user-1/测试.zip',
        type: 'application/zip',
        source: 'local',
        createdAt: new Date('2026-04-10T07:00:00.000Z'),
      },
    ]);

    const { syncConversationFilesToSandbox } = require('./uploads');
    const result = await syncConversationFilesToSandbox({
      conversationId: 'conversation-1',
      conversationFileIds: ['file-1'],
      user: { id: 'user-1' },
    });

    expect(result.syncedFiles).toHaveLength(1);
    expect(result.skippedFiles).toHaveLength(0);
    expect(result.syncedFiles[0].virtualPath).toMatch(/^\/workspace\/uploads\//);
    expect(result.syncedFiles[0].workdirPath).toMatch(/^\/workspace\/workdir\/uploads\//);
    expect(fs.existsSync(result.syncedFiles[0].hostPath)).toBe(true);
    expect(fs.existsSync(result.syncedFiles[0].workdirHostPath)).toBe(true);

    const manifestContent = JSON.parse(await fsp.readFile(result.uploadManifest.hostPath, 'utf8'));
    expect(manifestContent.files).toHaveLength(1);
    expect(manifestContent.files[0].originalName).toBe('测试.zip');
    expect(manifestContent.files[0].workdirPath).toMatch(/^\/workspace\/workdir\/uploads\//);
  });

  it('falls back to user-owned file lookup when the upload is not yet bound to a conversation', async () => {
    const userDir = path.join(uploadsRoot, 'user-1');
    await fsp.mkdir(userDir, { recursive: true });
    const storedFile = path.join(userDir, 'project.zip');
    await fsp.writeFile(storedFile, 'zip-bytes');

    getFiles
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([
        {
          file_id: 'file-2',
          filename: 'project.zip',
          filepath: '/uploads/user-1/project.zip',
          type: 'application/zip',
          source: 'local',
          createdAt: new Date('2026-04-11T07:00:00.000Z'),
        },
      ]);

    const { syncConversationFilesToSandbox } = require('./uploads');
    const result = await syncConversationFilesToSandbox({
      conversationId: 'conversation-2',
      conversationFileIds: ['file-2'],
      user: { id: 'user-1' },
    });

    expect(getFiles).toHaveBeenNthCalledWith(
      1,
      { file_id: { $in: ['file-2'] }, user: 'user-1', conversationId: 'conversation-2' },
      null,
      { text: 0 },
    );
    expect(getFiles).toHaveBeenNthCalledWith(
      2,
      { file_id: { $in: ['file-2'] }, user: 'user-1' },
      null,
      { text: 0 },
    );
    expect(result.syncedFiles).toHaveLength(1);
    expect(result.syncedFiles[0].workdirPath).toMatch(/^\/workspace\/workdir\/uploads\//);
  });
});
