const fsp = require('fs/promises');
const path = require('path');
const { logger } = require('@fk521ai/data-schemas');
const { ensureConversationSandbox, sanitizeSegment } = require('./paths');
const { SANDBOX_PATHS } = require('./runtimeContract');
const {
  detectArchiveFormat,
  isSupportedArchive,
  extractArchive,
  getSupportedArchiveSummary,
} = require('./archiveUtils');

const DEFAULT_TREE_MAX_DEPTH = Number(process.env.FK521_PROJECT_ARCHIVE_TREE_MAX_DEPTH || 4);
const DEFAULT_TREE_MAX_ENTRIES = Number(process.env.FK521_PROJECT_ARCHIVE_TREE_MAX_ENTRIES || 160);
const ARCHIVE_STATE_FILENAME = '.fk521-archive-state.json';
const PROJECT_ARCHIVE_MANIFEST_FILENAME = 'project-archives.json';

async function rmrf(targetPath) {
  await fsp.rm(targetPath, { recursive: true, force: true });
}

async function writeArchiveState(stateFilePath, state) {
  await fsp.writeFile(stateFilePath, JSON.stringify(state, null, 2), 'utf8');
}

async function readArchiveState(stateFilePath) {
  try {
    const raw = await fsp.readFile(stateFilePath, 'utf8');
    return JSON.parse(raw);
  } catch (_error) {
    return null;
  }
}

async function collectTopLevelProjectRoot(extractDir) {
  const entries = await fsp.readdir(extractDir, { withFileTypes: true });
  const visibleEntries = entries.filter((entry) => !entry.name.startsWith('.'));

  if (visibleEntries.length === 1 && visibleEntries[0].isDirectory()) {
    return path.join(extractDir, visibleEntries[0].name);
  }

  return extractDir;
}

function formatTreeLine(depth, name, isDirectory) {
  const indent = '  '.repeat(Math.max(depth, 0));
  return `${indent}${name}${isDirectory ? '/' : ''}`;
}

async function buildTreeLines(_rootDir, currentDir, depth, lines, limits) {
  if (depth > limits.maxDepth || lines.length >= limits.maxEntries) {
    return;
  }

  let entries = [];
  try {
    entries = await fsp.readdir(currentDir, { withFileTypes: true });
  } catch (_error) {
    return;
  }

  const visibleEntries = entries
    .filter((entry) => !entry.name.startsWith('.'))
    .sort((a, b) => {
      if (a.isDirectory() && !b.isDirectory()) return -1;
      if (!a.isDirectory() && b.isDirectory()) return 1;
      return a.name.localeCompare(b.name);
    });

  for (const entry of visibleEntries) {
    if (lines.length >= limits.maxEntries) {
      return;
    }

    const fullPath = path.join(currentDir, entry.name);
    lines.push(formatTreeLine(depth, entry.name, entry.isDirectory()));

    if (entry.isDirectory()) {
      await buildTreeLines(_rootDir, fullPath, depth + 1, lines, limits);
    }
  }
}

async function createProjectTree(projectRoot) {
  const rootName = path.basename(projectRoot);
  const lines = [`${rootName}/`];

  await buildTreeLines(projectRoot, projectRoot, 1, lines, {
    maxDepth: DEFAULT_TREE_MAX_DEPTH,
    maxEntries: DEFAULT_TREE_MAX_ENTRIES,
  });

  if (lines.length >= DEFAULT_TREE_MAX_ENTRIES) {
    lines.push('  ...');
  }

  return lines.join('\n');
}

async function extractProjectArchive({ file, projectsDir }) {
  const sourceStat = await fsp.stat(file.hostPath);
  const archiveName = String(file.filename || 'project.zip');
  const archiveFormat = detectArchiveFormat(file);
  if (!archiveFormat) {
    throw new Error(`Unsupported archive format for ${archiveName}`);
  }

  const baseName = archiveName.replace(/(\.tar\.gz|\.tgz|\.tar\.bz2|\.tbz2|\.tar\.xz|\.txz|\.tar|\.zip)$/i, '') || 'project';
  const safeFolder = sanitizeSegment(baseName, 'project');
  const extractDir = path.join(projectsDir, safeFolder);
  const statePath = path.join(extractDir, ARCHIVE_STATE_FILENAME);
  const nextState = {
    filename: archiveName,
    archiveFormat: archiveFormat.id,
    file_id: file.file_id || null,
    bytes: sourceStat.size,
    mtimeMs: file.sourceMtimeMs || sourceStat.mtimeMs,
    sourcePath: file.sourcePath || file.hostPath,
  };

  const previousState = await readArchiveState(statePath);
  if (previousState && JSON.stringify(previousState) === JSON.stringify(nextState)) {
    const projectRoot = await collectTopLevelProjectRoot(extractDir);
    const tree = await createProjectTree(projectRoot);
    return {
      archiveFilename: archiveName,
      archiveFormat: archiveFormat.id,
      file_id: file.file_id || null,
      archivePath: file.path,
      extractSandboxPath: `${SANDBOX_PATHS.projects}/${path.basename(extractDir)}`,
      projectRootSandboxPath: `${SANDBOX_PATHS.projects}/${path.relative(projectsDir, projectRoot).replace(/\\/g, '/')}`,
      projectRootHostPath: projectRoot,
      tree,
      reused: true,
    };
  }

  await rmrf(extractDir);
  await fsp.mkdir(extractDir, { recursive: true });
  await extractArchive({
    archivePath: file.hostPath,
    destinationDir: extractDir,
    format: archiveFormat.id,
  });
  await writeArchiveState(statePath, nextState);

  const projectRoot = await collectTopLevelProjectRoot(extractDir);
  const tree = await createProjectTree(projectRoot);

  return {
    archiveFilename: archiveName,
    archiveFormat: archiveFormat.id,
    file_id: file.file_id || null,
    archivePath: file.path,
    extractSandboxPath: `${SANDBOX_PATHS.projects}/${path.basename(extractDir)}`,
    projectRootSandboxPath: `${SANDBOX_PATHS.projects}/${path.relative(projectsDir, projectRoot).replace(/\\/g, '/')}`,
    projectRootHostPath: projectRoot,
    tree,
    reused: false,
  };
}

async function writeProjectArchiveManifest({ conversationId, projectArchives = [], archiveFailures = [], authContext = {} }) {
  const { workspaceDir } = ensureConversationSandbox(conversationId, authContext);
  const manifestsDir = path.join(workspaceDir, 'manifests');
  await fsp.mkdir(manifestsDir, { recursive: true });

  const hostPath = path.join(manifestsDir, PROJECT_ARCHIVE_MANIFEST_FILENAME);
  const primaryProject = Array.isArray(projectArchives) && projectArchives.length > 0 ? projectArchives[0] : null;
  const manifest = {
    version: 1,
    generatedAt: new Date().toISOString(),
    primaryProjectRoot: primaryProject?.projectRootSandboxPath || null,
    primaryArchive: primaryProject?.archiveFilename || null,
    projects: (projectArchives || []).map((project) => ({
      file_id: project.file_id || null,
      archiveFilename: project.archiveFilename,
      archiveFormat: project.archiveFormat,
      archivePath: project.archivePath,
      extractedDir: project.extractSandboxPath,
      projectRoot: project.projectRootSandboxPath,
      reused: Boolean(project.reused),
      tree: project.tree,
    })),
    failures: (archiveFailures || []).map((failure) => ({
      archiveFilename: failure.archiveFilename || 'unknown',
      archivePath: failure.archivePath || null,
      reason: failure.reason || 'unknown archive extraction error',
    })),
  };

  await fsp.writeFile(hostPath, JSON.stringify(manifest, null, 2), 'utf8');
  return {
    hostPath,
    virtualPath: `${SANDBOX_PATHS.manifests}/${PROJECT_ARCHIVE_MANIFEST_FILENAME}`,
    manifest,
  };
}

async function prepareProjectArchives({ conversationId, syncedFiles = [], authContext = {} }) {
  const archives = (syncedFiles || []).filter((file) => file?.hostPath && isSupportedArchive(file));
  if (archives.length === 0) {
    return {
      projectArchives: [],
      archiveFailures: [],
      manifestInfo: null,
    };
  }

  const { projectsDir } = ensureConversationSandbox(conversationId, authContext);
  await fsp.mkdir(projectsDir, { recursive: true });

  const prepared = [];
  const archiveFailures = [];
  for (const archive of archives) {
    try {
      prepared.push(await extractProjectArchive({ file: archive, projectsDir }));
    } catch (error) {
      logger.warn(
        `[project archives] Failed to extract ${archive.filename} for conversation ${conversationId}: ${error.message}`,
      );
      archiveFailures.push({
        archiveFilename: archive.filename,
        archivePath: archive.path,
        reason: error?.message || 'unknown archive extraction error',
      });
    }
  }

  const manifestInfo = await writeProjectArchiveManifest({
    conversationId,
    projectArchives: prepared,
    archiveFailures,
    authContext,
  });

  return {
    projectArchives: prepared,
    archiveFailures,
    manifestInfo,
  };
}

function buildProjectArchivesContext(projectArchives = [], archiveFailures = [], projectArchiveManifest = null) {
  if ((!Array.isArray(projectArchives) || projectArchives.length === 0) && (!Array.isArray(archiveFailures) || archiveFailures.length === 0)) {
    return '';
  }

  const lines = [
    '<project_archives>',
    '检测到可编辑的项目压缩包，已自动解压到沙箱工作区。',
    '如果用户要你修改项目代码，优先直接在下面的项目根目录里操作，而不是手动再解压 uploads 里的压缩包。',
    `项目压缩包清单: ${projectArchiveManifest?.virtualPath || `${SANDBOX_PATHS.manifests}/${PROJECT_ARCHIVE_MANIFEST_FILENAME}`}`,
    `已支持自动解压格式：${getSupportedArchiveSummary()}`,
    '',
  ];

  for (const project of projectArchives) {
    lines.push(`- Archive: ${project.archiveFilename}`);
    lines.push(`  Format: ${project.archiveFormat}`);
    lines.push(`  Uploaded archive: ${project.archivePath}`);
    lines.push(`  Extracted dir: ${project.extractSandboxPath}`);
    lines.push(`  Project root: ${project.projectRootSandboxPath}`);
    lines.push('  Tree:');
    for (const treeLine of String(project.tree || '').split('\n')) {
      lines.push(`    ${treeLine}`);
    }
    lines.push('');
  }

  if (Array.isArray(archiveFailures) && archiveFailures.length > 0) {
    lines.push('Archive extraction failures:');
    for (const failure of archiveFailures) {
      lines.push(`- Archive: ${failure.archiveFilename || 'unknown'}`);
      if (failure.archivePath) {
        lines.push(`  Uploaded archive: ${failure.archivePath}`);
      }
      lines.push(`  Reason: ${failure.reason || 'unknown archive extraction error'}`);
    }
    lines.push('');
  }

  lines.push('项目工作流要求：');
  lines.push(`- 修改代码时在 ${SANDBOX_PATHS.projects}/... 下操作。`);
  lines.push('- 当用户要求“完善项目 / 改代码 / 修 bug / 加功能”时，必要时调用代码执行工具在项目根目录内直接写文件。');
  lines.push('- 如需验证，可在沙箱里运行最小必要的安装、测试或构建命令；若环境不足，明确说明验证受限。');
  lines.push('- 如需查看压缩包内容或手动重解压，优先使用沙箱里的标准归档命令或现有项目目录，而不是重复编写复杂的自定义解压逻辑。');
  lines.push('- 不要仅根据压缩包文件名、附件 ID 或外层元数据推断项目内容；必须先看目录树或关键文件。');
  lines.push('- 如果自动解压失败，先报告上面的具体失败原因，再决定是否手动重解压。');
  lines.push(`- 完成后，把最终项目重新打包到 ${SANDBOX_PATHS.outputs}/<project-name>-updated.zip 或其他受支持归档格式。优先在沙箱里直接生成最终归档。`);
  lines.push('- 返回最终归档作为附件或下载链接；如果还生成了补丁、日志或报告，也可以一并放到 outputs。');
  lines.push('- 禁止回复“我没有文件存储服务器”或“我不能创建真实网络文件链接”；当前运行时已经具备输出文件与下载链接能力。');
  lines.push('</project_archives>');

  return lines.join('\n');
}

module.exports = {
  prepareProjectArchives,
  buildProjectArchivesContext,
  isSupportedArchive,
  writeProjectArchiveManifest,
};
