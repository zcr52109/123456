const fs = require('fs');
const fsp = require('fs/promises');
const os = require('os');
const path = require('path');

describe('Sandbox paths', () => {
  let tempRoot;
  let pathsModule;

  beforeEach(() => {
    jest.resetModules();
    tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'fk521-paths-'));
    process.env.FK521_SANDBOX_BASE_DIR = tempRoot;
    pathsModule = require('./paths');
  });

  afterEach(() => {
    delete process.env.FK521_SANDBOX_BASE_DIR;
    fs.rmSync(tempRoot, { recursive: true, force: true });
  });

  test('classifies downloadable task files under workspace/tasks', () => {
    expect(pathsModule.classifySandboxRelativePath('workspace/tasks/task-1/result.txt')).toEqual({
      normalizedPath: 'workspace/tasks/task-1/result.txt',
      rootId: 'workspace_tasks',
      downloadAllowed: true,
    });
  });

  test('rejects path traversal attempts during normalization', () => {
    expect(() => pathsModule.normalizeRelativeSandboxPath('../secret.txt')).toThrow('非法的 sandbox 文件路径');
  });

  test('resolves outputs files but blocks upload-root downloads', async () => {
    const convoPaths = pathsModule.ensureConversationSandbox('convo-1');
    const outputFile = path.join(convoPaths.outputsDir, 'report.txt');
    await fsp.writeFile(outputFile, 'ok', 'utf8');

    const resolved = await pathsModule.resolveConversationFile('convo-1', 'outputs/report.txt');
    expect(resolved.normalizedPath).toBe('outputs/report.txt');
    expect(resolved.classification.rootId).toBe('outputs');
    expect(resolved.absolutePath).toBe(await fsp.realpath(outputFile));

    await expect(pathsModule.resolveConversationFile('convo-1', 'uploads/private.txt')).rejects.toMatchObject({
      code: 'SANDBOX_ROOT_NOT_ALLOWED',
      reason: 'ROOT_NOT_ALLOWED',
    });
  });


  test('isolates sandbox roots by tenant and user segments', () => {
    const pathsA = pathsModule.getConversationPaths('convo-iso', {
      user: { id: 'user-a', tenantId: 'tenant-a' },
    });
    const pathsB = pathsModule.getConversationPaths('convo-iso', {
      user: { id: 'user-b', tenantId: 'tenant-a' },
    });

    expect(pathsA.rootDir).toContain(path.join('tenants', 'tenant-a', 'users', 'user-a'));
    expect(pathsB.rootDir).toContain(path.join('tenants', 'tenant-a', 'users', 'user-b'));
    expect(pathsA.rootDir).not.toEqual(pathsB.rootDir);
  });

  test('blocks symlink escape outside sandbox root', async () => {
    const convoPaths = pathsModule.ensureConversationSandbox('convo-2');
    const externalDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fk521-external-'));
    const externalFile = path.join(externalDir, 'outside.txt');
    const symlinkPath = path.join(convoPaths.outputsDir, 'outside-link.txt');

    await fsp.writeFile(externalFile, 'outside', 'utf8');
    await fsp.symlink(externalFile, symlinkPath);

    await expect(
      pathsModule.resolveConversationFile('convo-2', 'outputs/outside-link.txt'),
    ).rejects.toMatchObject({
      code: 'SANDBOX_SYMLINK_ESCAPE',
      reason: 'SYMLINK_ESCAPE',
    });

    fs.rmSync(externalDir, { recursive: true, force: true });
  });
});
