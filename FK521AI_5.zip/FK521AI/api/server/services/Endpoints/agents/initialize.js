const { logger } = require('@fk521ai/data-schemas');
const { createContentAggregator } = require('@fk521ai/agents');
const {
  initializeAgent,
  validateAgentModel,
  createEdgeCollector,
  filterOrphanedEdges,
  GenerationJobManager,
  getCustomEndpointConfig,
  createSequentialChainEdges,
} = require('@fk521ai/api');
const {
  ResourceType,
  PermissionBits,
  EModelEndpoint,
  isAgentsEndpoint,
  isEphemeralAgentId,
  encodeEphemeralAgentId,
} = require('fk521ai-data-provider');
const {
  createToolEndCallback,
  getDefaultHandlers,
} = require('~/server/controllers/agents/callbacks');
const { loadAgentTools, loadToolsForExecution } = require('~/server/services/ToolService');
const { filterFilesByAgentAccess } = require('~/server/services/Files/permissions');
const { getModelsConfig } = require('~/server/controllers/ModelController');
const { checkPermission } = require('~/server/services/PermissionService');
const AgentClient = require('~/server/controllers/agents/client');
const { processAddedConvo } = require('./addedConvo');
const { logViolation } = require('~/cache');
const db = require('~/models');


const AUTO_AGENT_COMPLEXITY_KEYWORDS = Object.freeze([
  '修复',
  '重构',
  'debug',
  '排查',
  'bug',
  '错误',
  '报错',
  '架构',
  '设计',
  '优化',
  '实现',
  '编码',
  '代码',
  '系统',
  '路由',
  '缓存',
  '多 ai',
  'agent',
  'workflow',
  'pipeline',
  'integrate',
  'refactor',
  'architecture',
  'multi-agent',
  'orchestr',
  'implement',
  'fix',
  'plan',
  'review',
  'audit',
]);

const AUTO_AGENT_ROLE_PROMPTS = Object.freeze({
  coordinator: [
    'You are the coordinator for a shared multi-agent run.',
    'Briefly decompose the request into execution steps, surface constraints, and hand off to the next specialist.',
    'Do not produce the final answer unless there is no downstream specialist.',
    'Keep your output concise, structured, and focused on task decomposition.',
  ].join(' '),
  planner: [
    'You are the planning specialist in a shared multi-agent run.',
    'Produce the best task plan, identify assumptions, interfaces, dependencies, and acceptance criteria.',
    'When code changes are requested, call out touched files, risk areas, and verification steps.',
    'Do not write the final user-facing answer.',
  ].join(' '),
  reviewer: [
    'You are the review specialist in a shared multi-agent run.',
    'Audit the plan and intermediate results for correctness, missing edge cases, regression risk, security, and hidden assumptions.',
    'Return concrete corrections and quality gates for the implementation specialist.',
    'Do not write the final user-facing answer.',
  ].join(' '),
  implementer: [
    'You are the implementation and final-answer specialist in a shared multi-agent run.',
    'Use the shared context, the planner output, and the reviewer feedback to produce the strongest final result.',
    'When code is involved, prioritize correct implementation details, verification notes, and concise delivery.',
    'This role is responsible for the final user-facing answer.',
  ].join(' '),
});

const AUTO_AGENT_CHAIN_PROMPT = [
  'Shared multi-agent context follows.',
  'Conversation and prior agent outputs:',
  '{convo}',
  '',
  'Continue from the accumulated context instead of restarting the analysis.',
  'Add only your role-specific contribution and preserve important decisions from earlier agents.',
].join('\n');

function getLatestUserText(messages = []) {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const message = messages[i];
    if (!message || message.role !== 'user') {
      continue;
    }
    const content = message.text ?? message.content ?? '';
    if (typeof content === 'string' && content.trim()) {
      return content.trim();
    }
    if (Array.isArray(content)) {
      const text = content
        .map((part) => {
          if (typeof part === 'string') {
            return part;
          }
          if (part?.type === 'text') {
            return part.text;
          }
          return '';
        })
        .join(' ')
        .trim();
      if (text) {
        return text;
      }
    }
  }
  return '';
}


function resolveCollaborativeMode({ req, endpointOption, primaryAgent }) {
  const rawValue =
    req?.body?.agentMode ??
    req?.body?.collaborationMode ??
    req?.body?.multiAgentMode ??
    endpointOption?.collaborationMode ??
    primaryAgent?.collaborationMode ??
    primaryAgent?.metadata?.collaborationMode;

  const normalized = String(rawValue || '').trim().toLowerCase();
  if (!normalized) {
    return 'auto';
  }

  if (['single', 'single-agent', 'solo', 'off', 'disabled', 'false', '0'].includes(normalized)) {
    return 'single';
  }

  if (['multi', 'multi-agent', 'collaborative', 'team', 'on', 'enabled', 'true', '1'].includes(normalized)) {
    return 'collaborative';
  }

  return 'auto';
}

function shouldUseCollaborativeAgents({ req, endpointOption, primaryAgent }) {
  if (!req || !primaryAgent || !endpointOption) {
    return false;
  }

  const hasExistingGraph =
    (Array.isArray(primaryAgent.edges) && primaryAgent.edges.length > 0) ||
    (Array.isArray(primaryAgent.agent_ids) && primaryAgent.agent_ids.length > 0) ||
    (Array.isArray(endpointOption.edges) && endpointOption.edges.length > 0) ||
    (Array.isArray(endpointOption.agent_ids) && endpointOption.agent_ids.length > 0) ||
    req.body?.addedConvo != null;

  if (hasExistingGraph) {
    return false;
  }

  const latestUserText = getLatestUserText(req.body?.messages);
  const normalized = latestUserText.toLowerCase();
  const keywordHits = AUTO_AGENT_COMPLEXITY_KEYWORDS.reduce(
    (count, keyword) => count + (normalized.includes(keyword) ? 1 : 0),
    0,
  );
  const attachmentCount = Array.isArray(req.body?.files) ? req.body.files.length : 0;
  const lineCount = latestUserText ? latestUserText.split(/\n+/).length : 0;
  const bulletCount = (latestUserText.match(/(^|\n)\s*(?:[-*•]|\d+[.)])/g) || []).length;
  const lengthScore = latestUserText.length >= 1200 ? 2 : latestUserText.length >= 600 ? 1 : 0;
  const score = keywordHits + attachmentCount + lineCount / 8 + bulletCount + lengthScore;

  return score >= 6;
}

function appendInstruction(base, addition) {
  const left = String(base || '').trim();
  const right = String(addition || '').trim();
  if (!left) {
    return right;
  }
  if (!right) {
    return left;
  }
  return `${left}\n\n${right}`;
}

function buildAutoCollaborativeAgents(primaryAgent) {
  const endpoint = primaryAgent.provider || EModelEndpoint.openAI;
  const model = primaryAgent.model || primaryAgent.model_parameters?.model || '';
  const baseName = String(primaryAgent.name || primaryAgent.model || 'Agent').trim();
  const baseTools = Array.isArray(primaryAgent.tools) ? [...primaryAgent.tools] : [];

  const plannerId = encodeEphemeralAgentId({
    endpoint,
    model,
    sender: `${baseName}-planner`,
    index: 101,
  });
  const reviewerId = encodeEphemeralAgentId({
    endpoint,
    model,
    sender: `${baseName}-reviewer`,
    index: 102,
  });
  const implementerId = encodeEphemeralAgentId({
    endpoint,
    model,
    sender: `${baseName}-implementer`,
    index: 103,
  });

  return {
    primaryAgent: {
      ...primaryAgent,
      instructions: appendInstruction(primaryAgent.instructions, AUTO_AGENT_ROLE_PROMPTS.coordinator),
    },
    collaborators: [
      {
        ...primaryAgent,
        id: plannerId,
        name: `${baseName} Planner`,
        instructions: appendInstruction(primaryAgent.instructions, AUTO_AGENT_ROLE_PROMPTS.planner),
        tools: baseTools,
      },
      {
        ...primaryAgent,
        id: reviewerId,
        name: `${baseName} Reviewer`,
        instructions: appendInstruction(primaryAgent.instructions, AUTO_AGENT_ROLE_PROMPTS.reviewer),
        tools: baseTools,
      },
      {
        ...primaryAgent,
        id: implementerId,
        name: `${baseName} Implementer`,
        instructions: appendInstruction(primaryAgent.instructions, AUTO_AGENT_ROLE_PROMPTS.implementer),
        tools: baseTools,
      },
    ],
  };
}

/**
 * Creates a tool loader function for the agent.
 * @param {AbortSignal} signal - The abort signal
 * @param {string | null} [streamId] - The stream ID for resumable mode
 * @param {boolean} [definitionsOnly=false] - When true, returns only serializable
 *   tool definitions without creating full tool instances (for event-driven mode)
 */
function createToolLoader(signal, streamId = null, definitionsOnly = false) {
  /**
   * @param {object} params
   * @param {ServerRequest} params.req
   * @param {ServerResponse} params.res
   * @param {string} params.agentId
   * @param {string[]} params.tools
   * @param {string} params.provider
   * @param {string} params.model
   * @param {AgentToolResources} params.tool_resources
   * @returns {Promise<{
   *   tools?: StructuredTool[],
   *   toolContextMap: Record<string, unknown>,
   *   toolDefinitions?: import('@fk521ai/agents').LCTool[],
   *   userMCPAuthMap?: Record<string, Record<string, string>>,
   *   toolRegistry?: import('@fk521ai/agents').LCToolRegistry
   * } | undefined>}
   */
  return async function loadTools({
    req,
    res,
    tools,
    model,
    agentId,
    provider,
    tool_options,
    tool_resources,
  }) {
    const agent = { id: agentId, tools, provider, model, tool_options };
    try {
      return await loadAgentTools({
        req,
        res,
        agent,
        signal,
        streamId,
        tool_resources,
        definitionsOnly,
      });
    } catch (error) {
      logger.error('Error loading tools for agent ' + agentId, error);
    }
  };
}

/**
 * Initializes the AgentClient for a given request/response cycle.
 * @param {Object} params
 * @param {Express.Request} params.req
 * @param {Express.Response} params.res
 * @param {AbortSignal} params.signal
 * @param {Object} params.endpointOption
 */
const initializeClient = async ({ req, res, signal, endpointOption }) => {
  if (!endpointOption) {
    throw new Error('Endpoint option not provided');
  }
  const appConfig = req.config;

  /** @type {string | null} */
  const streamId = req._resumableStreamId || null;

  /** @type {Array<UsageMetadata>} */
  const collectedUsage = [];
  /** @type {ArtifactPromises} */
  const artifactPromises = [];
  const { contentParts, aggregateContent } = createContentAggregator();
  const toolEndCallback = createToolEndCallback({ req, res, artifactPromises, streamId });

  /**
   * Agent context store - populated after initialization, accessed by callback via closure.
   * Maps agentId -> { userMCPAuthMap, agent, tool_resources, toolRegistry, openAIApiKey }
   * @type {Map<string, {
   *   userMCPAuthMap?: Record<string, Record<string, string>>,
   *   agent?: object,
   *   tool_resources?: object,
   *   toolRegistry?: import('@fk521ai/agents').LCToolRegistry,
   *   openAIApiKey?: string
   * }>}
   */
  const agentToolContexts = new Map();

  const toolExecuteOptions = {
    loadTools: async (toolNames, agentId) => {
      const ctx = agentToolContexts.get(agentId) ?? {};
      logger.debug(`[ON_TOOL_EXECUTE] ctx found: ${!!ctx.userMCPAuthMap}, agent: ${ctx.agent?.id}`);
      logger.debug(`[ON_TOOL_EXECUTE] toolRegistry size: ${ctx.toolRegistry?.size ?? 'undefined'}`);

      const result = await loadToolsForExecution({
        req,
        res,
        signal,
        streamId,
        toolNames,
        agent: ctx.agent,
        toolRegistry: ctx.toolRegistry,
        userMCPAuthMap: ctx.userMCPAuthMap,
        tool_resources: ctx.tool_resources,
        actionsEnabled: ctx.actionsEnabled,
      });

      logger.debug(`[ON_TOOL_EXECUTE] loaded ${result.loadedTools?.length ?? 0} tools`);
      return result;
    },
    toolEndCallback,
  };

  const summarizationOptions =
    appConfig?.summarization?.enabled === false ? { enabled: false } : { enabled: true };

  const eventHandlers = getDefaultHandlers({
    res,
    toolExecuteOptions,
    summarizationOptions,
    aggregateContent,
    toolEndCallback,
    collectedUsage,
    streamId,
  });

  if (!endpointOption.agent) {
    throw new Error('No agent promise provided');
  }

  let primaryAgent = await endpointOption.agent;
  delete endpointOption.agent;
  if (!primaryAgent) {
    throw new Error('Agent not found');
  }

  const requestedCollaborationMode = resolveCollaborativeMode({ req, endpointOption, primaryAgent });
  const autoCollaborativeMode =
    requestedCollaborationMode === 'collaborative'
      ? true
      : requestedCollaborationMode === 'single'
        ? false
        : shouldUseCollaborativeAgents({ req, endpointOption, primaryAgent });
  const autoCollaborativeBundle = autoCollaborativeMode
    ? buildAutoCollaborativeAgents(primaryAgent)
    : null;

  if (autoCollaborativeBundle?.primaryAgent) {
    primaryAgent = autoCollaborativeBundle.primaryAgent;
    logger.debug(`[initializeClient] Enabling collaborative agent pipeline (${requestedCollaborationMode})`);
  }

  const modelsConfig = await getModelsConfig(req);
  const validationResult = await validateAgentModel({
    req,
    res,
    modelsConfig,
    logViolation,
    agent: primaryAgent,
  });

  if (!validationResult.isValid) {
    throw new Error(validationResult.error?.message);
  }

  const agentConfigs = new Map();
  const allowedProviders = new Set(appConfig?.endpoints?.[EModelEndpoint.agents]?.allowedProviders);

  /** Event-driven mode: only load tool definitions, not full instances */
  const loadTools = createToolLoader(signal, streamId, true);
  /** @type {Array<MongoFile>} */
  const requestFiles = req.body.files ?? [];
  /** @type {string} */
  const conversationId = req.body.conversationId;
  /** @type {string | undefined} */
  const parentMessageId = req.body.parentMessageId;

  const primaryConfig = await initializeAgent(
    {
      req,
      res,
      loadTools,
      requestFiles,
      conversationId,
      parentMessageId,
      agent: primaryAgent,
      endpointOption,
      allowedProviders,
      isInitialAgent: true,
    },
    {
      getFiles: db.getFiles,
      getUserKey: db.getUserKey,
      getMessages: db.getMessages,
      getConvoFiles: db.getConvoFiles,
      updateFilesUsage: db.updateFilesUsage,
      getUserKeyValues: db.getUserKeyValues,
      getUserCodeFiles: db.getUserCodeFiles,
      getToolFilesByIds: db.getToolFilesByIds,
      getCodeGeneratedFiles: db.getCodeGeneratedFiles,
      filterFilesByAgentAccess: (params) => {
        const endpointConfig = req.config?.endpoints?.[primaryAgent.provider];
        return filterFilesByAgentAccess({ ...params, endpointConfig });
      },
    },
  );

  logger.debug(
    `[initializeClient] Storing tool context for ${primaryConfig.id}: ${primaryConfig.toolDefinitions?.length ?? 0} tools, registry size: ${primaryConfig.toolRegistry?.size ?? '0'}`,
  );
  agentToolContexts.set(primaryConfig.id, {
    agent: primaryAgent,
    toolRegistry: primaryConfig.toolRegistry,
    userMCPAuthMap: primaryConfig.userMCPAuthMap,
    tool_resources: primaryConfig.tool_resources,
    actionsEnabled: primaryConfig.actionsEnabled,
  });

  const agent_ids = primaryConfig.agent_ids;
  let userMCPAuthMap = primaryConfig.userMCPAuthMap;

  /** @type {Set<string>} Track agents that failed to load (orphaned references) */
  const skippedAgentIds = new Set();

  async function processAgent(agentId) {
    const agent = await db.getAgent({ id: agentId });
    if (!agent) {
      logger.warn(
        `[processAgent] Handoff agent ${agentId} not found, skipping (orphaned reference)`,
      );
      skippedAgentIds.add(agentId);
      return null;
    }

    const hasAccess = await checkPermission({
      userId: req.user.id,
      role: req.user.role,
      resourceType: ResourceType.AGENT,
      resourceId: agent._id,
      requiredPermission: PermissionBits.VIEW,
    });

    if (!hasAccess) {
      logger.warn(
        `[processAgent] User ${req.user.id} lacks VIEW access to handoff agent ${agentId}, skipping`,
      );
      skippedAgentIds.add(agentId);
      return null;
    }

    const validationResult = await validateAgentModel({
      req,
      res,
      agent,
      modelsConfig,
      logViolation,
    });

    if (!validationResult.isValid) {
      throw new Error(validationResult.error?.message);
    }

    const config = await initializeAgent(
      {
        req,
        res,
        agent,
        loadTools,
        requestFiles,
        conversationId,
        parentMessageId,
        endpointOption,
        allowedProviders,
      },
      {
        getFiles: db.getFiles,
        getUserKey: db.getUserKey,
        getMessages: db.getMessages,
        getConvoFiles: db.getConvoFiles,
        updateFilesUsage: db.updateFilesUsage,
        getUserKeyValues: db.getUserKeyValues,
        getUserCodeFiles: db.getUserCodeFiles,
        getToolFilesByIds: db.getToolFilesByIds,
        getCodeGeneratedFiles: db.getCodeGeneratedFiles,
        filterFilesByAgentAccess: (params) => {
          const endpointConfig = req.config?.endpoints?.[agent.provider];
          return filterFilesByAgentAccess({ ...params, endpointConfig });
        },
      },
    );

    if (userMCPAuthMap != null) {
      Object.assign(userMCPAuthMap, config.userMCPAuthMap ?? {});
    } else {
      userMCPAuthMap = config.userMCPAuthMap;
    }

    /** Store handoff agent's tool context for ON_TOOL_EXECUTE callback */
    agentToolContexts.set(agentId, {
      agent,
      toolRegistry: config.toolRegistry,
      userMCPAuthMap: config.userMCPAuthMap,
      tool_resources: config.tool_resources,
      actionsEnabled: config.actionsEnabled,
    });

    agentConfigs.set(agentId, config);
    return agent;
  }

  const checkAgentInit = (agentId) => agentId === primaryConfig.id || agentConfigs.has(agentId);

  // Graph topology discovery for recursive agent handoffs (BFS)
  const { edgeMap, agentsToProcess, collectEdges } = createEdgeCollector(
    checkAgentInit,
    skippedAgentIds,
  );

  // Seed with primary agent's edges
  collectEdges(primaryConfig.edges);

  // BFS to load and merge all connected agents (enables transitive handoffs: A->B->C)
  while (agentsToProcess.size > 0) {
    const agentId = agentsToProcess.values().next().value;
    agentsToProcess.delete(agentId);
    try {
      const agent = await processAgent(agentId);
      if (agent?.edges?.length) {
        collectEdges(agent.edges);
      }
    } catch (err) {
      logger.error(`[initializeClient] Error processing agent ${agentId}:`, err);
      skippedAgentIds.add(agentId);
    }
  }

  if (autoCollaborativeBundle?.collaborators?.length) {
    for (const collaborator of autoCollaborativeBundle.collaborators) {
      const validationResult = await validateAgentModel({
        req,
        res,
        agent: collaborator,
        modelsConfig,
        logViolation,
      });

      if (!validationResult.isValid) {
        throw new Error(validationResult.error?.message);
      }

      const config = await initializeAgent(
        {
          req,
          res,
          agent: collaborator,
          loadTools,
          requestFiles,
          conversationId,
          parentMessageId,
          endpointOption,
          allowedProviders,
        },
        {
          getFiles: db.getFiles,
          getUserKey: db.getUserKey,
          getMessages: db.getMessages,
          getConvoFiles: db.getConvoFiles,
          updateFilesUsage: db.updateFilesUsage,
          getUserKeyValues: db.getUserKeyValues,
          getUserCodeFiles: db.getUserCodeFiles,
          getToolFilesByIds: db.getToolFilesByIds,
          getCodeGeneratedFiles: db.getCodeGeneratedFiles,
          filterFilesByAgentAccess: (params) => {
            const endpointConfig = req.config?.endpoints?.[collaborator.provider];
            return filterFilesByAgentAccess({ ...params, endpointConfig });
          },
        },
      );

      if (userMCPAuthMap != null) {
        Object.assign(userMCPAuthMap, config.userMCPAuthMap ?? {});
      } else {
        userMCPAuthMap = config.userMCPAuthMap;
      }

      agentToolContexts.set(collaborator.id, {
        agent: collaborator,
        toolRegistry: config.toolRegistry,
        userMCPAuthMap: config.userMCPAuthMap,
        tool_resources: config.tool_resources,
        actionsEnabled: config.actionsEnabled,
      });

      agentConfigs.set(collaborator.id, config);
    }

    const autoChain = await createSequentialChainEdges(
      [primaryConfig.id].concat(autoCollaborativeBundle.collaborators.map((agent) => agent.id)),
      AUTO_AGENT_CHAIN_PROMPT,
    );
    collectEdges(autoChain);
  }

  /** @deprecated Agent Chain */
  if (agent_ids?.length) {
    for (const agentId of agent_ids) {
      if (checkAgentInit(agentId)) {
        continue;
      }
      try {
        await processAgent(agentId);
      } catch (err) {
        logger.error(`[initializeClient] Error processing chain agent ${agentId}:`, err);
        skippedAgentIds.add(agentId);
      }
    }
    const chain = await createSequentialChainEdges([primaryConfig.id].concat(agent_ids), '{convo}');
    collectEdges(chain);
  }

  let edges = Array.from(edgeMap.values());

  /** Multi-Convo: Process addedConvo for parallel agent execution */
  const { userMCPAuthMap: updatedMCPAuthMap } = await processAddedConvo({
    req,
    res,
    loadTools,
    logViolation,
    modelsConfig,
    requestFiles,
    agentConfigs,
    primaryAgent,
    endpointOption,
    userMCPAuthMap,
    conversationId,
    parentMessageId,
    allowedProviders,
    primaryAgentId: primaryConfig.id,
  });

  if (updatedMCPAuthMap) {
    userMCPAuthMap = updatedMCPAuthMap;
  }

  for (const [agentId, config] of agentConfigs) {
    if (agentToolContexts.has(agentId)) {
      continue;
    }
    agentToolContexts.set(agentId, {
      agent: config,
      toolRegistry: config.toolRegistry,
      userMCPAuthMap: config.userMCPAuthMap,
      tool_resources: config.tool_resources,
      actionsEnabled: config.actionsEnabled,
    });
  }

  // Ensure edges is an array when we have multiple agents (multi-agent mode)
  // MultiAgentGraph.categorizeEdges requires edges to be iterable
  if (agentConfigs.size > 0 && !edges) {
    edges = [];
  }

  // Filter out edges referencing non-existent agents (orphaned references)
  edges = filterOrphanedEdges(edges, skippedAgentIds);

  primaryConfig.edges = edges;

  let endpointConfig = appConfig.endpoints?.[primaryConfig.endpoint];
  if (!isAgentsEndpoint(primaryConfig.endpoint) && !endpointConfig) {
    try {
      endpointConfig = getCustomEndpointConfig({
        endpoint: primaryConfig.endpoint,
        appConfig,
      });
    } catch (err) {
      logger.error(
        '[api/server/controllers/agents/client.js #titleConvo] Error getting custom endpoint config',
        err,
      );
    }
  }

  const sender =
    endpointOption.model_parameters.modelLabel ??
    primaryAgent.name ??
    endpointConfig?.modelDisplayLabel ??
    getPlatformAssistantName();

  const client = new AgentClient({
    req,
    res,
    sender,
    contentParts,
    agentConfigs,
    eventHandlers,
    collectedUsage,
    aggregateContent,
    artifactPromises,
    agent: primaryConfig,
    spec: endpointOption.spec,
    iconURL: endpointOption.iconURL,
    attachments: primaryConfig.attachments,
    endpointType: endpointOption.endpointType,
    resendFiles: primaryConfig.resendFiles ?? true,
    maxContextTokens: primaryConfig.maxContextTokens,
    endpoint: isEphemeralAgentId(primaryConfig.id) ? primaryConfig.endpoint : EModelEndpoint.agents,
  });

  if (streamId) {
    GenerationJobManager.setCollectedUsage(streamId, collectedUsage);
  }

  return { client, userMCPAuthMap };
};

module.exports = {
  initializeClient,
  resolveCollaborativeMode,
  shouldUseCollaborativeAgents,
};
