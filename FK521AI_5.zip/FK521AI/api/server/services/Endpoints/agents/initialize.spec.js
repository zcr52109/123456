const mongoose = require('mongoose');
const {
  ResourceType,
  PermissionBits,
  PrincipalType,
  PrincipalModel,
} = require('fk521ai-data-provider');
const { MongoMemoryServer } = require('mongodb-memory-server');

const mockInitializeAgent = jest.fn();
const mockValidateAgentModel = jest.fn();

jest.mock('@fk521ai/agents', () => ({
  ...jest.requireActual('@fk521ai/agents'),
  createContentAggregator: jest.fn(() => ({
    contentParts: [],
    aggregateContent: jest.fn(),
  })),
}));

jest.mock('@fk521ai/api', () => ({
  ...jest.requireActual('@fk521ai/api'),
  initializeAgent: (...args) => mockInitializeAgent(...args),
  validateAgentModel: (...args) => mockValidateAgentModel(...args),
  GenerationJobManager: { setCollectedUsage: jest.fn() },
  getCustomEndpointConfig: jest.fn(),
  createSequentialChainEdges: jest.fn(),
}));

jest.mock('~/server/controllers/agents/callbacks', () => ({
  createToolEndCallback: jest.fn(() => jest.fn()),
  getDefaultHandlers: jest.fn(() => ({})),
}));

jest.mock('~/server/services/ToolService', () => ({
  loadAgentTools: jest.fn(),
  loadToolsForExecution: jest.fn(),
}));

jest.mock('~/server/controllers/ModelController', () => ({
  getModelsConfig: jest.fn().mockResolvedValue({}),
}));

let agentClientArgs;
jest.mock('~/server/controllers/agents/client', () => {
  return jest.fn().mockImplementation((args) => {
    agentClientArgs = args;
    return {};
  });
});

jest.mock('./addedConvo', () => ({
  processAddedConvo: jest.fn().mockResolvedValue({ userMCPAuthMap: undefined }),
}));

jest.mock('~/cache', () => ({
  logViolation: jest.fn(),
}));

const { initializeClient } = require('./initialize');
const { User, AclEntry } = require('~/db/models');
const { createAgent } = require('~/models');

const PRIMARY_ID = 'agent_primary';
const TARGET_ID = 'agent_target';
const AUTHORIZED_ID = 'agent_authorized';

describe('initializeClient — processAgent ACL gate', () => {
  let mongoServer;
  let testUser;

  beforeAll(async () => {
    mongoServer = await MongoMemoryServer.create();
    await mongoose.connect(mongoServer.getUri());
  });

  afterAll(async () => {
    await mongoose.disconnect();
    await mongoServer.stop();
  });

  beforeEach(async () => {
    await mongoose.connection.dropDatabase();
    jest.clearAllMocks();
    agentClientArgs = undefined;

    testUser = await User.create({
      email: 'test@example.com',
      name: 'Test User',
      username: 'testuser',
      role: 'USER',
    });

    mockValidateAgentModel.mockResolvedValue({ isValid: true });
  });

  const makeReq = () => ({
    user: { id: testUser._id.toString(), role: 'USER' },
    body: { conversationId: 'conv_1', files: [] },
    config: { endpoints: {} },
    _resumableStreamId: null,
  });

  const makeEndpointOption = () => ({
    agent: Promise.resolve({
      id: PRIMARY_ID,
      name: 'Primary',
      provider: 'openai',
      model: 'gpt-4',
      tools: [],
    }),
    model_parameters: { model: 'gpt-4' },
    endpoint: 'agents',
  });

  const makePrimaryConfig = (edges) => ({
    id: PRIMARY_ID,
    endpoint: 'agents',
    edges,
    toolDefinitions: [],
    toolRegistry: new Map(),
    userMCPAuthMap: null,
    tool_resources: {},
    resendFiles: true,
    maxContextTokens: 4096,
  });

  it('should skip handoff agent and filter its edge when user lacks VIEW access', async () => {
    await createAgent({
      id: TARGET_ID,
      name: 'Target Agent',
      provider: 'openai',
      model: 'gpt-4',
      author: new mongoose.Types.ObjectId(),
      tools: [],
    });

    const edges = [{ from: PRIMARY_ID, to: TARGET_ID, edgeType: 'handoff' }];
    mockInitializeAgent.mockResolvedValue(makePrimaryConfig(edges));

    await initializeClient({
      req: makeReq(),
      res: {},
      signal: new AbortController().signal,
      endpointOption: makeEndpointOption(),
    });

    expect(mockInitializeAgent).toHaveBeenCalledTimes(1);
    expect(agentClientArgs.agent.edges).toEqual([]);
  });

  it('should auto-enable collaborative pipeline for complex requests without explicit graph config', async () => {
    const complexReq = makeReq();
    complexReq.body.messages = [
      {
        role: 'user',
        text: [
          '请帮我修复系统指令超标、模型路由、缓存刷新、多 AI 协作、代码实现与审查问题。',
          '需要完整架构设计、实现计划、风险检查、回归验证、代码修改和最终交付。',
          '同时处理 bug、报错、优化、重构、review、implement。',
        ].join('\n'),
      },
    ];
    complexReq.body.files = [{ id: 'file_1' }];

    const endpointOption = makeEndpointOption();
    const primaryConfig = makePrimaryConfig([]);
    const collaboratorConfigs = [
      {
        id: 'planner_cfg',
        edges: [],
        toolDefinitions: [],
        toolRegistry: new Map(),
        userMCPAuthMap: null,
        tool_resources: {},
      },
      {
        id: 'reviewer_cfg',
        edges: [],
        toolDefinitions: [],
        toolRegistry: new Map(),
        userMCPAuthMap: null,
        tool_resources: {},
      },
      {
        id: 'implementer_cfg',
        edges: [],
        toolDefinitions: [],
        toolRegistry: new Map(),
        userMCPAuthMap: null,
        tool_resources: {},
      },
    ];

    mockInitializeAgent
      .mockResolvedValueOnce(primaryConfig)
      .mockResolvedValueOnce(collaboratorConfigs[0])
      .mockResolvedValueOnce(collaboratorConfigs[1])
      .mockResolvedValueOnce(collaboratorConfigs[2]);

    const autoEdges = [
      { from: PRIMARY_ID, to: 'planner', edgeType: 'direct' },
      { from: 'planner', to: 'reviewer', edgeType: 'direct' },
      { from: 'reviewer', to: 'implementer', edgeType: 'direct' },
    ];
    const { createSequentialChainEdges } = require('@fk521ai/api');
    createSequentialChainEdges.mockResolvedValue(autoEdges);

    await initializeClient({
      req: complexReq,
      res: {},
      signal: new AbortController().signal,
      endpointOption,
    });

    expect(mockInitializeAgent).toHaveBeenCalledTimes(4);
    expect(createSequentialChainEdges).toHaveBeenCalledTimes(1);
    expect(agentClientArgs.agentConfigs.size).toBe(3);
    expect(agentClientArgs.agent.edges).toEqual(autoEdges);

    const collaboratorArgs = mockInitializeAgent.mock.calls.slice(1).map((call) => call[0].agent);
    expect(collaboratorArgs.map((agent) => agent.name)).toEqual([
      'Primary Planner',
      'Primary Reviewer',
      'Primary Implementer',
    ]);
  });


  it('should force single-agent flow when collaborationMode=single', async () => {
    const req = makeReq();
    req.body.messages = [
      { role: 'user', text: '请修复架构、缓存、代码实现、review 和多 AI 问题。' },
    ];
    req.body.collaborationMode = 'single';

    mockInitializeAgent.mockResolvedValue(makePrimaryConfig([]));

    await initializeClient({
      req,
      res: {},
      signal: new AbortController().signal,
      endpointOption: makeEndpointOption(),
    });

    expect(mockInitializeAgent).toHaveBeenCalledTimes(1);
  });

  it('should force collaborative flow when collaborationMode=collaborative', async () => {
    const req = makeReq();
    req.body.messages = [{ role: 'user', text: '你好，帮我总结一下。' }];
    req.body.collaborationMode = 'collaborative';

    const primaryConfig = makePrimaryConfig([]);
    const collaboratorConfigs = [
      { id: 'planner_cfg', edges: [], toolDefinitions: [], toolRegistry: new Map(), userMCPAuthMap: null, tool_resources: {} },
      { id: 'reviewer_cfg', edges: [], toolDefinitions: [], toolRegistry: new Map(), userMCPAuthMap: null, tool_resources: {} },
      { id: 'implementer_cfg', edges: [], toolDefinitions: [], toolRegistry: new Map(), userMCPAuthMap: null, tool_resources: {} },
    ];

    mockInitializeAgent
      .mockResolvedValueOnce(primaryConfig)
      .mockResolvedValueOnce(collaboratorConfigs[0])
      .mockResolvedValueOnce(collaboratorConfigs[1])
      .mockResolvedValueOnce(collaboratorConfigs[2]);

    const { createSequentialChainEdges } = require('@fk521ai/api');
    createSequentialChainEdges.mockResolvedValue([
      { from: PRIMARY_ID, to: 'planner', edgeType: 'direct' },
      { from: 'planner', to: 'reviewer', edgeType: 'direct' },
      { from: 'reviewer', to: 'implementer', edgeType: 'direct' },
    ]);

    await initializeClient({
      req,
      res: {},
      signal: new AbortController().signal,
      endpointOption: makeEndpointOption(),
    });

    expect(mockInitializeAgent).toHaveBeenCalledTimes(4);
  });

  it('should keep single-agent flow for simple requests', async () => {
    const simpleReq = makeReq();
    simpleReq.body.messages = [{ role: 'user', text: '你好，帮我总结一下。' }];
    mockInitializeAgent.mockResolvedValue(makePrimaryConfig([]));

    const { createSequentialChainEdges } = require('@fk521ai/api');
    createSequentialChainEdges.mockResolvedValue([]);

    await initializeClient({
      req: simpleReq,
      res: {},
      signal: new AbortController().signal,
      endpointOption: makeEndpointOption(),
    });

    expect(mockInitializeAgent).toHaveBeenCalledTimes(1);
    expect(createSequentialChainEdges).not.toHaveBeenCalled();
    expect(agentClientArgs.agentConfigs.size).toBe(0);
  });


  it('should initialize handoff agent and keep its edge when user has VIEW access', async () => {
    const authorizedAgent = await createAgent({
      id: AUTHORIZED_ID,
      name: 'Authorized Agent',
      provider: 'openai',
      model: 'gpt-4',
      author: new mongoose.Types.ObjectId(),
      tools: [],
    });

    await AclEntry.create({
      principalType: PrincipalType.USER,
      principalId: testUser._id,
      principalModel: PrincipalModel.USER,
      resourceType: ResourceType.AGENT,
      resourceId: authorizedAgent._id,
      permBits: PermissionBits.VIEW,
      grantedBy: testUser._id,
    });

    const edges = [{ from: PRIMARY_ID, to: AUTHORIZED_ID, edgeType: 'handoff' }];
    const handoffConfig = {
      id: AUTHORIZED_ID,
      edges: [],
      toolDefinitions: [],
      toolRegistry: new Map(),
      userMCPAuthMap: null,
      tool_resources: {},
    };

    let callCount = 0;
    mockInitializeAgent.mockImplementation(() => {
      callCount++;
      return callCount === 1
        ? Promise.resolve(makePrimaryConfig(edges))
        : Promise.resolve(handoffConfig);
    });

    await initializeClient({
      req: makeReq(),
      res: {},
      signal: new AbortController().signal,
      endpointOption: makeEndpointOption(),
    });

    expect(mockInitializeAgent).toHaveBeenCalledTimes(2);
    expect(agentClientArgs.agent.edges).toHaveLength(1);
    expect(agentClientArgs.agent.edges[0].to).toBe(AUTHORIZED_ID);
  });
});
