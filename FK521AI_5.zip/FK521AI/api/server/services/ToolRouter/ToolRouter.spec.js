const { decideToolInvocation, validateToolInput } = require('./index');

describe('ToolRouter', () => {
  test('blocks high-risk tools when intent is not explicit', () => {
    const tool = {
      name: 'workspace_write',
      schema: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          content: { type: 'string' },
        },
        required: ['path', 'content'],
        additionalProperties: false,
      },
    };

    const decision = decideToolInvocation({
      tool,
      input: { path: '/workspace/outputs/result.txt', content: 'ok' },
      req: { body: { text: '你好' } },
    });

    expect(decision.action).toBe('ASK_USER');
    expect(decision.reasonCode).toBe('HIGH_RISK_INTENT_UNCONFIRMED');
  });

  test('allows high-risk tools when user explicitly requests file creation', () => {
    const tool = {
      name: 'workspace_write',
      schema: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          content: { type: 'string' },
        },
        required: ['path', 'content'],
        additionalProperties: false,
      },
    };

    const decision = decideToolInvocation({
      tool,
      input: { path: '/workspace/outputs/result.txt', content: 'ok' },
      req: { body: { text: '请生成文件并保存到 outputs 目录' } },
    });

    expect(decision.action).toBe('CALL_TOOL');
    expect(decision.reasonCode).toBe('OK');
  });

  test('rejects forbidden redline tool names', () => {
    const tool = {
      name: 'shell_exec',
      schema: {
        type: 'object',
        properties: { command: { type: 'string' } },
        required: ['command'],
        additionalProperties: false,
      },
    };

    const decision = decideToolInvocation({
      tool,
      input: { command: 'id' },
      req: { body: { text: '请执行命令' } },
    });

    expect(decision.action).toBe('REJECT');
    expect(decision.reasonCode).toBe('FORBIDDEN_TOOL_NAME');
  });

  test('returns schema validation failure for missing required fields', () => {
    const tool = {
      name: 'workspace_write',
      schema: {
        type: 'object',
        properties: {
          path: { type: 'string' },
          content: { type: 'string' },
        },
        required: ['path', 'content'],
        additionalProperties: false,
      },
    };

    const validation = validateToolInput(tool, { path: '/workspace/outputs/a.txt' });
    expect(validation.ok).toBe(false);
    expect(validation.errors.some((error) => error.code === 'MISSING_REQUIRED')).toBe(true);

    const decision = decideToolInvocation({
      tool,
      input: { path: '/workspace/outputs/a.txt' },
      req: { body: { text: '请保存文件' } },
    });
    expect(decision.action).toBe('ASK_USER');
    expect(decision.reasonCode).toBe('SCHEMA_VALIDATION_FAILED');
  });
});
