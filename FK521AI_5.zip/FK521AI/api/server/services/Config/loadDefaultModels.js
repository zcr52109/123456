const { logger } = require('@fk521ai/data-schemas');
const { EModelEndpoint } = require('fk521ai-data-provider');
const {
  getAnthropicModels,
  getBedrockModels,
  getOpenAIModels,
  getGoogleModels,
} = require('@fk521ai/api');
const { getAppConfig } = require('./app');

/**
 * Loads the default models for the application.
 * @async
 * @function
 * @param {ServerRequest} req - The Express request object.
 */
async function loadDefaultModels(req) {
  try {
    const appConfig =
      req.config ?? (await getAppConfig({ role: req.user?.role, tenantId: req.user?.tenantId }));
    const vertexConfig = appConfig?.endpoints?.[EModelEndpoint.anthropic]?.vertexConfig;

    const [openAI, anthropic, azureOpenAI, assistants, azureAssistants, agents, google, bedrock] =
      await Promise.all([
        getOpenAIModels({ user: req.user.id }).catch((error) => {
          logger.error('Error fetching OpenAI models:', error);
          return [];
        }),
        getAnthropicModels({ user: req.user.id, vertexModels: vertexConfig?.modelNames }).catch(
          (error) => {
            logger.error('Error fetching Anthropic models:', error);
            return [];
          },
        ),
        getOpenAIModels({ user: req.user.id, azure: true }).catch((error) => {
          logger.error('Error fetching Azure OpenAI models:', error);
          return [];
        }),
        getOpenAIModels({ assistants: true }).catch((error) => {
          logger.error('Error fetching OpenAI Assistants API models:', error);
          return [];
        }),
        getOpenAIModels({ azureAssistants: true }).catch((error) => {
          logger.error('Error fetching Azure OpenAI Assistants API models:', error);
          return [];
        }),
        getOpenAIModels({ agents: true }).catch((error) => {
          logger.error('Error fetching Agents endpoint models:', error);
          return [];
        }),
        Promise.resolve(getGoogleModels()).catch((error) => {
          logger.error('Error getting Google models:', error);
          return [];
        }),
        Promise.resolve(getBedrockModels()).catch((error) => {
          logger.error('Error getting Bedrock models:', error);
          return [];
        }),
      ]);

    // Apply compatibility mappings for Google models (old field names to new)
    const googleModelsWithCompat = google.map(model => ({
      ...model,
      // Map old 'model' field to new 'name' field if needed
      name: model.name || model.model || '',
      // Map old 'displayName' to 'label' if needed
      label: model.label || model.displayName || model.name || '',
      // Ensure 'versions' array exists for backward compatibility
      versions: model.versions || (model.version ? [model.version] : []),
    }));

    return {
      [EModelEndpoint.openAI]: openAI,
      [EModelEndpoint.google]: googleModelsWithCompat,
      [EModelEndpoint.anthropic]: anthropic,
      [EModelEndpoint.azureOpenAI]: azureOpenAI,
      [EModelEndpoint.assistants]: assistants,
      [EModelEndpoint.azureAssistants]: azureAssistants,
      [EModelEndpoint.agents]: agents,
      [EModelEndpoint.bedrock]: bedrock,
    };
  } catch (error) {
    logger.error('Error fetching default models:', error);
    throw new Error(`Failed to load default models: ${error.message}`);
  }
}

module.exports = loadDefaultModels;
