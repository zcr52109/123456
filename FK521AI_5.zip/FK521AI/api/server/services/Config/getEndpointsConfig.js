const { createEndpointsConfigService } = require('@fk521ai/api');
const loadDefaultEndpointsConfig = require('./loadDefaultEConfig');
const { getAppConfig } = require('./app');

const { getEndpointsConfig, checkCapability } = createEndpointsConfigService({
  getAppConfig,
  loadDefaultEndpointsConfig,
});

module.exports = { getEndpointsConfig, checkCapability };
