const fs = require('fs/promises');
const path = require('path');
const mongoose = require('mongoose');

const SETTINGS_KEY = 'runtime.system-settings';
const DEFAULT_SETTINGS = Object.freeze({
  featureToggles: {
    rateLimitEnabled: false,
    allowAllUploadTypes: true,
    csrfStrictMode: true,
  },
  limits: {
    uploadMaxFileSize: 0,
    jsonBodyLimit: '50mb',
    formBodyLimit: '50mb',
    workspaceMaxFileBytes: 0,
    workspaceMaxTotalWriteBytes: 0,
    archiveMaxEntries: 0,
    archiveMaxTotalBytes: 0,
  },
});

const FALLBACK_FILE = path.resolve(__dirname, '../../../.runtime/system-settings.json');
let memoryState = { version: 1, settings: JSON.parse(JSON.stringify(DEFAULT_SETTINGS)) };

const SystemSettingSchema = new mongoose.Schema(
  {
    key: { type: String, required: true, unique: true, index: true },
    value: { type: mongoose.Schema.Types.Mixed, default: {} },
    version: { type: Number, default: 1 },
  },
  { timestamps: true, collection: 'system_settings' },
);

const SystemSetting = mongoose.models.SystemSetting || mongoose.model('SystemSetting', SystemSettingSchema);

function deepMerge(base, input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    return base;
  }
  const output = { ...base };
  for (const [key, value] of Object.entries(input)) {
    if (
      value &&
      typeof value === 'object' &&
      !Array.isArray(value) &&
      base[key] &&
      typeof base[key] === 'object' &&
      !Array.isArray(base[key])
    ) {
      output[key] = deepMerge(base[key], value);
    } else {
      output[key] = value;
    }
  }
  return output;
}

function normalizeSettings(value) {
  return deepMerge(JSON.parse(JSON.stringify(DEFAULT_SETTINGS)), value || {});
}

async function readFallbackFile() {
  try {
    const raw = await fs.readFile(FALLBACK_FILE, 'utf8');
    const data = JSON.parse(raw);
    if (data && typeof data === 'object') {
      memoryState = {
        version: Number(data.version || memoryState.version || 1),
        settings: normalizeSettings(data.settings || data.value || {}),
      };
    }
  } catch (_error) {}
  return memoryState;
}

async function writeFallbackFile(state) {
  memoryState = {
    version: Number(state.version || 1),
    settings: normalizeSettings(state.settings || state.value || {}),
  };
  await fs.mkdir(path.dirname(FALLBACK_FILE), { recursive: true });
  await fs.writeFile(FALLBACK_FILE, JSON.stringify(memoryState, null, 2), 'utf8');
  return memoryState;
}

async function getSystemSettings() {
  if (mongoose.connection.readyState === 1) {
    const existing = await SystemSetting.findOne({ key: SETTINGS_KEY }).lean();
    if (existing) {
      return {
        version: Number(existing.version || 1),
        settings: normalizeSettings(existing.value),
        defaults: DEFAULT_SETTINGS,
      };
    }
    const created = await SystemSetting.create({
      key: SETTINGS_KEY,
      value: normalizeSettings({}),
      version: 1,
    });
    return {
      version: Number(created.version || 1),
      settings: normalizeSettings(created.value),
      defaults: DEFAULT_SETTINGS,
    };
  }

  const fallback = await readFallbackFile();
  return {
    version: Number(fallback.version || 1),
    settings: normalizeSettings(fallback.settings),
    defaults: DEFAULT_SETTINGS,
  };
}

async function updateSystemSettings(partial = {}) {
  if (mongoose.connection.readyState === 1) {
    const current = await getSystemSettings();
    const merged = normalizeSettings(deepMerge(current.settings, partial));
    const updated = await SystemSetting.findOneAndUpdate(
      { key: SETTINGS_KEY },
      { $set: { value: merged }, $inc: { version: 1 } },
      { upsert: true, new: true, setDefaultsOnInsert: true },
    ).lean();
    return {
      version: Number(updated?.version || 1),
      settings: normalizeSettings(updated?.value),
      defaults: DEFAULT_SETTINGS,
    };
  }

  const current = await readFallbackFile();
  const next = {
    version: Number(current.version || 1) + 1,
    settings: normalizeSettings(deepMerge(current.settings, partial)),
  };
  const written = await writeFallbackFile(next);
  return {
    version: Number(written.version || 1),
    settings: normalizeSettings(written.settings),
    defaults: DEFAULT_SETTINGS,
  };
}

module.exports = {
  SystemSetting,
  getSystemSettings,
  updateSystemSettings,
  DEFAULT_SETTINGS,
};
