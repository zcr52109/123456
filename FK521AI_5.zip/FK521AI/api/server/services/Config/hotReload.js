const fs = require('fs');
const { logger } = require('@fk521ai/data-schemas');
const { getProjectApiConfigPath } = require('~/server/utils/projectApiConfig');
const { getManagedModelStylesPath } = require('~/server/utils/managedModelStyles');
const { invalidateConfigCaches } = require('./app');
const { invalidateUIModelCache } = require('~/server/controllers/ModelController');
const { recordPolicyAuditEvent } = require('~/server/services/RuntimePolicy');

let started = false;
const watchers = [];

function watchFile(filePath, label) {
  if (!filePath) {
    return;
  }

  let lastMtimeMs = fs.existsSync(filePath) ? fs.statSync(filePath).mtimeMs : 0;
  fs.watchFile(filePath, { interval: 2000 }, async (curr) => {
    if (!curr || curr.mtimeMs === lastMtimeMs) {
      return;
    }
    lastMtimeMs = curr.mtimeMs;
    logger.info(`[ConfigHotReload] Detected ${label} change, invalidating config caches`);
    invalidateUIModelCache();
    recordPolicyAuditEvent({ action: 'config_file_changed', label, filePath });
    await invalidateConfigCaches();
  });
  watchers.push({ filePath, label });
}

function startAdminConfigWatchers() {
  if (started) {
    return;
  }
  started = true;
  watchFile(getProjectApiConfigPath(), 'project_apis');
  watchFile(getManagedModelStylesPath(), 'managed_model_styles');
}

function stopAdminConfigWatchers() {
  for (const watcher of watchers.splice(0)) {
    fs.unwatchFile(watcher.filePath);
  }
  started = false;
}

module.exports = {
  startAdminConfigWatchers,
  stopAdminConfigWatchers,
};
