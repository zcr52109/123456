const { EventEmitter } = require('events');

const configEvents = new EventEmitter();
configEvents.setMaxListeners(200);

let configRevision = Date.now();

function getConfigRevision() {
  return configRevision;
}

function notifyConfigUpdated(payload = {}) {
  configRevision += 1;
  const event = {
    type: 'config_updated',
    revision: configRevision,
    changedKeys: Array.isArray(payload.changedKeys) && payload.changedKeys.length > 0 ? payload.changedKeys : ['endpoints', 'startupConfig'],
    tenantId: payload.tenantId || null,
    updatedAt: new Date().toISOString(),
  };
  configEvents.emit('config_updated', event);
  return event;
}

function subscribeConfigUpdates(listener) {
  configEvents.on('config_updated', listener);
  return () => configEvents.off('config_updated', listener);
}

module.exports = {
  configEvents,
  getConfigRevision,
  notifyConfigUpdated,
  subscribeConfigUpdates,
};
