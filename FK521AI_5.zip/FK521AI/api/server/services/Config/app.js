const { CacheKeys, Tools, Constants } = require("fk521ai-data-provider");
const { AppService, logger } = require("@fk521ai/data-schemas");
const {
  createAppConfigService,
  clearMcpConfigCache,
} = require("@fk521ai/api");
const { setCachedTools, invalidateCachedTools } = require("./getCachedTools");
const { loadAndFormatTools } = require("~/server/services/start/tools");
const loadCustomConfig = require("./loadCustomConfig");
const getLogStores = require("~/cache/getLogStores");
const paths = require("~/config/paths");
const db = require("~/models");
const { notifyConfigUpdated } = require('./realtime');

const nativeSystemTools = {
  [Tools.execute_code]: {
    type: Tools.function,
    [Tools.function]: {
      name: Tools.execute_code,
      description:
        'Execute Python or JavaScript in the already-authorized local sandbox with access to the conversation workspace and downloadable output files. When the user asks to create or export a file, write the real file into the runtime workspace/outputs instead of only printing content in chat.',
      parameters: {
        type: 'object',
        properties: {
          code: { type: 'string', description: 'The code to execute.' },
          language: {
            type: 'string',
            enum: ['python', 'javascript'],
            description: 'Preferred runtime. Defaults to python when omitted.',
          },
        },
        required: ['code'],
        additionalProperties: true,
      },
    },
  },
  [Constants.PROGRAMMATIC_TOOL_CALLING]: {
    type: Tools.function,
    [Tools.function]: {
      name: Constants.PROGRAMMATIC_TOOL_CALLING,
      description:
        'Run orchestration code in the already-authorized local sandbox and call other tools programmatically from that sandbox.',
      parameters: {
        type: 'object',
        properties: {
          code: { type: 'string', description: 'The orchestration code to execute.' },
          language: {
            type: 'string',
            enum: ['python', 'javascript'],
            description: 'Preferred runtime. Defaults to python when omitted.',
          },
        },
        required: ['code'],
        additionalProperties: true,
      },
    },
  },
};

const loadBaseConfig = async () => {
  /** @type {TCustomConfig} */
  const config = (await loadCustomConfig()) ?? {};
  /** @type {Record<string, FunctionTool>} */
  const systemTools = {
    ...loadAndFormatTools({
      adminFilter: config.filteredTools,
      adminIncluded: config.includedTools,
      directory: paths.structuredTools,
    }),
    ...nativeSystemTools,
  };
  return AppService({ config, paths, systemTools });
};

const { getAppConfig, clearAppConfigCache, clearOverrideCache } =
  createAppConfigService({
    loadBaseConfig,
    setCachedTools,
    getCache: getLogStores,
    cacheKeys: CacheKeys,
    getApplicableConfigs: db.getApplicableConfigs,
    getUserPrincipals: db.getUserPrincipals,
    overrideCacheTtl: 0,
  });

/**
 * Invalidate all config-related caches after an admin config mutation.
 * Clears the base config, per-principal override caches, tool caches,
 * and the MCP config-source server cache.
 * @param {string} [tenantId] - Optional tenant ID to scope override cache clearing.
 */
async function invalidateConfigCaches(tenantId) {
  const results = await Promise.allSettled([
    clearAppConfigCache(),
    clearOverrideCache(tenantId),
    invalidateCachedTools({ invalidateGlobal: true }),
    clearMcpConfigCache(),
  ]);
  const labels = [
    "clearAppConfigCache",
    "clearOverrideCache",
    "invalidateCachedTools",
    "clearMcpConfigCache",
  ];
  for (let i = 0; i < results.length; i++) {
    if (results[i].status === "rejected") {
      logger.error(
        `[invalidateConfigCaches] ${labels[i]} failed:`,
        results[i].reason,
      );
    }
  }

  notifyConfigUpdated({
    tenantId: tenantId || null,
    changedKeys: [
      'endpoints',
      'startupConfig',
      'models',
      'fileConfig',
      'tools',
      'actions',
      'mcpTools',
      'agentTools',
      'agents',
    ],
  });
}

module.exports = {
  getAppConfig,
  clearAppConfigCache,
  invalidateConfigCaches,
};
