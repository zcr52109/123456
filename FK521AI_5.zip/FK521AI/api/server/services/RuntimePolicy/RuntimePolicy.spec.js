const fs = require('fs');
const os = require('os');
const path = require('path');

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fk521-policy-audit-'));
process.env.FK521_POLICY_AUDIT_PATH = path.join(tempDir, 'policy-events.log');

const {
  recordPolicyAuditEvent,
  readPolicyAuditLog,
} = require('./index');

describe('RuntimePolicy audit log', () => {
  afterAll(() => {
    fs.rmSync(tempDir, { recursive: true, force: true });
    delete process.env.FK521_POLICY_AUDIT_PATH;
  });

  test('filters by conversationId and tool name', () => {
    recordPolicyAuditEvent({
      eventType: 'tool_call',
      conversationId: 'conv-a',
      toolName: 'workspace_read',
      inputSummary: { path: '/workspace/uploads/a.txt' },
    });
    recordPolicyAuditEvent({
      eventType: 'tool_result',
      conversationId: 'conv-b',
      toolName: 'content_scan',
      resultSummary: { findings: 1 },
    });

    const convA = readPolicyAuditLog({ conversationId: 'conv-a', limit: 10 });
    expect(convA.length).toBeGreaterThanOrEqual(1);
    expect(convA.every((entry) => entry.conversationId === 'conv-a')).toBe(true);

    const scanOnly = readPolicyAuditLog({ toolName: 'content_scan', limit: 10 });
    expect(scanOnly.length).toBeGreaterThanOrEqual(1);
    expect(scanOnly.every((entry) => entry.toolName === 'content_scan')).toBe(true);
  });
});
