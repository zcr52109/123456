const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { logger } = require('@fk521ai/data-schemas');
const { getProjectApiConfigPath } = require('~/server/utils/projectApiConfig');
const { getManagedModelStylesPath } = require('~/server/utils/managedModelStyles');

const projectRoot = path.resolve(__dirname, '..', '..', '..', '..');
const defaultAuditDir = path.join(projectRoot, 'runtime', 'audit');
const defaultAuditFile = path.join(defaultAuditDir, 'policy-events.log');

let cachedSnapshot = null;

function stableStringify(value) {
  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(',')}]`;
  }

  if (value && typeof value === 'object') {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(',')}}`;
  }

  return JSON.stringify(value);
}

function sha256(input) {
  return crypto.createHash('sha256').update(String(input || '')).digest('hex');
}

function readFileSafely(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (_error) {
    return '';
  }
}

function getRuntimePolicyVersion() {
  return String(process.env.FK521_POLICY_VERSION || process.env.FK521_SANDBOX_POLICY_VERSION || 'fk521-policy-v1').trim();
}

function buildPolicyState() {
  const projectApisPath = getProjectApiConfigPath();
  const stylesPath = getManagedModelStylesPath();
  const projectApisRaw = readFileSafely(projectApisPath);
  const stylesRaw = readFileSafely(stylesPath);

  return {
    policyVersion: getRuntimePolicyVersion(),
    routerModel: String(process.env.FK521_TOOL_ROUTER_MODEL || 'hybrid').trim() || 'hybrid',
    downloadPolicyVersion: String(process.env.FK521_DOWNLOAD_POLICY_VERSION || 'download-links-v1').trim() || 'download-links-v1',
    projectApisPath,
    stylesPath,
    projectApisHash: sha256(projectApisRaw),
    stylesHash: sha256(stylesRaw),
    projectApisMtimeMs: fs.existsSync(projectApisPath) ? fs.statSync(projectApisPath).mtimeMs : 0,
    stylesMtimeMs: fs.existsSync(stylesPath) ? fs.statSync(stylesPath).mtimeMs : 0,
  };
}

function getRuntimePolicySnapshot() {
  const state = buildPolicyState();
  const payload = {
    policyVersion: state.policyVersion,
    routerModel: state.routerModel,
    downloadPolicyVersion: state.downloadPolicyVersion,
    projectApisHash: state.projectApisHash,
    stylesHash: state.stylesHash,
    projectApisMtimeMs: state.projectApisMtimeMs,
    stylesMtimeMs: state.stylesMtimeMs,
  };
  const snapshotId = sha256(stableStringify(payload)).slice(0, 24);
  cachedSnapshot = {
    ...state,
    snapshotId,
    computedAt: new Date().toISOString(),
  };
  return cachedSnapshot;
}

function getCachedRuntimePolicySnapshot() {
  return cachedSnapshot || getRuntimePolicySnapshot();
}

function getAuditLogPath() {
  const customPath = String(process.env.FK521_POLICY_AUDIT_PATH || '').trim();
  if (customPath) {
    return customPath;
  }
  fs.mkdirSync(defaultAuditDir, { recursive: true });
  return defaultAuditFile;
}


function truncateSummary(value, maxLength = 1200) {
  const text = typeof value === 'string' ? value : stableStringify(value);
  return text.length > maxLength ? `${text.slice(0, maxLength - 1)}…` : text;
}

function readPolicyAuditLog({ conversationId = null, toolName = null, limit = 100 } = {}) {
  try {
    const filePath = getAuditLogPath();
    if (!fs.existsSync(filePath)) {
      return [];
    }

    const raw = fs.readFileSync(filePath, 'utf8');
    const lines = raw.split(/\r?\n/).filter(Boolean);
    const entries = [];

    for (let i = lines.length - 1; i >= 0; i -= 1) {
      try {
        const entry = JSON.parse(lines[i]);
        if (conversationId != null && String(entry.conversationId || '') !== String(conversationId)) {
          continue;
        }
        if (toolName != null && String(entry.toolName || '') !== String(toolName)) {
          continue;
        }
        entries.push({
          ...entry,
          inputSummary: entry.inputSummary != null ? truncateSummary(entry.inputSummary) : undefined,
          resultSummary: entry.resultSummary != null ? truncateSummary(entry.resultSummary) : undefined,
        });
        if (entries.length >= Math.max(1, Number(limit) || 100)) {
          break;
        }
      } catch (_error) {
        continue;
      }
    }

    return entries;
  } catch (error) {
    logger.error('[RuntimePolicy] Failed to read audit log', error);
    return [];
  }
}

function recordPolicyAuditEvent(event = {}) {
  try {
    const filePath = getAuditLogPath();
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const snapshot = getRuntimePolicySnapshot();
    const payload = {
      ts: new Date().toISOString(),
      eventId: crypto.randomUUID(),
      policyVersion: snapshot.policyVersion,
      policySnapshotId: snapshot.snapshotId,
      ...event,
    };
    fs.appendFileSync(filePath, `${JSON.stringify(payload)}\n`, 'utf8');
    return payload;
  } catch (error) {
    logger.error('[RuntimePolicy] Failed to append audit event', error);
    return null;
  }
}

module.exports = {
  getRuntimePolicyVersion,
  getRuntimePolicySnapshot,
  getCachedRuntimePolicySnapshot,
  recordPolicyAuditEvent,
  readPolicyAuditLog,
  stableStringify,
  truncateSummary,
};
