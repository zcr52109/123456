const crypto = require('crypto');
const path = require('path');

function readFirstEnv(keys = [], fallback = '') {
  for (const key of keys) {
    const value = String(process.env[key] || '').trim();
    if (value) {
      return value;
    }
  }
  return fallback;
}

function getPlatformAssistantName() {
  const name = readFirstEnv(['APP_TITLE', 'FK521_MODEL_ID', 'LLM_MODEL_ID', 'MODEL_ID'], 'FK521AI');
  return name || 'FK521AI';
}

function getPlatformVersion() {
  const explicitVersion = readFirstEnv(
    ['APP_VERSION', 'FK521_MODEL_VERSION', 'LLM_MODEL_VERSION', 'MODEL_VERSION'],
    '',
  );
  if (explicitVersion) {
    return explicitVersion;
  }

  try {
    const pkg = require(path.join(__dirname, '../../../../package.json'));
    const version = String(pkg?.version || '').trim();
    return version || 'unknown';
  } catch (_error) {
    return 'unknown';
  }
}

function getBuildDigest() {
  return readFirstEnv(
    ['FK521_BUILD_DIGEST', 'LLM_BUILD_DIGEST', 'BUILD_DIGEST', 'GIT_COMMIT_SHA'],
    'unknown',
  );
}

function getEngineVersion() {
  return readFirstEnv(
    ['FK521_ENGINE_VERSION', 'LLM_ENGINE_VERSION', 'ENGINE_VERSION', 'RUNTIME_ENGINE_VERSION'],
    process.version,
  );
}

function stableStringify(value) {
  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(',')}]`;
  }

  if (value && typeof value === 'object') {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(',')}}`;
  }

  return JSON.stringify(value);
}

function resolveRuntimeIdentityOverrides(context = {}) {
  const req = context.req || {};
  const endpointOption = context.endpointOption || req?.body?.endpointOption || {};
  const agent = context.agent || {};

  const modelId =
    String(
      context.modelId ||
        endpointOption.modelLabel ||
        req?.body?.modelLabel ||
        agent.modelLabel ||
        context.assistantName ||
        '',
    ).trim() || getPlatformAssistantName();

  const modelVersion =
    String(
      context.modelVersion ||
        endpointOption.modelVersion ||
        req?.body?.modelVersion ||
        agent.modelVersion ||
        '',
    ).trim() || getPlatformVersion();

  const buildDigest = String(context.buildDigest || '').trim() || getBuildDigest();
  const engineVersion = String(context.engineVersion || '').trim() || getEngineVersion();

  return {
    modelId,
    modelVersion,
    buildDigest,
    engineVersion,
  };
}

function getModelIdentity(context = {}) {
  const overrides = resolveRuntimeIdentityOverrides(context);
  return {
    modelId: overrides.modelId,
    modelVersion: overrides.modelVersion,
    buildDigest: overrides.buildDigest,
    engineVersion: overrides.engineVersion,
    runtimeSource: context.runtimeSource || 'environment',
    identityOrigin: context.identityOrigin || 'system_truth',
  };
}

function signModelIdentity(identity = getModelIdentity()) {
  const secret = String(
    process.env.FK521_MODEL_IDENTITY_SECRET || process.env.FK521_SANDBOX_CONTRACT_SECRET || 'fk521-model-identity-secret',
  );
  return {
    alg: 'HS256',
    kid: process.env.FK521_MODEL_IDENTITY_KID || 'model-identity-v1',
    sig: crypto.createHmac('sha256', secret).update(stableStringify(identity)).digest('base64url'),
  };
}

function getVerifiedModelIdentity(context = {}) {
  const identity = getModelIdentity(context);
  return {
    ...identity,
    signature: signModelIdentity(identity),
  };
}

function getPlatformIdentityMetadata(context = {}) {
  const assistantName = getPlatformAssistantName();
  const platformVersion = getPlatformVersion();
  const modelIdentity = getVerifiedModelIdentity(context);

  return {
    applicationTitle: assistantName,
    assistantName,
    runtimeOwner: 'platform',
    identityOrigin: 'server_runtime',
    userFacingModelName: modelIdentity.modelId,
    platformVersion,
    providerNamesAreBackendModelIdentifiers: true,
    modelId: modelIdentity.modelId,
    modelVersion: modelIdentity.modelVersion,
    buildDigest: modelIdentity.buildDigest,
    engineVersion: modelIdentity.engineVersion,
    modelIdentity,
  };
}

module.exports = {
  getBuildDigest,
  getEngineVersion,
  getModelIdentity,
  getPlatformAssistantName,
  getPlatformVersion,
  getPlatformIdentityMetadata,
  getVerifiedModelIdentity,
  resolveRuntimeIdentityOverrides,
  signModelIdentity,
  stableStringify,
};
