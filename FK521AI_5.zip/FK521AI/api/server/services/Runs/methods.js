const axios = require('axios');
const { logAxiosError } = require('@fk521ai/api');
const { EModelEndpoint } = require('fk521ai-data-provider');

/**
 * @typedef {Object} RetrieveOptions
 * @property {string} thread_id - The ID of the thread to retrieve.
 * @property {string} run_id - The ID of the run to retrieve.
 * @property {number} [timeout] - Optional timeout for the API call.
 * @property {number} [maxRetries=5] - Optional maximum number of retries for the API call with exponential backoff.
 * @property {OpenAIClient} openai - Configuration and credentials for OpenAI API access.
 */

/**
 * Asynchronously retrieves data from an API endpoint based on provided thread and run IDs.
 * Implements retry logic with exponential backoff for transient failures.
 *
 * @param {RetrieveOptions} options - The options for the retrieve operation.
 * @returns {Promise<Object>} The data retrieved from the API.
 */
async function retrieveRun({ thread_id, run_id, timeout, openai, maxRetries = 5 }) {
  const appConfig = openai.req.config;
  const { apiKey, baseURL, httpAgent, organization } = openai;
  let url = `${baseURL}/threads/${thread_id}/runs/${run_id}`;

  let headers = {
    Authorization: `Bearer ${apiKey}`,
    'OpenAI-Beta': 'assistants=v1',
  };

  if (organization) {
    headers['OpenAI-Organization'] = organization;
  }

  /** @type {TAzureConfig | undefined} */
  const azureConfig = appConfig.endpoints?.[EModelEndpoint.azureOpenAI];

  if (azureConfig && azureConfig.assistants) {
    delete headers.Authorization;
    headers = { ...headers, ...openai._options.defaultHeaders };
    const queryParams = new URLSearchParams(openai._options.defaultQuery).toString();
    url = `${url}?${queryParams}`;
  }

  let lastError;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const axiosConfig = {
        headers: headers,
        timeout: timeout,
      };

      if (httpAgent) {
        axiosConfig.httpAgent = httpAgent;
        axiosConfig.httpsAgent = httpAgent;
      }

      const response = await axios.get(url, axiosConfig);
      return response.data;
    } catch (error) {
      lastError = error;
      // Do not retry on certain errors (e.g., 4xx client errors except 429)
      if (error.response) {
        const status = error.response.status;
        // Retry on 429 (rate limit) and 5xx server errors
        if (status < 500 && status !== 429) {
          throw new Error(logAxiosError({ message: '[retrieveRun] Non-retryable error:', error }));
        }
      }
      // If we have more retries, wait with exponential backoff
      if (attempt < maxRetries - 1) {
        const delay = Math.min(1000 * Math.pow(2, attempt), 30000); // exponential backoff capped at 30s
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  // All retries exhausted
  const message = '[retrieveRun] Failed to retrieve run data after retries:';
  throw new Error(logAxiosError({ message, error: lastError }));
}

module.exports = { retrieveRun };
