const { logger } = require('@fk521ai/data-schemas');
const { tool: toolFn, DynamicStructuredTool } = require('@langchain/core/tools');
const {
  sleep,
  StepTypes,
  GraphEvents,
  createToolSearch,
  Constants: AgentConstants,
} = require('@fk521ai/agents');
const {
  sendEvent,
  getToolkitKey,
  getUserMCPAuthMap,
  loadToolDefinitions,
  GenerationJobManager,
  isActionDomainAllowed,
  buildImageToolContext,
  buildToolClassification,
  buildOAuthToolCallName,
} = require('@fk521ai/api');
const {
  Time,
  Tools,
  Constants,
  CacheKeys,
  ErrorTypes,
  ContentTypes,
  imageGenTools,
  EModelEndpoint,
  EToolResources,
  actionDelimiter,
  ImageVisionTool,
  openapiToFunction,
  AgentCapabilities,
  isEphemeralAgentId,
  validateActionDomain,
  actionDomainSeparator,
  defaultAgentCapabilities,
  validateAndParseOpenAPISpec,
} = require('fk521ai-data-provider');
const {
  createActionTool,
  legacyDomainEncode,
  decryptMetadata,
  loadActionSets,
  domainParser,
} = require('./ActionService');
const {
  getEndpointsConfig,
  getMCPServerTools,
  getCachedTools,
} = require('~/server/services/Config');
const { processFileURL, uploadImageBuffer } = require('~/server/services/Files/process');
const { manifestToolMap, toolkits } = require('~/app/clients/tools/manifest');
const { loadAuthValues } = require('~/server/services/Tools/credentials');
const { reinitMCPServer } = require('~/server/services/Tools/mcp');
const { resolveConfigServers } = require('~/server/services/MCP');
const { recordUsage } = require('~/server/services/Threads');
const { loadTools } = require('~/app/clients/tools/util');
const { createLocalSandboxProgrammaticToolCallingTool } = require('~/app/clients/tools/util/localSandboxTools');
const { WORKSPACE_TOOL_NAMES } = require('~/server/services/Platform/runtimeContext');
const { redactMessage } = require('~/config/parsers');
const { findPluginAuthsByKeys } = require('~/models');
const { getFlowStateManager } = require('~/config');
const { getLogStores } = require('~/cache');

const domainSeparatorRegex = new RegExp(actionDomainSeparator, 'g');
/**
 * Resolves the set of enabled agent capabilities from endpoints config,
 * falling back to app-level or default capabilities for ephemeral agents.
 * @param {ServerRequest} req
 * @param {Object} appConfig
 * @param {string} agentId
 * @returns {Promise<Set<string>>}
 */
async function resolveAgentCapabilities(req, appConfig, agentId) {
  const endpointsConfig = await getEndpointsConfig(req);
  let capabilities = new Set(endpointsConfig?.[EModelEndpoint.agents]?.capabilities ?? []);
  if (capabilities.size === 0 && isEphemeralAgentId(agentId)) {
    capabilities = new Set(
      appConfig.endpoints?.[EModelEndpoint.agents]?.capabilities ?? defaultAgentCapabilities,
    );
  }
  return capabilities;
}

/**
 * Processes the required actions by calling the appropriate tools and returning the outputs.
 * @param {OpenAIClient} client - OpenAI or StreamRunManager Client.
 * @param {RequiredAction} requiredActions - The current required action.
 * @returns {Promise<ToolOutput>} The outputs of the tools.
 */
const processVisionRequest = async (client, currentAction) => {
  if (!client.visionPromise) {
    return {
      tool_call_id: currentAction.toolCallId,
      output: 'No image details found.',
    };
  }

  /** @type {ChatCompletion | undefined} */
  const completion = await client.visionPromise;
  if (completion && completion.usage) {
    recordUsage({
      user: client.req.user.id,
      model: client.req.body.model,
      conversationId: (client.responseMessage ?? client.finalMessage).conversationId,
      ...completion.usage,
    });
  }
  const output = completion?.choices?.[0]?.message?.content ?? 'No image details found.';
  return {
    tool_call_id: currentAction.toolCallId,
    output,
  };
};

/**
 * Processes return required actions from run.
 * @param {OpenAIClient | StreamRunManager} client - OpenAI (legacy) or StreamRunManager Client.
 * @param {RequiredAction[]} requiredActions - The required actions to submit outputs for.
 * @returns {Promise<ToolOutputs>} The outputs of the tools.
 */
async function processRequiredActions(client, requiredActions) {
  logger.debug(
    `[required actions] user: ${client.req.user.id} | thread_id: ${requiredActions[0].thread_id} | run_id: ${requiredActions[0].run_id}`,
    requiredActions,
  );
  const appConfig = client.req.config;
  const toolDefinitions = (await getCachedTools()) ?? {};
  const seenToolkits = new Set();
  const tools = requiredActions
    .map((action) => {
      const toolName = action.tool;
      const toolDef = toolDefinitions[toolName];
      if (toolDef && !manifestToolMap[toolName]) {
        for (const toolkit of toolkits) {
          if (seenToolkits.has(toolkit.pluginKey)) {
            return;
          } else if (toolName.startsWith(`${toolkit.pluginKey}_`)) {
            seenToolkits.add(toolkit.pluginKey);
            return toolkit.pluginKey;
          }
        }
      }
      return toolName;
    })
    .filter((toolName) => !!toolName);

  const { loadedTools } = await loadTools({
    user: client.req.user.id,
    model: client.req.body.model ?? 'gpt-4o-mini',
    tools,
    functions: true,
    endpoint: client.req.body.endpoint,
    options: {
      processFileURL,
      req: client.req,
      uploadImageBuffer,
      openAIApiKey: client.apiKey,
      returnMetadata: true,
    },
    webSearch: appConfig.webSearch,
    fileStrategy: appConfig.fileStrategy,
    imageOutputType: appConfig.imageOutputType,
  });

  const ToolMap = loadedTools.reduce((map, tool) => {
    map[tool.name] = tool;
    return map;
  }, {});

  const promises = [];

  let actionSetsData = null;
  let isActionTool = false;
  const ActionToolMap = {};
  const ActionBuildersMap = {};

  for (let i = 0; i < requiredActions.length; i++) {
    const currentAction = requiredActions[i];
    if (currentAction.tool === ImageVisionTool.function.name) {
      promises.push(processVisionRequest(client, currentAction));
      continue;
    }
    let tool = ToolMap[currentAction.tool] ?? ActionToolMap[currentAction.tool];

    const handleToolOutput = async (output) => {
      requiredActions[i].output = output;

      /** @type {FunctionToolCall & PartMetadata} */
      const toolCall = {
        function: {
          name: currentAction.tool,
          arguments: JSON.stringify(currentAction.toolInput),
          output,
        },
        id: currentAction.toolCallId,
        type: 'function',
        progress: 1,
        action: isActionTool,
      };

      const toolCallIndex = client.mappedOrder.get(toolCall.id);

      if (imageGenTools.has(currentAction.tool)) {
        const imageOutput = output;
        toolCall.function.output = `${currentAction.tool} displayed an image. All generated images are already plainly visible, so don't repeat the descriptions in detail. Do not list download links as they are available in the UI already. The user may download the images by clicking on them, but do not mention anything about downloading to the user.`;

        // Streams the "Finished" state of the tool call in the UI
        client.addContentData({
          [ContentTypes.TOOL_CALL]: toolCall,
          index: toolCallIndex,
          type: ContentTypes.TOOL_CALL,
        });

        await sleep(500);

        /** @type {ImageFile} */
        const imageDetails = {
          ...imageOutput,
          ...currentAction.toolInput,
        };

        const image_file = {
          [ContentTypes.IMAGE_FILE]: imageDetails,
          type: ContentTypes.IMAGE_FILE,
          // Replace the tool call output with Image file
          index: toolCallIndex,
        };

        client.addContentData(image_file);

        // Update the stored tool call
        client.seenToolCalls && client.seenToolCalls.set(toolCall.id, toolCall);

        return {
          tool_call_id: currentAction.toolCallId,
          output: toolCall.function.output,
        };
      }

      client.seenToolCalls && client.seenToolCalls.set(toolCall.id, toolCall);
      client.addContentData({
        [ContentTypes.TOOL_CALL]: toolCall,
        index: toolCallIndex,
        type: ContentTypes.TOOL_CALL,
        result: toolCall.function?.output, // Include tool execution result in stream
      });

      return {
        tool_call_id: currentAction.toolCallId,
        output,
      };
    };

    if (!tool) {
      // throw new Error(`Tool ${currentAction.tool} not found.`);

      if (!actionSetsData) {
        /** @type {Action[]} */
        const actionSets =
          (await loadActionSets({
            assistant_id: client.req.body.assistant_id,
          })) ?? [];

        // Process all action sets once
        // Map domains to their processed action sets
        const processedDomains = new Map();
        const domainLookupMap = new Map();

        for (const action of actionSets) {
          const domain = await domainParser(action.metadata.domain, true);
          domainLookupMap.set(domain, domain);

          const legacyDomain = legacyDomainEncode(action.metadata.domain);
          if (legacyDomain !== domain) {
            domainLookupMap.set(legacyDomain, domain);
          }

          const isDomainAllowed = await isActionDomainAllowed(
            action.metadata.domain,
            appConfig?.actions?.allowedDomains,
          );
          if (!isDomainAllowed) {
            continue;
          }

          // Validate and parse OpenAPI spec
          const validationResult = validateAndParseOpenAPISpec(action.metadata.raw_spec);
          if (!validationResult.spec || !validationResult.serverUrl) {
            throw new Error(
              `Invalid spec: user: ${client.req.user.id} | thread_id: ${requiredActions[0].thread_id} | run_id: ${requiredActions[0].run_id}`,
            );
          }

          // SECURITY: Validate the domain from the spec matches the stored domain
          // This is defense-in-depth to prevent any stored malicious actions
          const domainValidation = validateActionDomain(
            action.metadata.domain,
            validationResult.serverUrl,
          );
          if (!domainValidation.isValid) {
            logger.error(`Domain mismatch in stored action: ${domainValidation.message}`, {
              userId: client.req.user.id,
              action_id: action.action_id,
            });
            continue; // Skip this action rather than failing the entire request
          }

          // Process the OpenAPI spec
          const { requestBuilders } = openapiToFunction(validationResult.spec);

          // Store encrypted values for OAuth flow
          const encrypted = {
            oauth_client_id: action.metadata.oauth_client_id,
            oauth_client_secret: action.metadata.oauth_client_secret,
          };

          // Decrypt metadata
          const decryptedAction = { ...action };
          decryptedAction.metadata = await decryptMetadata(action.metadata);

          processedDomains.set(domain, {
            action: decryptedAction,
            requestBuilders,
            encrypted,
          });

          // Store builders for reuse
          ActionBuildersMap[action.metadata.domain] = requestBuilders;
        }

        actionSetsData = { domainLookupMap, processedDomains };
      }

      let currentDomain = '';
      let matchedKey = '';
      for (const [key, canonical] of actionSetsData.domainLookupMap.entries()) {
        if (currentAction.tool.includes(key)) {
          currentDomain = canonical;
          matchedKey = key;
          break;
        }
      }

      if (!currentDomain || !actionSetsData.processedDomains.has(currentDomain)) {
        continue;
      }

      const { action, requestBuilders, encrypted } =
        actionSetsData.processedDomains.get(currentDomain);
      const functionName = currentAction.tool.replace(`${actionDelimiter}${matchedKey}`, '');
      const requestBuilder = requestBuilders[functionName];

      if (!requestBuilder) {
        // throw new Error(`Tool ${currentAction.tool} not found.`);
        continue;
      }

      // We've already decrypted the metadata, so we can pass it directly
      const _allowedDomains = appConfig?.actions?.allowedDomains;
      tool = await createActionTool({
        userId: client.req.user.id,
        res: client.res,
        action,
        requestBuilder,
        // Note: intentionally not passing zodSchema, name, and description for assistants API
        encrypted, // Pass the encrypted values for OAuth flow
        useSSRFProtection: !Array.isArray(_allowedDomains) || _allowedDomains.length === 0,
      });
      if (!tool) {
        logger.warn(
          `Invalid action: user: ${client.req.user.id} | thread_id: ${requiredActions[0].thread_id} | run_id: ${requiredActions[0].run_id} | toolName: ${currentAction.tool}`,
        );
        throw new Error(`{"type":"${ErrorTypes.INVALID_ACTION}"}`);
      }
      isActionTool = !!tool;
      ActionToolMap[currentAction.tool] = tool;
    }

    if (currentAction.tool === 'calculator') {
      currentAction.toolInput = currentAction.toolInput.input;
    }

    const handleToolError = (error) => {
      logger.error(
        `tool_call_id: ${currentAction.toolCallId} | Error processing tool ${currentAction.tool}`,
        error,
      );
      return {
        tool_call_id: currentAction.toolCallId,
        output: `Error processing tool ${currentAction.tool}: ${redactMessage(error.message, 256)}`,
      };
    };

    try {
      const promise = tool
        ._call(currentAction.toolInput)
        .then(handleToolOutput)
        .catch(handleToolError);
      promises.push(promise);
    } catch (error) {
      const toolOutputError = handleToolError(error);
      promises.push(Promise.resolve(toolOutputError));
    }
  }

  return {
    tool_outputs: await Promise.all(promises),
  };
}

/**
 * Processes the runtime tool calls and returns the tool classes.
 * @param {Object} params - Run params containing user and request information.
 * @param {ServerRequest} params.req - The request object.
 * @param {ServerResponse} params.res - The request object.
 * @param {AbortSignal} params.signal
 * @param {Pick<Agent, 'id' | 'provider' | 'model' | 'tools'} params.agent - The agent to load tools for.
 * @param {string | undefined} [params.openAIApiKey] - The OpenAI API key.
 * @returns {Promise<{
 *   tools?: StructuredTool[];
 *   toolContextMap?: Record<string, unknown>;
 *   userMCPAuthMap?: Record<string, Record<string, string>>;
 *   toolRegistry?: Map<string, import('~/utils/toolClassification').LCTool>;
 *   hasDeferredTools?: boolean;
 * }>} The agent tools and registry.
 */
/** Native FK521AI tools that are not in the manifest */
const nativeTools = new Set([Tools.execute_code, ...WORKSPACE_TOOL_NAMES]);

/** Checks if a tool name is a known built-in tool */
const isBuiltInTool = (toolName) =>
  Boolean(
    manifestToolMap[toolName] ||
      toolkits.some((t) => t.pluginKey === toolName) ||
      nativeTools.has(toolName),
  );

/**
 * Loads only tool definitions without creating tool instances.
 * This is the efficient path for event-driven mode where tools are loaded on-demand.
 *
 * @param {Object} params
 * @param {ServerRequest} params.req - The request object
 * @param {ServerResponse} [params.res] - The response object for SSE events
 * @param {Object} params.agent - The agent configuration
 * @param {string|null} [params.streamId] - Stream ID for resumable mode
 * @returns {Promise<{
 *   toolDefinitions?: import('@fk521ai/api').LCTool[];
 *   toolRegistry?: Map<string, import('@fk521ai/api').LCTool>;
 *   userMCPAuthMap?: Record<string, Record<string, string>>;
 *   hasDeferredTools?: boolean;
 * }>}
 */
async function loadToolDefinitionsWrapper({ req, res, agent, streamId = null, tool_resources }) {
  const configuredTools = Array.isArray(agent.tools) ? agent.tools : [];

  if (
    configuredTools.length === 1 &&
    (configuredTools[0] === AgentCapabilities.context || configuredTools[0] === AgentCapabilities.ocr)
  ) {
    return { toolDefinitions: [] };
  }

  const appConfig = req.config;
  const enabledCapabilities = await resolveAgentCapabilities(req, appConfig, agent.id);

  const checkCapability = (capability) => enabledCapabilities.has(capability);
  const areToolsEnabled = checkCapability(AgentCapabilities.tools);
  const actionsEnabled = checkCapability(AgentCapabilities.actions);
  const deferredToolsEnabled = checkCapability(AgentCapabilities.deferred_tools);

  const filteredTools = configuredTools.filter((tool) => {
    if (tool === Tools.execute_code) {
      return checkCapability(AgentCapabilities.execute_code);
    }
    if (tool.includes(actionDelimiter)) {
      return actionsEnabled;
    }
    if (!areToolsEnabled) {
      return false;
    }
    return true;
  });

  if (areToolsEnabled) {
    filteredTools.push(...WORKSPACE_TOOL_NAMES);
  }

  const uniqueFilteredTools = [...new Set(filteredTools)];

  if (!uniqueFilteredTools || uniqueFilteredTools.length === 0) {
    return { toolDefinitions: [] };
  }

  /** @type {Record<string, Record<string, string>>} */
  let userMCPAuthMap;
  if (configuredTools.some((t) => t.includes(Constants.mcp_delimiter))) {
    userMCPAuthMap = await getUserMCPAuthMap({
      tools: agent.tools,
      userId: req.user.id,
      findPluginAuthsByKeys,
    });
  }

  const flowsCache = getLogStores(CacheKeys.FLOWS);
  const flowManager = getFlowStateManager(flowsCache);
  const configServers = await resolveConfigServers(req);
  const pendingOAuthServers = new Set();

  const createOAuthEmitter = (serverName) => {
    return async (authURL) => {
      const flowId = `${req.user.id}:${serverName}:${Date.now()}`;
      const stepId = 'step_oauth_login_' + serverName;
      const toolCall = {
        id: flowId,
        name: buildOAuthToolCallName(serverName),
        type: 'tool_call_chunk',
      };

      const runStepData = {
        runId: Constants.USE_PRELIM_RESPONSE_MESSAGE_ID,
        id: stepId,
        type: StepTypes.TOOL_CALLS,
        index: 0,
        stepDetails: {
          type: StepTypes.TOOL_CALLS,
          tool_calls: [toolCall],
        },
      };

      const runStepDeltaData = {
        id: stepId,
        delta: {
          type: StepTypes.TOOL_CALLS,
          tool_calls: [{ ...toolCall, args: '' }],
          auth: authURL,
          expires_at: Date.now() + Time.TWO_MINUTES,
        },
      };

      const runStepEvent = { event: GraphEvents.ON_RUN_STEP, data: runStepData };
      const runStepDeltaEvent = { event: GraphEvents.ON_RUN_STEP_DELTA, data: runStepDeltaData };

      if (streamId) {
        await GenerationJobManager.emitChunk(streamId, runStepEvent);
        await GenerationJobManager.emitChunk(streamId, runStepDeltaEvent);
      } else if (res && !res.writableEnded) {
        sendEvent(res, runStepEvent);
        sendEvent(res, runStepDeltaEvent);
      } else {
        logger.warn(
          `[Tool Definitions] Cannot emit OAuth event for ${serverName}: no streamId and res not available`,
        );
      }
    };
  };

  const getOrFetchMCPServerTools = async (userId, serverName) => {
    const cached = await getMCPServerTools(userId, serverName);
    if (cached) {
      return cached;
    }

    const oauthStart = async () => {
      pendingOAuthServers.add(serverName);
    };

    const result = await reinitMCPServer({
      user: req.user,
      oauthStart,
      flowManager,
      serverName,
      configServers,
      userMCPAuthMap,
    });

    return result?.availableTools || null;
  };

  const getActionToolDefinitions = async (agentId, actionToolNames) => {
    const actionSets = (await loadActionSets({ agent_id: agentId })) ?? [];
    if (actionSets.length === 0) {
      return [];
    }

    const definitions = [];
    const allowedDomains = appConfig?.actions?.allowedDomains;
    const normalizedToolNames = new Set(
      actionToolNames.map((n) => n.replace(domainSeparatorRegex, '_')),
    );

    for (const action of actionSets) {
      const domain = await domainParser(action.metadata.domain, true);
      const normalizedDomain = domain.replace(domainSeparatorRegex, '_');

      const legacyDomain = legacyDomainEncode(action.metadata.domain);
      const legacyNormalized = legacyDomain.replace(domainSeparatorRegex, '_');

      const isDomainAllowed = await isActionDomainAllowed(action.metadata.domain, allowedDomains);
      if (!isDomainAllowed) {
        logger.warn(
          `[Actions] Domain "${action.metadata.domain}" not in allowedDomains. ` +
            `Add it to fk521ai.yaml actions.allowedDomains to enable this action.`,
        );
        continue;
      }

      const validationResult = validateAndParseOpenAPISpec(action.metadata.raw_spec);
      if (!validationResult.spec || !validationResult.serverUrl) {
        logger.warn(`[Actions] Invalid OpenAPI spec for domain: ${domain}`);
        continue;
      }

      const { functionSignatures } = openapiToFunction(validationResult.spec, true);

      for (const sig of functionSignatures) {
        const toolName = `${sig.name}${actionDelimiter}${normalizedDomain}`;
        const legacyToolName = `${sig.name}${actionDelimiter}${legacyNormalized}`;
        if (!normalizedToolNames.has(toolName) && !normalizedToolNames.has(legacyToolName)) {
          continue;
        }

        definitions.push({
          name: toolName,
          description: sig.description,
          parameters: sig.parameters,
        });
      }
    }

    return definitions;
  };

  let { toolDefinitions, toolRegistry, hasDeferredTools } = await loadToolDefinitions(
    {
      userId: req.user.id,
      agentId: agent.id,
      tools: uniqueFilteredTools,
      toolOptions: agent.tool_options,
      deferredToolsEnabled,
    },
    {
      isBuiltInTool,
      loadAuthValues,
      getOrFetchMCPServerTools,
      getActionToolDefinitions,
    },
  );

  if (pendingOAuthServers.size > 0 && (res || streamId)) {
    const serverNames = Array.from(pendingOAuthServers);
    logger.info(
      `[Tool Definitions] OAuth required for ${serverNames.length} server(s): ${serverNames.join(', ')}. Emitting events and waiting.`,
    );

    const oauthWaitPromises = serverNames.map(async (serverName) => {
      try {
        const result = await reinitMCPServer({
          user: req.user,
          serverName,
          configServers,
          userMCPAuthMap,
          flowManager,
          returnOnOAuth: false,
          oauthStart: createOAuthEmitter(serverName),
          connectionTimeout: Time.TWO_MINUTES,
        });

        if (result?.availableTools) {
          logger.info(`[Tool Definitions] OAuth completed for ${serverName}, tools available`);
          return { serverName, success: true };
        }
        return { serverName, success: false };
      } catch (error) {
        logger.debug(`[Tool Definitions] OAuth wait failed for ${serverName}:`, error?.message);
        return { serverName, success: false };
      }
    });

    const results = await Promise.allSettled(oauthWaitPromises);
    const successfulServers = results
      .filter((r) => r.status === 'fulfilled' && r.value.success)
      .map((r) => r.value.serverName);

    if (successfulServers.length > 0) {
      logger.info(
        `[Tool Definitions] Reloading tools after OAuth for: ${successfulServers.join(', ')}`,
      );
      const reloadResult = await loadToolDefinitions(
        {
          userId: req.user.id,
          agentId: agent.id,
          tools: uniqueFilteredTools,
          toolOptions: agent.tool_options,
          deferredToolsEnabled,
        },
        {
          isBuiltInTool,
          loadAuthValues,
          getOrFetchMCPServerTools,
          getActionToolDefinitions,
        },
      );
      toolDefinitions = reloadResult.toolDefinitions;
      toolRegistry = reloadResult.toolRegistry;
      hasDeferredTools = reloadResult.hasDeferredTools;
    }
  }

  /** @type {Record<string, string>} */
  const toolContextMap = {};

  const imageFiles = tool_resources?.[EToolResources.image_edit]?.files ?? [];
  if (imageFiles.length > 0) {
    const hasOaiImageGen = filteredTools.includes('image_gen_oai');
    const hasGeminiImageGen = filteredTools.includes('gemini_image_gen');

    if (hasOaiImageGen) {
      const toolContext = buildImageToolContext({
        imageFiles,
        toolName: `${EToolResources.image_edit}_oai`,
        contextDescription: 'image editing',
      });
      if (toolContext) {
        toolContextMap.image_edit_oai = toolContext;
      }
    }

    if (hasGeminiImageGen) {
      const toolContext = buildImageToolContext({
        imageFiles,
        toolName: 'gemini_image_gen',
        contextDescription: 'image context',
      });
      if (toolContext) {
        toolContextMap.gemini_image_gen = toolContext;
      }
    }
  }

  return {
    toolRegistry,
    userMCPAuthMap,
    toolContextMap,
    toolDefinitions,
    hasDeferredTools,
    actionsEnabled,
  };
}

/**
 * Loads agent tools for initialization or execution.
 * @param {Object} params
 * @param {ServerRequest} params.req - The request object
 * @param {ServerResponse} params.res - The response object
 * @param {Object} params.agent - The agent configuration
 * @param {AbortSignal} [params.signal] - Abort signal
 * @param {Object} [params.tool_resources] - Tool resources
 * @param {string} [params.openAIApiKey] - OpenAI API key
 * @param {string|null} [params.streamId] - Stream ID for resumable mode
 * @param {boolean} [params.definitionsOnly=true] - When true, returns only serializable
 *   tool definitions without creating full tool instances. Use for event-driven mode
 *   where tools are loaded on-demand during execution.
 */
async function loadAgentTools({
  req,
  res,
  agent,
  signal,
  tool_resources,
  openAIApiKey,
  streamId = null,
  definitionsOnly = true,
}) {
  if (definitionsOnly) {
    return loadToolDefinitionsWrapper({ req, res, agent, streamId, tool_resources });
  }

  const configuredTools = Array.isArray(agent.tools) ? agent.tools : [];
  if (
    configuredTools.length === 1 &&
    /** Legacy handling for `ocr` as may still exist in existing Agents */
    (configuredTools[0] === AgentCapabilities.context || configuredTools[0] === AgentCapabilities.ocr)
  ) {
    return { toolDefinitions: [] };
  }

  const appConfig = req.config;
  const enabledCapabilities = await resolveAgentCapabilities(req, appConfig, agent.id);
  const checkCapability = (capability) => {
    const enabled = enabledCapabilities.has(capability);
    if (!enabled) {
      const isToolCapability = [
        AgentCapabilities.execute_code,
      ].includes(capability);
      const suffix = isToolCapability ? ' despite configured tool.' : '.';
      logger.warn(
        `Capability "${capability}" disabled${suffix} User: ${req.user.id} | Agent: ${agent.id}`,
      );
    }
    return enabled;
  };
  const areToolsEnabled = checkCapability(AgentCapabilities.tools);
  const actionsEnabled = checkCapability(AgentCapabilities.actions);

  let includesWebSearch = false;
  const _agentTools = configuredTools.filter((tool) => {
    if (tool === Tools.execute_code) {
      return checkCapability(AgentCapabilities.execute_code);
    } else if (tool.includes(actionDelimiter)) {
      return actionsEnabled;
    } else if (!areToolsEnabled) {
      return false;
    }
    return true;
  });

  if (areToolsEnabled) {
    _agentTools.push(...WORKSPACE_TOOL_NAMES);
  }

  const uniqueAgentTools = [...new Set(_agentTools)];

  if (!uniqueAgentTools || uniqueAgentTools.length === 0) {
    return {};
  }

  /** @type {Record<string, Record<string, string>>} */
  let userMCPAuthMap;
  if (configuredTools.some((t) => t.includes(Constants.mcp_delimiter))) {
    userMCPAuthMap = await getUserMCPAuthMap({
      tools: agent.tools,
      userId: req.user.id,
      findPluginAuthsByKeys,
    });
  }

  const { loadedTools, toolContextMap } = await loadTools({
    agent,
    signal,
    userMCPAuthMap,
    functions: true,
    user: req.user.id,
    tools: uniqueAgentTools,
    options: {
      req,
      res,
      openAIApiKey,
      tool_resources,
      processFileURL,
      uploadImageBuffer,
      returnMetadata: true,
    },
    webSearch: appConfig.webSearch,
    fileStrategy: appConfig.fileStrategy,
    imageOutputType: appConfig.imageOutputType,
  });
  /** Build tool registry from MCP tools and create PTC/tool search tools if configured */
  const deferredToolsEnabled = checkCapability(AgentCapabilities.deferred_tools);
  const { toolRegistry, toolDefinitions, additionalTools, hasDeferredTools } =
    await buildToolClassification({
      loadedTools,
      userId: req.user.id,
      agentId: agent.id,
      agentToolOptions: agent.tool_options,
      deferredToolsEnabled,
      loadAuthValues,
    });

  const agentTools = [];
  for (let i = 0; i < loadedTools.length; i++) {
    const tool = loadedTools[i];
    if (tool.name && tool.name === Tools.execute_code) {
      agentTools.push(tool);
      continue;
    }

    if (!areToolsEnabled) {
      continue;
    }

    if (tool.mcp === true) {
      agentTools.push(tool);
      continue;
    }

    if (tool instanceof DynamicStructuredTool) {
      agentTools.push(tool);
      continue;
    }

    const toolDefinition = {
      name: tool.name,
      schema: tool.schema,
      description: tool.description,
    };

    if (imageGenTools.has(tool.name)) {
      toolDefinition.responseFormat = 'content_and_artifact';
    }

    const toolInstance = toolFn(async (...args) => {
      return tool['_call'](...args);
    }, toolDefinition);

    agentTools.push(toolInstance);
  }

  const ToolMap = loadedTools.reduce((map, tool) => {
    map[tool.name] = tool;
    return map;
  }, {});

  agentTools.push(...additionalTools);

  const hasActionTools = uniqueAgentTools.some((t) => t.includes(actionDelimiter));
  if (!hasActionTools) {
    return {
      toolRegistry,
      userMCPAuthMap,
      toolContextMap,
      toolDefinitions,
      hasDeferredTools,
      actionsEnabled,
      tools: agentTools,
    };
  }

  const actionSets = (await loadActionSets({ agent_id: agent.id })) ?? [];
  if (actionSets.length === 0) {
    if (uniqueAgentTools.length > 0 && agentTools.length === 0) {
      logger.warn(`No tools found for the specified tool calls: ${uniqueAgentTools.join(', ')}`);
    }
    return {
      toolRegistry,
      userMCPAuthMap,
      toolContextMap,
      toolDefinitions,
      hasDeferredTools,
      actionsEnabled,
      tools: agentTools,
    };
  }

  const processedActionSets = new Map();
  const domainLookupMap = new Map();

  for (const action of actionSets) {
    const domain = await domainParser(action.metadata.domain, true);
    domainLookupMap.set(domain, domain);

    const legacyDomain = legacyDomainEncode(action.metadata.domain);
    if (legacyDomain !== domain) {
      domainLookupMap.set(legacyDomain, domain);
    }
    const isDomainAllowed = await isActionDomainAllowed(
      action.metadata.domain,
      appConfig?.actions?.allowedDomains,
    );
    if (!isDomainAllowed) {
      continue;
    }

    // Validate and parse OpenAPI spec once per action set
    const validationResult = validateAndParseOpenAPISpec(action.metadata.raw_spec);
    if (!validationResult.spec || !validationResult.serverUrl) {
      continue;
    }

    // SECURITY: Validate the domain from the spec matches the stored domain
    // This is defense-in-depth to prevent any stored malicious actions
    const domainValidation = validateActionDomain(
      action.metadata.domain,
      validationResult.serverUrl,
    );
    if (!domainValidation.isValid) {
      logger.error(`Domain mismatch in stored action: ${domainValidation.message}`, {
        userId: req.user.id,
        agent_id: agent.id,
        action_id: action.action_id,
      });
      continue; // Skip this action rather than failing the entire request
    }

    const encrypted = {
      oauth_client_id: action.metadata.oauth_client_id,
      oauth_client_secret: action.metadata.oauth_client_secret,
    };

    // Decrypt metadata once per action set
    const decryptedAction = { ...action };
    decryptedAction.metadata = await decryptMetadata(action.metadata);

    // Process the OpenAPI spec once per action set
    const { requestBuilders, functionSignatures, zodSchemas } = openapiToFunction(
      validationResult.spec,
      true,
    );

    processedActionSets.set(domain, {
      action: decryptedAction,
      requestBuilders,
      functionSignatures,
      zodSchemas,
      encrypted,
    });
  }

  // Now map tools to the processed action sets
  const ActionToolMap = {};

  for (const toolName of uniqueAgentTools) {
    if (ToolMap[toolName]) {
      continue;
    }

    let currentDomain = '';
    let matchedKey = '';
    for (const [key, canonical] of domainLookupMap.entries()) {
      if (toolName.includes(key)) {
        currentDomain = canonical;
        matchedKey = key;
        break;
      }
    }

    if (!currentDomain || !processedActionSets.has(currentDomain)) {
      continue;
    }

    const { action, encrypted, zodSchemas, requestBuilders, functionSignatures } =
      processedActionSets.get(currentDomain);
    const functionName = toolName.replace(`${actionDelimiter}${matchedKey}`, '');
    const functionSig = functionSignatures.find((sig) => sig.name === functionName);
    const requestBuilder = requestBuilders[functionName];
    const zodSchema = zodSchemas[functionName];

    if (requestBuilder) {
      const _allowedDomains = appConfig?.actions?.allowedDomains;
      const tool = await createActionTool({
        userId: req.user.id,
        res,
        action,
        requestBuilder,
        zodSchema,
        encrypted,
        name: toolName,
        description: functionSig.description,
        streamId,
        useSSRFProtection: !Array.isArray(_allowedDomains) || _allowedDomains.length === 0,
      });

      if (!tool) {
        logger.warn(
          `Invalid action: user: ${req.user.id} | agent_id: ${agent.id} | toolName: ${toolName}`,
        );
        throw new Error(`{"type":"${ErrorTypes.INVALID_ACTION}"}`);
      }

      agentTools.push(tool);
      ActionToolMap[toolName] = tool;
    }
  }

  if (uniqueAgentTools.length > 0 && agentTools.length === 0) {
    logger.warn(`No tools found for the specified tool calls: ${uniqueAgentTools.join(', ')}`);
    return {};
  }

  return {
    toolRegistry,
    toolContextMap,
    userMCPAuthMap,
    toolDefinitions,
    hasDeferredTools,
    actionsEnabled,
    tools: agentTools,
  };
}

/**
 * Loads tools for event-driven execution (ON_TOOL_EXECUTE handler).
 * This function encapsulates all dependencies needed for tool loading,
 * so callers don't need to import processFileURL, uploadImageBuffer, etc.
 *
 * Handles both regular tools (MCP, built-in) and action tools.
 *
 * @param {Object} params
 * @param {ServerRequest} params.req - The request object
 * @param {ServerResponse} params.res - The response object
 * @param {AbortSignal} [params.signal] - Abort signal
 * @param {Object} params.agent - The agent object
 * @param {string[]} params.toolNames - Names of tools to load
 * @param {Map} [params.toolRegistry] - Tool registry
 * @param {Record<string, Record<string, string>>} [params.userMCPAuthMap] - User MCP auth map
 * @param {Object} [params.tool_resources] - Tool resources
 * @param {string|null} [params.streamId] - Stream ID for web search callbacks
 * @param {boolean} [params.actionsEnabled] - Whether the actions capability is enabled
 * @returns {Promise<{ loadedTools: Array, configurable: Object }>}
 */
async function loadToolsForExecution({
  req,
  res,
  signal,
  agent,
  toolNames,
  toolRegistry,
  userMCPAuthMap,
  tool_resources,
  streamId = null,
  actionsEnabled,
}) {
  const appConfig = req.config;
  const allLoadedTools = [];
  const configurable = { userMCPAuthMap };

  if (actionsEnabled === undefined) {
    const enabledCapabilities = await resolveAgentCapabilities(req, appConfig, agent?.id);
    actionsEnabled = enabledCapabilities.has(AgentCapabilities.actions);
  }

  const isToolSearch = toolNames.includes(AgentConstants.TOOL_SEARCH);
  const isPTC = toolNames.includes(AgentConstants.PROGRAMMATIC_TOOL_CALLING);

  logger.debug(
    `[loadToolsForExecution] isToolSearch: ${isToolSearch}, toolRegistry: ${toolRegistry?.size ?? 'undefined'}`,
  );

  if (isToolSearch && toolRegistry) {
    const toolSearchTool = createToolSearch({
      mode: 'local',
      toolRegistry,
    });
    allLoadedTools.push(toolSearchTool);
    configurable.toolRegistry = toolRegistry;
  }

  if (isPTC && toolRegistry) {
    configurable.toolRegistry = toolRegistry;
    try {
      const ptcTool = createLocalSandboxProgrammaticToolCallingTool({ req });
      allLoadedTools.push(ptcTool);
    } catch (error) {
      logger.error('[loadToolsForExecution] Error creating local PTC tool:', error);
    }
  }

  const specialToolNames = new Set([
    AgentConstants.TOOL_SEARCH,
    AgentConstants.PROGRAMMATIC_TOOL_CALLING,
  ]);

  let ptcOrchestratedToolNames = [];
  if (isPTC && toolRegistry) {
    ptcOrchestratedToolNames = Array.from(toolRegistry.values())
      .filter(
        (toolDef) =>
          toolDef?.name &&
          !specialToolNames.has(toolDef.name) &&
          (Array.isArray(toolDef.allowed_callers)
            ? toolDef.allowed_callers.includes('code_execution')
            : false),
      )
      .map((toolDef) => toolDef.name);
  }

  const requestedNonSpecialToolNames = toolNames.filter((name) => !specialToolNames.has(name));
  const allToolNamesToLoad = isPTC
    ? [...new Set([...requestedNonSpecialToolNames, ...ptcOrchestratedToolNames])]
    : requestedNonSpecialToolNames;

  const actionToolNames = allToolNamesToLoad.filter((name) => name.includes(actionDelimiter));
  const regularToolNames = allToolNamesToLoad.filter((name) => !name.includes(actionDelimiter));

  if (regularToolNames.length > 0) {

    const { loadedTools } = await loadTools({
      agent,
      signal,
      userMCPAuthMap,
      functions: true,
      tools: regularToolNames,
      user: req.user.id,
      options: {
        req,
        res,
        tool_resources,
        processFileURL,
        uploadImageBuffer,
        returnMetadata: true,
        },
      webSearch: appConfig?.webSearch,
      fileStrategy: appConfig?.fileStrategy,
      imageOutputType: appConfig?.imageOutputType,
    });

    if (loadedTools) {
      allLoadedTools.push(...loadedTools);
    }
  }

  if (actionToolNames.length > 0 && agent && actionsEnabled) {
    const actionTools = await loadActionToolsForExecution({
      req,
      res,
      agent,
      appConfig,
      streamId,
      actionToolNames,
    });
    allLoadedTools.push(...actionTools);
  } else if (actionToolNames.length > 0 && agent && !actionsEnabled) {
    logger.warn(
      `[loadToolsForExecution] Capability "${AgentCapabilities.actions}" disabled. ` +
        `Skipping action tool execution. User: ${req.user.id} | Agent: ${agent.id} | Tools: ${actionToolNames.join(', ')}`,
    );
  }

  if (isPTC && allLoadedTools.length > 0) {
    const ptcToolMap = new Map();
    for (const tool of allLoadedTools) {
      if (tool.name && tool.name !== AgentConstants.PROGRAMMATIC_TOOL_CALLING) {
        ptcToolMap.set(tool.name, tool);
      }
    }
    configurable.ptcToolMap = ptcToolMap;
  }

  return {
    configurable,
    loadedTools: allLoadedTools,
  };
}

/**
 * Loads action tools for event-driven execution.
 * @param {Object} params
 * @param {ServerRequest} params.req - The request object
 * @param {ServerResponse} params.res - The response object
 * @param {Object} params.agent - The agent object
 * @param {Object} params.appConfig - App configuration
 * @param {string|null} params.streamId - Stream ID
 * @param {string[]} params.actionToolNames - Action tool names to load
 * @returns {Promise<Array>} Loaded action tools
 */
async function loadActionToolsForExecution({
  req,
  res,
  agent,
  appConfig,
  streamId,
  actionToolNames,
}) {
  const loadedActionTools = [];

  const actionSets = (await loadActionSets({ agent_id: agent.id })) ?? [];
  if (actionSets.length === 0) {
    return loadedActionTools;
  }

  const processedActionSets = new Map();
  /** Maps both new and legacy normalized domains to their canonical (new) domain key */
  const normalizedToDomain = new Map();
  const allowedDomains = appConfig?.actions?.allowedDomains;

  for (const action of actionSets) {
    const domain = await domainParser(action.metadata.domain, true);
    const normalizedDomain = domain.replace(domainSeparatorRegex, '_');
    normalizedToDomain.set(normalizedDomain, domain);

    const legacyDomain = legacyDomainEncode(action.metadata.domain);
    const legacyNormalized = legacyDomain.replace(domainSeparatorRegex, '_');
    if (legacyNormalized !== normalizedDomain) {
      normalizedToDomain.set(legacyNormalized, domain);
    }

    const isDomainAllowed = await isActionDomainAllowed(action.metadata.domain, allowedDomains);
    if (!isDomainAllowed) {
      logger.warn(
        `[Actions] Domain "${action.metadata.domain}" not in allowedDomains. ` +
          `Add it to fk521ai.yaml actions.allowedDomains to enable this action.`,
      );
      continue;
    }

    const validationResult = validateAndParseOpenAPISpec(action.metadata.raw_spec);
    if (!validationResult.spec || !validationResult.serverUrl) {
      logger.warn(`[Actions] Invalid OpenAPI spec for domain: ${domain}`);
      continue;
    }

    const domainValidation = validateActionDomain(
      action.metadata.domain,
      validationResult.serverUrl,
    );
    if (!domainValidation.isValid) {
      logger.error(`Domain mismatch in stored action: ${domainValidation.message}`, {
        userId: req.user.id,
        agent_id: agent.id,
        action_id: action.action_id,
      });
      continue;
    }

    const encrypted = {
      oauth_client_id: action.metadata.oauth_client_id,
      oauth_client_secret: action.metadata.oauth_client_secret,
    };

    const decryptedAction = { ...action };
    decryptedAction.metadata = await decryptMetadata(action.metadata);

    const { requestBuilders, functionSignatures, zodSchemas } = openapiToFunction(
      validationResult.spec,
      true,
    );

    processedActionSets.set(domain, {
      action: decryptedAction,
      requestBuilders,
      functionSignatures,
      zodSchemas,
      encrypted,
      legacyNormalized,
    });
  }

  for (const toolName of actionToolNames) {
    let currentDomain = '';
    for (const [normalizedDomain, canonicalDomain] of normalizedToDomain.entries()) {
      if (toolName.includes(normalizedDomain)) {
        currentDomain = canonicalDomain;
        break;
      }
    }

    if (!currentDomain || !processedActionSets.has(currentDomain)) {
      continue;
    }

    const { action, encrypted, zodSchemas, requestBuilders, functionSignatures, legacyNormalized } =
      processedActionSets.get(currentDomain);
    const normalizedDomain = currentDomain.replace(domainSeparatorRegex, '_');
    const functionName = toolName.replace(`${actionDelimiter}${normalizedDomain}`, '');
    const functionSig = functionSignatures.find((sig) => sig.name === functionName);
    const requestBuilder = requestBuilders[functionName];
    const zodSchema = zodSchemas[functionName];

    if (!requestBuilder) {
      const legacyFnName = toolName.replace(`${actionDelimiter}${legacyNormalized}`, '');
      if (legacyFnName !== toolName && requestBuilders[legacyFnName]) {
        const legacyTool = await createActionTool({
          userId: req.user.id,
          res,
          action,
          streamId,
          encrypted,
          requestBuilder: requestBuilders[legacyFnName],
          zodSchema: zodSchemas[legacyFnName],
          name: toolName,
          description:
            functionSignatures.find((sig) => sig.name === legacyFnName)?.description ?? '',
          useSSRFProtection: !Array.isArray(allowedDomains) || allowedDomains.length === 0,
        });
        if (legacyTool) {
          loadedActionTools.push(legacyTool);
        }
      }
      continue;
    }

    const tool = await createActionTool({
      userId: req.user.id,
      res,
      action,
      streamId,
      zodSchema,
      encrypted,
      requestBuilder,
      name: toolName,
      description: functionSig?.description ?? '',
      useSSRFProtection: !Array.isArray(allowedDomains) || allowedDomains.length === 0,
    });

    if (!tool) {
      logger.warn(`[Actions] Failed to create action tool: ${toolName}`);
      continue;
    }

    loadedActionTools.push(tool);
  }

  return loadedActionTools;
}

module.exports = {
  loadTools,
  isBuiltInTool,
  getToolkitKey,
  loadAgentTools,
  loadToolsForExecution,
  processRequiredActions,
  resolveAgentCapabilities,
};
