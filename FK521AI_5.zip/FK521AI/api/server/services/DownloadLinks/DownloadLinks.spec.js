jest.mock('@fk521ai/data-schemas', () => ({
  logger: {
    error: jest.fn(),
    warn: jest.fn(),
    info: jest.fn(),
  },
}));

jest.mock('fk521ai-data-provider', () => ({
  FileSources: {
    local: 'local',
    firebase: 'firebase',
    s3: 's3',
    azure_blob: 'azure_blob',
  },
}));

jest.mock('~/models', () => ({
  getFiles: jest.fn(async () => []),
  getConvo: jest.fn(async () => null),
}));

jest.mock('~/server/utils/files', () => ({
  cleanFileName: jest.fn((value) => String(value || '').replace(/[^a-zA-Z0-9._-]/g, '_')),
}));

jest.mock('~/server/services/Files/strategies', () => ({
  getStrategyFunctions: jest.fn(() => ({ getDownloadStream: undefined })),
}));

jest.mock('~/server/services/Sandbox/paths', () => ({
  resolveConversationFile: jest.fn(),
  classifySandboxRelativePath: jest.fn((relativePath) => {
    const normalizedPath = String(relativePath || '').replace(/^\/+/, '');
    return {
      normalizedPath,
      rootId: normalizedPath.startsWith('outputs/') ? 'outputs' : null,
      downloadAllowed: normalizedPath.startsWith('outputs/'),
    };
  }),
}));

jest.mock('~/server/services/RuntimePolicy', () => ({
  getCachedRuntimePolicySnapshot: jest.fn(() => ({
    policyVersion: 'policy-test',
    snapshotId: 'snapshot-test',
  })),
}));

const fs = require('fs/promises');
const os = require('os');
const path = require('path');
const { resolveConversationFile } = require('~/server/services/Sandbox/paths');
const {
  signPayload,
  verifySignedToken,
  buildAbsoluteDownloadUrl,
  createSandboxDownloadLink,
} = require('./index');

describe('DownloadLinks', () => {
  test('signs and verifies download tokens', () => {
    const payload = {
      kind: 'sandbox',
      conversationId: 'convo-1',
      relativePath: 'outputs/fix.zip',
      exp: Date.now() + 60_000,
      method: 'GET',
      nonce: 'nonce-1',
    };

    const token = signPayload(payload);
    const verified = verifySignedToken(token);

    expect(verified.kind).toBe('sandbox');
    expect(verified.relativePath).toBe('outputs/fix.zip');
  });

  test('rejects expired tokens', () => {
    const payload = {
      kind: 'file',
      file_id: 'file-1',
      exp: Date.now() - 1_000,
      method: 'GET',
      nonce: 'nonce-2',
    };

    const token = signPayload(payload);
    expect(() => verifySignedToken(token)).toThrow(/expired/i);
  });

  test('builds absolute download url from forwarded host', () => {
    const url = buildAbsoluteDownloadUrl(
      {
        headers: {
          'x-forwarded-proto': 'https',
          'x-forwarded-host': 'example.com',
        },
      },
      'abc.token',
    );

    expect(url).toBe('https://example.com/api/downloads/dl?t=abc.token');
  });

  test('allows ephemeral sandbox conversation id for unsigned-new chat downloads', async () => {
    const { assertConversationAccess } = require('./index');

    await expect(
      assertConversationAccess({
        userId: 'user-1',
        tenantId: 'tenant-1',
        conversationId: 'new',
      }),
    ).resolves.toMatchObject({
      conversationId: 'new',
      isEphemeral: true,
      user: 'user-1',
      tenantId: 'tenant-1',
    });
  });

  test('creates sandbox links only for readable existing files', async () => {
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'download-link-'));
    const filePath = path.join(tempDir, 'fix.zip');
    await fs.writeFile(filePath, 'ok', 'utf8');
    resolveConversationFile.mockResolvedValue({
      normalizedPath: 'outputs/fix.zip',
      absolutePath: filePath,
    });

    const link = await createSandboxDownloadLink({
      req: {
        protocol: 'https',
        headers: { host: 'example.com' },
        user: { id: 'user-1' },
      },
      conversationId: 'convo-1',
      relativePath: 'outputs/fix.zip',
      filename: 'fix.zip',
    });

    expect(link.download_url).toContain('/api/downloads/dl?t=');
    const token = new URL(link.download_url).searchParams.get('t');
    const claims = verifySignedToken(token);
    expect(claims.relativePath).toBe('outputs/fix.zip');
  });

  test('refuses sandbox links for missing files', async () => {
    resolveConversationFile.mockResolvedValue({
      normalizedPath: 'outputs/missing.zip',
      absolutePath: path.join(os.tmpdir(), `missing-${Date.now()}.zip`),
    });

    await expect(
      createSandboxDownloadLink({
        req: { protocol: 'https', headers: { host: 'example.com' }, user: { id: 'user-1' } },
        conversationId: 'convo-1',
        relativePath: 'outputs/missing.zip',
        filename: 'missing.zip',
      }),
    ).rejects.toMatchObject({ code: 'FILE_NOT_FOUND' });
  });
});
