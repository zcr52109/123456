const fs = require('fs').promises;
const express = require('express');
const { EnvVar } = require('@fk521ai/agents');
const { logger, SystemCapabilities } = require('@fk521ai/data-schemas');
const {
  refreshS3FileUrls,
  resolveUploadErrorMessage,
  verifyAgentUploadPermission,
} = require('@fk521ai/api');
const {
  Time,
  isUUID,
  CacheKeys,
  FileSources,
  ResourceType,
  EModelEndpoint,
  PermissionBits,
  checkOpenAIStorage,
  isAssistantsEndpoint,
} = require('fk521ai-data-provider');
const {
  filterFile,
  processFileUpload,
  processDeleteRequest,
  processAgentFileUpload,
} = require('~/server/services/Files/process');
const { fileAccess } = require('~/server/middleware/accessResources/fileAccess');
const { getStrategyFunctions } = require('~/server/services/Files/strategies');
const { getOpenAIClient } = require('~/server/controllers/assistants/helpers');
const { hasCapability } = require('~/server/middleware/roles/capabilities');
const { checkPermission } = require('~/server/services/PermissionService');
const { loadAuthValues } = require('~/server/services/Tools/credentials');
const { hasAccessToFilesViaAgent } = require('~/server/services/Files');
const { cleanFileName } = require('~/server/utils/files');
const { buildContentDisposition, getDisplayFilename } = require('@fk521ai/api');
const { getLogStores } = require('~/cache');
const { Readable } = require('stream');
const db = require('~/models');
const { resolveConversationFile } = require('~/server/services/Sandbox/paths');
const { ensureSandboxCapabilityManifest } = require('~/server/services/Sandbox/runtimeContract');
const { respondWithStandardError } = require('~/server/utils/respondWithStandardError');
const { authorizeSandboxAction, SANDBOX_ACTIONS } = require('~/server/services/Sandbox/authorization');
const {
  assertConversationAccess,
  assertFileAccess,
  createFileDownloadLink,
  createSandboxDownloadLink,
} = require('~/server/services/DownloadLinks');

const router = express.Router();

async function cleanupTempUpload(req, reason = 'cleanup') {
  const filePath = req?.file?.path;
  if (!filePath) {
    return;
  }

  try {
    await fs.unlink(filePath);
  } catch (error) {
    if (error?.code !== 'ENOENT') {
      logger.warn(`[/files] Error deleting temp upload during ${reason}:`, error);
    }
  }
}

function resolveUploadStatus(error) {
  const explicitStatus = Number(error?.status || error?.statusCode);
  if (Number.isInteger(explicitStatus) && explicitStatus >= 400 && explicitStatus < 600) {
    return explicitStatus;
  }

  const message = String(error?.message || '');
  if (/limit|too large|file size/i.test(message)) {
    return 413;
  }
  if (/unsupported|not supported|invalid file|no file|no .*provided|empty file/i.test(message)) {
    return 400;
  }
  if (/parse|extract|decode/i.test(message)) {
    return 422;
  }
  return 500;
}

function resolveUploadErrorCode(status) {
  if (status === 413) {
    return 'FILE_SIZE_LIMIT';
  }
  if (status === 422) {
    return 'FILE_PARSE_FAILED';
  }
  if (status >= 400 && status < 500) {
    return 'UPLOAD_VALIDATION_ERROR';
  }
  return 'UPLOAD_PROCESSING_ERROR';
}

router.get('/', async (req, res) => {
  try {
    const appConfig = req.config;
    const files = await db.getFiles({ user: req.user.id });
    if (appConfig.fileStrategy === FileSources.s3) {
      try {
        const cache = getLogStores(CacheKeys.S3_EXPIRY_INTERVAL);
        const alreadyChecked = await cache.get(req.user.id);
        if (!alreadyChecked) {
          await refreshS3FileUrls(files, db.batchUpdateFiles);
          await cache.set(req.user.id, true, Time.THIRTY_MINUTES);
        }
      } catch (error) {
        logger.warn('[/files] Error refreshing S3 file URLs:', error);
      }
    }
    res.status(200).send(files);
  } catch (error) {
    logger.error('[/files] Error getting files:', error);
    res.status(400).json({ message: 'Error in request', error: error.message });
  }
});

/**
 * Get files specific to an agent
 * @route GET /files/agent/:agent_id
 * @param {string} agent_id - The agent ID to get files for
 * @returns {Promise<TFile[]>} Array of files attached to the agent
 */
router.get('/agent/:agent_id', async (req, res) => {
  try {
    const { agent_id } = req.params;
    const userId = req.user.id;

    if (!agent_id) {
      return res.status(400).json({ error: 'Agent ID is required' });
    }

    const agent = await db.getAgent({ id: agent_id });
    if (!agent) {
      return res.status(200).json([]);
    }

    if (agent.author.toString() !== userId) {
      const hasEditPermission = await checkPermission({
        userId,
        role: req.user.role,
        resourceType: ResourceType.AGENT,
        resourceId: agent._id,
        requiredPermission: PermissionBits.EDIT,
      });

      if (!hasEditPermission) {
        return res.status(200).json([]);
      }
    }

    const agentFileIds = [];
    if (agent.tool_resources) {
      for (const [, resource] of Object.entries(agent.tool_resources)) {
        if (resource?.file_ids && Array.isArray(resource.file_ids)) {
          agentFileIds.push(...resource.file_ids);
        }
      }
    }

    if (agentFileIds.length === 0) {
      return res.status(200).json([]);
    }

    const files = await db.getFiles({ file_id: { $in: agentFileIds } }, null, { text: 0 });

    res.status(200).json(files);
  } catch (error) {
    logger.error('[/files/agent/:agent_id] Error fetching agent files:', error);
    res.status(500).json({ error: 'Failed to fetch agent files' });
  }
});

router.get('/config', async (req, res) => {
  try {
    const appConfig = req.config;
    res.status(200).json(appConfig.fileConfig);
  } catch (error) {
    logger.error('[/files] Error getting fileConfig', error);
    res.status(400).json({ message: 'Error in request', error: error.message });
  }
});


router.post('/links', async (req, res) => {
  try {
    const ttlSeconds = Number(req.body?.ttl_seconds || req.body?.ttlSeconds || 0) || undefined;

    if (req.body?.file_id) {
      const file = await assertFileAccess({ userId: req.user.id, fileId: req.body.file_id });
      const link = await createFileDownloadLink({ req, file, ttlSeconds });
      return res.status(200).json(link);
    }

    if (req.body?.conversationId && req.body?.path) {
      await assertConversationAccess({ userId: req.user.id, conversationId: req.body.conversationId });
      const link = await createSandboxDownloadLink({
        req,
        conversationId: req.body.conversationId,
        relativePath: req.body.path,
        filename: req.body.filename,
        ttlSeconds,
      });
      return res.status(200).json(link);
    }

    return respondWithStandardError(res, 400, {
      message: '缺少 file_id 或 conversationId/path',
      error_code: 'DOWNLOAD_LINK_INPUT_REQUIRED',
    });
  } catch (error) {
    if (error?.code === 'FILE_NOT_FOUND' || error?.code === 'CONVERSATION_NOT_FOUND') {
      return respondWithStandardError(res, 404, {
        message: error.message || '资源不存在',
        error_code: error.code,
      });
    }

    if (error?.code === 'FILE_ACCESS_DENIED') {
      return respondWithStandardError(res, 403, {
        message: '无权访问该文件',
        error_code: error.code,
      });
    }

    logger.error('[/files/links] Error creating signed download link:', error);
    return respondWithStandardError(res, 500, {
      message: '生成下载链接失败',
      error_code: 'DOWNLOAD_LINK_CREATE_ERROR',
    });
  }
});
router.get('/sandbox/:conversationId/capabilities', async (req, res) => {
  try {
    const { conversationId } = req.params;

    await assertConversationAccess({
      userId: req.user.id,
      tenantId: req.user.tenantId,
      conversationId,
    });

    const decision = await authorizeSandboxAction({
      user: req.user,
      action: SANDBOX_ACTIONS.READ_CAPABILITIES,
    });

    if (!decision.allow) {
      return respondWithStandardError(res, 403, {
        message: 'Sandbox capabilities are not available for this request',
        error_code: 'PERMISSION_DENIED',
        reason: decision.reasonCode,
        decision_id: decision.decisionId,
        policy_version: decision.policyVersion,
        remediation: decision.remediation,
      });
    }

    const { manifest } = await ensureSandboxCapabilityManifest(conversationId, { user: req.user });
    return res.status(200).json(manifest);
  } catch (error) {
    logger.error('[/files/sandbox/:conversationId/capabilities] Error getting sandbox capabilities:', error);

    if (error?.code === 'CONVERSATION_NOT_FOUND') {
      return respondWithStandardError(res, 404, {
        message: 'Conversation not found',
        error_code: 'CONVERSATION_NOT_FOUND',
      });
    }

    return respondWithStandardError(res, 500, {
      message: 'Error getting sandbox capabilities',
      error_code: 'SANDBOX_CAPABILITIES_ERROR',
    });
  }
});

router.get('/sandbox/:conversationId', async (req, res) => {
  try {
    const { conversationId } = req.params;
    const relativePath = String(req.query.path || '');

    await assertConversationAccess({
      userId: req.user.id,
      tenantId: req.user.tenantId,
      conversationId,
    });

    const decision = await authorizeSandboxAction({
      user: req.user,
      action: SANDBOX_ACTIONS.DOWNLOAD_FILE,
      relativePath,
    });

    if (!decision.allow) {
      return respondWithStandardError(res, 403, {
        message: 'Sandbox file access denied',
        error_code: 'PERMISSION_DENIED',
        reason: decision.reasonCode,
        decision_id: decision.decisionId,
        policy_version: decision.policyVersion,
        remediation: decision.remediation,
        details: decision.resource,
      });
    }

    const resolvedFile = await resolveConversationFile(conversationId, relativePath, { authContext: { user: req.user } });
    await fs.access(resolvedFile.absolutePath);

    const filename = getDisplayFilename(cleanFileName(resolvedFile.normalizedPath.split('/').pop() || 'artifact'), 'artifact');
    res.setHeader('Content-Disposition', buildContentDisposition(filename, 'artifact'));
    res.setHeader('Content-Type', 'application/octet-stream');
    return res.sendFile(resolvedFile.absolutePath);
  } catch (error) {
    logger.error('[/files/sandbox/:conversationId] Error downloading sandbox file:', error);

    if (error?.code === 'SANDBOX_ROOT_NOT_ALLOWED' || error?.code === 'SANDBOX_PATH_TRAVERSAL' || error?.code === 'SANDBOX_SYMLINK_ESCAPE') {
      return respondWithStandardError(res, 403, {
        message: 'Sandbox file access denied',
        error_code: 'PERMISSION_DENIED',
        reason: error.reason || 'ROOT_NOT_ALLOWED',
      });
    }

    if (error?.code === 'CONVERSATION_NOT_FOUND') {
      return respondWithStandardError(res, 404, {
        message: 'Conversation not found',
        error_code: 'CONVERSATION_NOT_FOUND',
      });
    }

    if (error?.code === 'ENOENT') {
      return respondWithStandardError(res, 404, {
        message: 'Sandbox file not found',
        error_code: 'SANDBOX_FILE_NOT_FOUND',
      });
    }

    return respondWithStandardError(res, 500, {
      message: 'Error downloading sandbox file',
      error_code: 'SANDBOX_FILE_DOWNLOAD_ERROR',
    });
  }
});

router.delete('/', async (req, res) => {
  try {
    const { files: _files } = req.body;

    /** @type {MongoFile[]} */
    const files = _files.filter((file) => {
      if (!file.file_id) {
        return false;
      }
      if (!file.filepath) {
        return false;
      }

      if (/^(file|assistant)-/.test(file.file_id)) {
        return true;
      }

      return isUUID.safeParse(file.file_id).success;
    });

    if (files.length === 0) {
      res.status(204).json({ message: 'Nothing provided to delete' });
      return;
    }

    const fileIds = files.map((file) => file.file_id);
    const dbFiles = await db.getFiles({ file_id: { $in: fileIds } });

    const ownedFiles = [];
    const nonOwnedFiles = [];

    for (const file of dbFiles) {
      if (file.user.toString() === req.user.id.toString()) {
        ownedFiles.push(file);
      } else {
        nonOwnedFiles.push(file);
      }
    }

    if (nonOwnedFiles.length === 0) {
      await processDeleteRequest({ req, files: ownedFiles });
      logger.debug(
        `[/files] Files deleted successfully: ${ownedFiles
          .filter((f) => f.file_id)
          .map((f) => f.file_id)
          .join(', ')}`,
      );
      res.status(200).json({ message: 'Files deleted successfully' });
      return;
    }

    let authorizedFiles = [...ownedFiles];
    let unauthorizedFiles = [];

    if (req.body.agent_id && nonOwnedFiles.length > 0) {
      const nonOwnedFileIds = nonOwnedFiles.map((f) => f.file_id);
      const accessMap = await hasAccessToFilesViaAgent({
        userId: req.user.id,
        role: req.user.role,
        fileIds: nonOwnedFileIds,
        agentId: req.body.agent_id,
        isDelete: true,
      });

      for (const file of nonOwnedFiles) {
        if (accessMap.get(file.file_id)) {
          authorizedFiles.push(file);
        } else {
          unauthorizedFiles.push(file);
        }
      }
    } else {
      unauthorizedFiles = nonOwnedFiles;
    }

    if (unauthorizedFiles.length > 0) {
      return res.status(403).json({
        message: 'You can only delete files you have access to',
        unauthorizedFiles: unauthorizedFiles.map((f) => f.file_id),
      });
    }

    /* Handle agent unlinking even if no valid files to delete */
    if (req.body.agent_id && req.body.tool_resource && dbFiles.length === 0) {
      const agent = await db.getAgent({
        id: req.body.agent_id,
      });

      const toolResourceFiles = agent.tool_resources?.[req.body.tool_resource]?.file_ids ?? [];
      const agentFiles = files.filter((f) => toolResourceFiles.includes(f.file_id));

      await processDeleteRequest({ req, files: agentFiles });
      res.status(200).json({ message: 'File associations removed successfully from agent' });
      return;
    }

    /* Handle assistant unlinking even if no valid files to delete */
    if (req.body.assistant_id && req.body.tool_resource && dbFiles.length === 0) {
      const assistant = await db.getAssistant({
        id: req.body.assistant_id,
      });

      const toolResourceFiles = assistant.tool_resources?.[req.body.tool_resource]?.file_ids ?? [];
      const assistantFiles = files.filter((f) => toolResourceFiles.includes(f.file_id));

      await processDeleteRequest({ req, files: assistantFiles });
      res.status(200).json({ message: 'File associations removed successfully from assistant' });
      return;
    } else if (
      req.body.assistant_id &&
      req.body.files?.[0]?.filepath === EModelEndpoint.azureAssistants
    ) {
      await processDeleteRequest({ req, files: req.body.files });
      return res
        .status(200)
        .json({ message: 'File associations removed successfully from Azure Assistant' });
    }

    await processDeleteRequest({ req, files: authorizedFiles });

    logger.debug(
      `[/files] Files deleted successfully: ${authorizedFiles
        .filter((f) => f.file_id)
        .map((f) => f.file_id)
        .join(', ')}`,
    );
    res.status(200).json({ message: 'Files deleted successfully' });
  } catch (error) {
    logger.error('[/files] Error deleting files:', error);
    res.status(400).json({ message: 'Error in request', error: error.message });
  }
});

function isValidCodeDownloadId(str) {
  return typeof str === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(str);
}

router.get('/code/download/:session_id/:fileId', async (req, res) => {
  try {
    const { session_id, fileId } = req.params;
    const logPrefix = `Session ID: ${session_id} | File ID: ${fileId} | Code output download requested by user `;
    logger.debug(logPrefix);

    if (!session_id || !fileId) {
      return res.status(400).send('Bad request');
    }

    if (!isValidCodeDownloadId(session_id) || !isValidCodeDownloadId(fileId)) {
      logger.debug(`${logPrefix} invalid session_id or fileId`);
      return res.status(400).send('Bad request');
    }

    const { getDownloadStream } = getStrategyFunctions(FileSources.execute_code);
    if (!getDownloadStream) {
      logger.warn(
        `${logPrefix} has no stream method implemented for ${FileSources.execute_code} source`,
      );
      return res.status(501).send('Not Implemented');
    }

    const result = await loadAuthValues({ userId: req.user.id, authFields: [EnvVar.CODE_API_KEY] });
    const apiKey = result[EnvVar.CODE_API_KEY];
    if (!apiKey) {
      logger.warn(`${logPrefix} missing ${EnvVar.CODE_API_KEY}`);
      return res.status(503).send('Code execution download is not configured');
    }

    /** @type {AxiosResponse<ReadableStream> | undefined} */
    const response = await getDownloadStream(`${session_id}/${fileId}`, apiKey);
    const filename = getDisplayFilename(
      cleanFileName(String(req.query?.filename || fileId)),
      'download',
    );

    res.setHeader('Content-Disposition', buildContentDisposition(filename, 'download'));
    res.setHeader('Content-Type', response.headers?.['content-type'] || 'application/octet-stream');
    if (response.headers?.['content-length']) {
      res.setHeader('Content-Length', response.headers['content-length']);
    }
    if (response.headers?.etag) {
      res.setHeader('ETag', response.headers.etag);
    }
    if (response.headers?.['last-modified']) {
      res.setHeader('Last-Modified', response.headers['last-modified']);
    }

    response.data.on('error', (streamError) => {
      logger.error('Error streaming code output file:', streamError);
      if (!res.headersSent) {
        res.status(500).send('Error downloading file');
      } else {
        res.destroy(streamError);
      }
    });
    response.data.pipe(res);
  } catch (error) {
    logger.error('Error downloading file:', error);
    res.status(500).send('Error downloading file');
  }
});

router.get('/download/:userId/:file_id', fileAccess, async (req, res) => {
  try {
    const { userId, file_id } = req.params;
    logger.debug(`File download requested by user ${userId}: ${file_id}`);

    // Access already validated by fileAccess middleware
    const file = req.fileAccess.file;

    if (checkOpenAIStorage(file.source) && !file.model) {
      logger.warn(`File download requested by user ${userId} has no associated model: ${file_id}`);
      return res.status(400).send('The model used when creating this file is not available');
    }

    const { getDownloadStream } = getStrategyFunctions(file.source);
    if (!getDownloadStream) {
      logger.warn(
        `File download requested by user ${userId} has no stream method implemented: ${file.source}`,
      );
      return res.status(501).send('Not Implemented');
    }

    const setHeaders = () => {
      const cleanedFilename = getDisplayFilename(cleanFileName(file.filename), 'download');
      res.setHeader('Content-Disposition', buildContentDisposition(cleanedFilename, 'download'));
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('X-File-Metadata', JSON.stringify(file));
    };

    if (checkOpenAIStorage(file.source)) {
      req.body = { model: file.model };
      const endpointMap = {
        [FileSources.openai]: EModelEndpoint.assistants,
        [FileSources.azure]: EModelEndpoint.azureAssistants,
      };
      const { openai } = await getOpenAIClient({
        req,
        res,
        overrideEndpoint: endpointMap[file.source],
      });
      logger.debug(`Downloading file ${file_id} from OpenAI`);
      const passThrough = await getDownloadStream(file_id, openai);
      setHeaders();
      logger.debug(`File ${file_id} downloaded from OpenAI`);

      // Handle both Node.js and Web streams
      const stream =
        passThrough.body && typeof passThrough.body.getReader === 'function'
          ? Readable.fromWeb(passThrough.body)
          : passThrough.body;

      stream.pipe(res);
    } else {
      const fileStream = await getDownloadStream(req, file.filepath);

      fileStream.on('error', (streamError) => {
        logger.error('[DOWNLOAD ROUTE] Stream error:', streamError);
      });

      setHeaders();
      fileStream.pipe(res);
    }
  } catch (error) {
    logger.error('[DOWNLOAD ROUTE] Error downloading file:', error);
    res.status(500).send('Error downloading file');
  }
});

router.post('/', async (req, res) => {
  const metadata = req.body;
  let tempFileCleaned = false;
  const cleanup = async (reason) => {
    if (tempFileCleaned) {
      return;
    }
    tempFileCleaned = true;
    await cleanupTempUpload(req, reason);
  };

  try {
    filterFile({ req });

    metadata.temp_file_id = metadata.file_id;
    metadata.file_id = req.file_id;

    if (isAssistantsEndpoint(metadata.endpoint)) {
      return await processFileUpload({ req, res, metadata });
    }

    let skipUploadAuth = false;
    try {
      skipUploadAuth = await hasCapability(req.user, SystemCapabilities.MANAGE_AGENTS);
    } catch (err) {
      logger.warn(`[/files] capability check failed, denying bypass: ${err.message}`);
    }

    if (!skipUploadAuth) {
      const denied = await verifyAgentUploadPermission({
        req,
        res,
        metadata,
        getAgent: db.getAgent,
        checkPermission,
      });
      if (denied) {
        return;
      }
    }

    return await processAgentFileUpload({ req, res, metadata });
  } catch (error) {
    const message = resolveUploadErrorMessage(error);
    const status = resolveUploadStatus(error);
    logger[status >= 500 ? 'error' : 'warn']('[/files] Error processing file:', error);

    await cleanup('error');
    if (res.headersSent) {
      return;
    }

    return res.status(status).json({
      message,
      error_code: resolveUploadErrorCode(status),
    });
  } finally {
    await cleanup('final');
  }
});

module.exports = router;
