const express = require('express');
const {
  createFileLimiters,
  configMiddleware,
  requireJwtAuth,
  uaParser,
  checkBan,
} = require('~/server/middleware');
const { avatar: asstAvatarRouter } = require('~/server/routes/assistants/v1');
const { avatar: agentAvatarRouter } = require('~/server/routes/agents/v1');
const { createMulterInstance } = require('./multer');

const files = require('./files');
const images = require('./images');
const avatar = require('./avatar');

const initialize = async () => {
  const router = express.Router();
  router.use(requireJwtAuth);
  router.use(configMiddleware);
  router.use(checkBan);
  router.use(uaParser);

  const upload = await createMulterInstance();
  const uploadSingleFile = (routeName) => (req, res, next) => {
    upload.single('file')(req, res, (error) => {
      if (!error) {
        return next();
      }

      const status = error?.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
      return res.status(status).json({
        message: error?.message || 'File upload failed',
        error_code: error?.code || 'UPLOAD_ERROR',
        route: routeName,
      });
    });
  };
  const { fileUploadIpLimiter, fileUploadUserLimiter } = createFileLimiters();

  /** Apply rate limiters to all POST routes */
  router.use((req, res, next) => {
    if (req.method === 'POST') {
      return fileUploadIpLimiter(req, res, (err) => {
        if (err) {
          return next(err);
        }
        return fileUploadUserLimiter(req, res, next);
      });
    }
    next();
  });

  router.post('/', uploadSingleFile('files'));
  router.post('/images', uploadSingleFile('images'));
  router.post('/images/avatar', uploadSingleFile('avatar'));
  router.post('/images/agents/:agent_id/avatar', uploadSingleFile('agent-avatar'));
  router.post('/images/assistants/:assistant_id/avatar', uploadSingleFile('assistant-avatar'));

  router.use('/', files);
  router.use('/images', images);
  router.use('/images/avatar', avatar);
  router.use('/images/agents', agentAvatarRouter);
  router.use('/images/assistants', asstAvatarRouter);
  return router;
};

module.exports = { initialize };
