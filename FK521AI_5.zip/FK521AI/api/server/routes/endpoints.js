const express = require('express');
const requireJwtOrApiKeyAuth = require('~/server/middleware/requireJwtOrApiKeyAuth');
const endpointController = require('~/server/controllers/EndpointController');

const router = express.Router();
/** Auth required for role/tenant-scoped endpoint config resolution. */
router.get('/', requireJwtOrApiKeyAuth, endpointController);

module.exports = router;
