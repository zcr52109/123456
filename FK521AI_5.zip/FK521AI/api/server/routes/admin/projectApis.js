const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const multer = require('multer');
const express = require('express');
const { sanitizeFilename } = require('@fk521ai/api');
const { FileSources } = require('fk521ai-data-provider');
const { SystemCapabilities } = require('@fk521ai/data-schemas');
const { requireCapability } = require('~/server/middleware/roles/capabilities');
const { requireJwtAuth } = require('~/server/middleware');
const difyConsoleRouter = require('./difyConsole');
const { invalidateConfigCaches, getAppConfig } = require('~/server/services/Config');
const { invalidateUIModelCache } = require('~/server/controllers/ModelController');
const { getFileStrategy } = require('~/server/utils/getFileStrategy');
const { getStrategyFunctions } = require('~/server/services/Files/strategies');
const { respondWithStandardError, respondWithInternalError } = require('~/server/utils/respondWithStandardError');
const {
  readProjectApis,
  writeProjectApisFromAdmin,
  getProjectApisRevision,
  ProjectApiConfigError,
  loadManagedCustomEndpoints,
  loadManagedModelSpecs,
  loadManagedFileConfig,
  loadRagEmbeddingConfig,
  resolveProviderBaseURL,
  isMaskedApiKeyValue,
  sanitizeProjectApisForAdmin,
} = require('~/server/utils/projectApiConfig');
const { parseImportFile, mergeImportedProjectApis } = require('~/server/utils/projectApiImport');
const {
  readManagedModelStyles,
  upsertManagedModelStyle,
  removeManagedModelStyle,
} = require('~/server/utils/managedModelStyles');
const { recordPolicyAuditEvent, getCachedRuntimePolicySnapshot } = require('~/server/services/RuntimePolicy');

const router = express.Router();
const requireAdminAccess = requireCapability(SystemCapabilities.ACCESS_ADMIN);
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024,
  },
});

router.use(requireJwtAuth, requireAdminAccess);
router.use((_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

function handleProjectApiConfigError(res, error, fallbackMessage) {
  if (error instanceof ProjectApiConfigError || error?.code?.startsWith?.('PROJECT_APIS_')) {
    const status = error.code === 'PROJECT_APIS_CONFIG_CONFLICT' ? 409 : 500;
    return respondWithStandardError(res, status, {
      message: error.message || fallbackMessage,
      error_code: error.code || 'PROJECT_APIS_CONFIG_ERROR',
    });
  }
  return respondWithInternalError(res, fallbackMessage);
}

router.get('/', (_req, res) => {
  try {
    return res.status(200).json({
      items: sanitizeProjectApisForAdmin(readProjectApis()),
      styles: readManagedModelStyles(),
      revision: getProjectApisRevision(),
    });
  } catch (error) {
    return handleProjectApiConfigError(res, error, '读取项目接口配置失败');
  }
});

router.get('/runtime', (_req, res) => {
  try {
    return res.status(200).json({
      customEndpoints: loadManagedCustomEndpoints(),
      modelSpecs: loadManagedModelSpecs(),
      fileConfig: loadManagedFileConfig(),
      ragEmbedding: loadRagEmbeddingConfig(),
      revision: getProjectApisRevision(),
    });
  } catch (error) {
    return handleProjectApiConfigError(res, error, '读取项目运行时接口配置失败');
  }
});


function normalizeModelNameEntry(entry) {
  if (typeof entry === 'string') {
    const name = entry.trim();
    return name ? { id: name, name, label: name } : null;
  }
  if (!entry || typeof entry !== 'object') {
    return null;
  }
  const id = String(entry.id || entry.name || entry.model || '').trim();
  const name = String(entry.name || entry.id || entry.model || '').trim();
  const label = String(entry.label || entry.display_name || entry.displayName || name || id).trim();
  const finalName = name || id;
  if (!finalName) {
    return null;
  }
  return {
    id: id || finalName,
    name: finalName,
    label: label || finalName,
  };
}

function uniqueModelEntries(entries = []) {
  const seen = new Set();
  const result = [];
  for (const entry of entries) {
    const normalized = normalizeModelNameEntry(entry);
    if (!normalized) {
      continue;
    }
    const key = normalized.name.toLowerCase();
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    result.push(normalized);
  }
  return result.sort((a, b) => a.name.localeCompare(b.name));
}

async function fetchOpenAICompatibleModels({ baseURL, apiKey }) {
  const url = `${String(baseURL || '').replace(/\/+$/, '')}/models`;
  const response = await axios.get(url, {
    timeout: 20000,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      Accept: 'application/json',
    },
    validateStatus: () => true,
  });

  if (response.status >= 400) {
    const providerMessage =
      response.data?.error?.message ||
      response.data?.message ||
      response.data?.error ||
      `HTTP ${response.status}`;
    const error = new Error(String(providerMessage));
    error.status = response.status;
    throw error;
  }

  const payload = response.data;
  const rawModels = Array.isArray(payload?.data)
    ? payload.data
    : Array.isArray(payload?.models)
      ? payload.models
      : Array.isArray(payload)
        ? payload
        : [];
  return uniqueModelEntries(rawModels);
}

router.post('/models/refresh', async (req, res) => {
  try {
    const itemId = String(req.body?.itemId || '').trim();
    const provider = String(req.body?.provider || 'custom').trim();
    const existing = itemId ? readProjectApis().find((item) => String(item.id || '') === itemId) : null;
    const baseURL = resolveProviderBaseURL(provider || existing?.provider || 'custom', req.body?.baseURL || existing?.baseURL || '');
    let apiKey = String(req.body?.apiKey || '').trim();

    if ((!apiKey || isMaskedApiKeyValue(apiKey)) && existing?.apiKey) {
      apiKey = existing.apiKey;
    }

    if (!baseURL) {
      return respondWithStandardError(res, 400, { message: '请先填写 Base URL', error_code: 'BASE_URL_REQUIRED' });
    }
    if (!apiKey || isMaskedApiKeyValue(apiKey)) {
      return respondWithStandardError(res, 400, { message: '请先填写可用的 API Key', error_code: 'API_KEY_REQUIRED' });
    }

    const models = await fetchOpenAICompatibleModels({ baseURL, apiKey });
    return res.status(200).json({ models, count: models.length });
  } catch (error) {
    return respondWithStandardError(res, 502, {
      message: `刷新模型名失败：${error instanceof Error ? error.message : '上游接口不可用'}`,
      error_code: 'MODEL_REFRESH_FAILED',
    });
  }
});

router.put('/', async (req, res) => {
  try {
    const items = Array.isArray(req.body?.items) ? req.body.items : [];
    if (items.length > 100) {
      return respondWithStandardError(res, 400, { message: '项目接口数量不能超过 100 个', error_code: 'TOO_MANY_PROJECT_APIS' });
    }

    const previousSnapshot = getCachedRuntimePolicySnapshot();
    const normalized = writeProjectApisFromAdmin(items, {
      expectedRevision: req.body?.revision,
    });
    invalidateUIModelCache();
    await invalidateConfigCaches(req.user?.tenantId);
    if (typeof difyConsoleRouter.invalidateConsoleStatsCache === 'function') {
      difyConsoleRouter.invalidateConsoleStatsCache(req.user?.tenantId);
    }
    recordPolicyAuditEvent({
      action: 'project_apis_updated',
      userId: req.user?.id,
      tenantId: req.user?.tenantId,
      previousSnapshotId: previousSnapshot?.snapshotId,
      itemCount: normalized.length,
    });

    return res.status(200).json({
      items: sanitizeProjectApisForAdmin(normalized),
      styles: readManagedModelStyles(),
      customEndpoints: loadManagedCustomEndpoints(),
      modelSpecs: loadManagedModelSpecs(),
      fileConfig: loadManagedFileConfig(),
      ragEmbedding: loadRagEmbeddingConfig(),
      revision: getProjectApisRevision(),
    });
  } catch (error) {
    return handleProjectApiConfigError(res, error, '保存项目接口配置失败');
  }
});

router.get('/styles', (_req, res) => {
  return res.status(200).json({ styles: readManagedModelStyles() });
});

router.post('/styles/upload', upload.single('file'), async (req, res) => {
  try {
    const uploaded = req.file;
    if (!uploaded) {
      return respondWithStandardError(res, 400, { message: '请上传 .txt 文件', error_code: 'FILE_REQUIRED' });
    }

    const extension = path.extname(uploaded.originalname || '').toLowerCase();
    const mime = String(uploaded.mimetype || '').toLowerCase();
    const isText = extension === '.txt' || mime.startsWith('text/');
    if (!isText) {
      return respondWithStandardError(res, 400, { message: '仅支持上传 .txt 文本风格文件', error_code: 'INVALID_FILE_TYPE' });
    }

    const content = String(uploaded.buffer?.toString('utf8') || '').replace(/\r\n/g, '\n').trim();
    if (!content) {
      return respondWithStandardError(res, 400, { message: '风格文件内容不能为空', error_code: 'EMPTY_FILE_CONTENT' });
    }

    const style = {
      id: String(req.body?.id || '').trim() || `style-${crypto.randomUUID()}`,
      name: String(req.body?.name || path.basename(uploaded.originalname, extension) || '未命名风格').trim(),
      category: String(req.body?.category || 'general').trim() || 'general',
      description: String(req.body?.description || '').trim(),
      content,
      enabled: req.body?.enabled !== 'false',
      createdAt: new Date().toISOString(),
    };

    const previousSnapshot = getCachedRuntimePolicySnapshot();
    const styles = await upsertManagedModelStyle(style);
    invalidateUIModelCache();
    await invalidateConfigCaches(req.user?.tenantId);
    recordPolicyAuditEvent({
      action: 'managed_model_style_upserted',
      userId: req.user?.id,
      tenantId: req.user?.tenantId,
      styleId: style.id,
      previousSnapshotId: previousSnapshot?.snapshotId,
    });
    return res.status(200).json({
      message: '风格文件已上传',
      styles,
      modelSpecs: loadManagedModelSpecs(),
    });
  } catch (error) {
    return respondWithInternalError(res, '上传风格文件失败');
  }
});

router.delete('/styles/:id', async (req, res) => {
  try {
    const id = String(req.params?.id || '').trim();
    if (!id) {
      return respondWithStandardError(res, 400, { message: '风格文件 ID 不能为空', error_code: 'STYLE_FILE_ID_REQUIRED' });
    }
    const previousSnapshot = getCachedRuntimePolicySnapshot();
    const styles = await removeManagedModelStyle(id);
    invalidateUIModelCache();
    await invalidateConfigCaches(req.user?.tenantId);
    recordPolicyAuditEvent({
      action: 'managed_model_style_deleted',
      userId: req.user?.id,
      tenantId: req.user?.tenantId,
      styleId: id,
      previousSnapshotId: previousSnapshot?.snapshotId,
    });
    return res.status(200).json({
      message: '风格文件已删除',
      styles,
      modelSpecs: loadManagedModelSpecs(),
    });
  } catch (error) {
    return respondWithInternalError(res, '删除风格文件失败');
  }
});


router.post('/batch-import', upload.single('file'), async (req, res) => {
  try {
    const uploaded = req.file;
    if (!uploaded?.buffer?.length) {
      return respondWithStandardError(res, 400, { message: '请上传批量导入文件', error_code: 'IMPORT_FILE_REQUIRED' });
    }

    const rows = parseImportFile({
      buffer: uploaded.buffer,
      filename: uploaded.originalname,
      mimeType: uploaded.mimetype,
    });

    if (!Array.isArray(rows) || rows.length === 0) {
      return respondWithStandardError(res, 400, { message: '未解析到可导入的模型记录', error_code: 'IMPORT_ROWS_EMPTY' });
    }

    const previousSnapshot = getCachedRuntimePolicySnapshot();
    const currentItems = readProjectApis();
    const { items, summary } = mergeImportedProjectApis(currentItems, rows);
    writeProjectApis(items);
    invalidateUIModelCache();
    await invalidateConfigCaches(req.user?.tenantId);
    if (typeof difyConsoleRouter.invalidateConsoleStatsCache === 'function') {
      difyConsoleRouter.invalidateConsoleStatsCache(req.user?.tenantId);
    }
    recordPolicyAuditEvent({
      action: 'project_apis_batch_imported',
      userId: req.user?.id,
      tenantId: req.user?.tenantId,
      previousSnapshotId: previousSnapshot?.snapshotId,
      importedRows: summary.totalRows,
      created: summary.created,
      updated: summary.updated,
    });

    return res.status(200).json({
      message: `导入完成：新增 ${summary.created} 条，更新 ${summary.updated} 条，跳过 ${summary.skipped} 条`,
      summary,
      items: sanitizeProjectApisForAdmin(items),
      styles: readManagedModelStyles(),
      customEndpoints: loadManagedCustomEndpoints(),
      modelSpecs: loadManagedModelSpecs(),
      fileConfig: loadManagedFileConfig(),
      ragEmbedding: loadRagEmbeddingConfig(),
    });
  } catch (error) {
    return respondWithInternalError(res, '批量导入模型失败');
  }
});

router.post('/upload-avatar', upload.single('file'), async (req, res) => {
  try {
    const uploaded = req.file;
    if (!uploaded) {
      return respondWithStandardError(res, 400, { message: '请上传头像图片', error_code: 'AVATAR_FILE_REQUIRED' });
    }

    const mime = String(uploaded.mimetype || '').toLowerCase();
    if (!mime.startsWith('image/')) {
      return respondWithStandardError(res, 400, { message: '仅支持上传图片文件作为模型头像', error_code: 'INVALID_AVATAR_FILE_TYPE' });
    }

    const appConfig = req.config || await getAppConfig({
      role: req.user?.role,
      userId: req.user?.id,
      tenantId: req.user?.tenantId,
    }).catch(() => null);

    let fileStrategy = getFileStrategy(appConfig, { isAvatar: true });
    let strategyFunctions;
    try {
      strategyFunctions = getStrategyFunctions(fileStrategy);
    } catch {
      fileStrategy = FileSources.local;
      strategyFunctions = getStrategyFunctions(FileSources.local);
    }

    let saveBuffer = strategyFunctions?.saveBuffer;
    if (typeof saveBuffer !== 'function') {
      const fallbackFunctions = getStrategyFunctions(FileSources.local);
      saveBuffer = fallbackFunctions?.saveBuffer;
    }
    if (typeof saveBuffer !== 'function') {
      return respondWithInternalError(res, '当前文件存储策略不支持后台头像上传');
    }

    const safeExt = path.extname(sanitizeFilename(uploaded.originalname || 'avatar.png')) || '.png';
    const fileName = `managed-model-${crypto.randomUUID()}${safeExt}`;
    const url = await saveBuffer({
      userId: 'managed-models',
      buffer: uploaded.buffer,
      fileName,
      basePath: 'images',
    });

    return res.status(200).json({ url });
  } catch (error) {
    return respondWithInternalError(res, '上传模型头像失败');
  }
});

module.exports = router;
