const express = require('express');
const { createAdminConfigHandlers } = require('@fk521ai/api');
const { SystemCapabilities } = require('@fk521ai/data-schemas');
const {
  hasConfigCapability,
  requireCapability,
} = require('~/server/middleware/roles/capabilities');
const { getAppConfig, invalidateConfigCaches } = require('~/server/services/Config');
const { requireJwtAuth } = require('~/server/middleware');
const db = require('~/models');

const router = express.Router();

const requireAdminAccess = requireCapability(SystemCapabilities.ACCESS_ADMIN);

// Middleware to validate section-based permissions
const validateSectionPermission = async (req, res, next) => {
  try {
    const { principalType, principalId } = req.params;
    const configSection = req.body?.section || req.query?.section;

    // If a specific section is being accessed, verify the user has permission for that section
    if (configSection && req.user) {
      const hasPermission = await hasConfigCapability({
        user: req.user,
        capability: `config:${configSection}`,
        tenantId: req.user.tenantId,
      });

      if (!hasPermission) {
        return res.status(403).send({
          error: `Insufficient permissions for config section: ${configSection}`,
        });
      }
    }

    next();
  } catch (error) {
    console.error('Error in validateSectionPermission:', error);
    next(error);
  }
};

const handlers = createAdminConfigHandlers({
  listAllConfigs: db.listAllConfigs,
  findConfigByPrincipal: db.findConfigByPrincipal,
  upsertConfig: db.upsertConfig,
  patchConfigFields: db.patchConfigFields,
  unsetConfigField: db.unsetConfigField,
  deleteConfig: db.deleteConfig,
  toggleConfigActive: db.toggleConfigActive,
  hasConfigCapability,
  getAppConfig,
  invalidateConfigCaches,
});

router.use(requireJwtAuth, requireAdminAccess);

// Apply section validation to config mutation routes
router.use('/:principalType/:principalId', validateSectionPermission);

router.get('/', handlers.listConfigs);
router.get('/base', handlers.getBaseConfig);
router.get('/:principalType/:principalId', handlers.getConfig);
router.put('/:principalType/:principalId', handlers.upsertConfigOverrides);
router.patch('/:principalType/:principalId/fields', handlers.patchConfigField);
router.delete('/:principalType/:principalId/fields', handlers.deleteConfigField);
router.delete('/:principalType/:principalId', handlers.deleteConfigOverrides);
router.patch('/:principalType/:principalId/active', handlers.toggleConfig);

module.exports = router;
