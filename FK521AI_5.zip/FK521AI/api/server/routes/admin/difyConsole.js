const bcrypt = require('bcryptjs');
const express = require('express');
const mongoose = require('mongoose');
const { createAdminUsersHandlers } = require('@fk521ai/api');
const { SystemCapabilities } = require('@fk521ai/data-schemas');
const { SystemRoles } = require('fk521ai-data-provider');
const { requireCapability } = require('~/server/middleware/roles/capabilities');
const { requireJwtAuth } = require('~/server/middleware');
const { invalidateConfigCaches } = require('~/server/services/Config');
const { executeLocalCode } = require('~/server/services/Dify/localCodeExecutor');
const { getAppConfig } = require('~/server/services/Config');
const {
  readProjectApis,
  writeProjectApis,
  normalizeProjectApis,
} = require('~/server/utils/projectApiConfig');
const { readSystemSettings, writeSystemSettings } = require('~/server/utils/adminSystemConfig');
const { readDifyConsoleConfig, writeDifyConsoleConfig } = require('~/server/utils/difyConsoleConfig');
const db = require('~/models');
const { respondWithStandardError, respondWithInternalError } = require('~/server/utils/respondWithStandardError');

const router = express.Router();
const requireAdminAccess = requireCapability(SystemCapabilities.ACCESS_ADMIN);
const requireReadUsers = requireCapability(SystemCapabilities.READ_USERS);
const requireManageUsers = requireCapability(SystemCapabilities.MANAGE_USERS);
const handlers = createAdminUsersHandlers({
  findUsers: db.findUsers,
  countUsers: db.countUsers,
  deleteUserById: db.deleteUserById,
  deleteConfig: db.deleteConfig,
  deleteAclEntries: db.deleteAclEntries,
});

const USER_FIELDS = '_id name username email avatar role provider emailVerified createdAt updatedAt';
const STATS_CACHE_TTL_MS = 15000;
const statsCache = new Map();

function isAdminUser(user) {
  return String(user?.role || '').trim().toUpperCase() === SystemRoles.ADMIN;
}

function checkAdminConsoleAccess(req, res, next) {
  if (isAdminUser(req.user)) {
    return next();
  }
  return requireAdminAccess(req, res, next);
}

function checkReadUsers(req, res, next) {
  if (isAdminUser(req.user)) {
    return next();
  }
  return requireReadUsers(req, res, next);
}

function checkManageUsers(req, res, next) {
  if (isAdminUser(req.user)) {
    return next();
  }
  return requireManageUsers(req, res, next);
}

function normalizeRole(role) {
  const normalized = String(role || '').trim().toUpperCase();
  return normalized === SystemRoles.ADMIN ? SystemRoles.ADMIN : SystemRoles.USER;
}

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function normalizeName(name, fallback) {
  const value = String(name || '').trim();
  return value || fallback;
}

function isValidUserId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

async function runAdminHandler(req, res, next, handler, fallbackMessage) {
  try {
    return await Promise.resolve(handler(req, res, next));
  } catch (error) {
    return respondWithInternalError(res, fallbackMessage);
  }
}

async function withSoftTimeout(promise, timeoutMs, fallbackValue) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((resolve) => {
        timer = setTimeout(() => resolve(fallbackValue), timeoutMs);
      }),
    ]);
  } finally {
    if (timer) {
      clearTimeout(timer);
    }
  }
}


function getStatsCacheKey(tenantId) {
  return tenantId ? `tenant:${tenantId}` : 'global';
}

function invalidateConsoleStatsCache(tenantId) {
  const key = getStatsCacheKey(tenantId);
  statsCache.delete(key);
  if (tenantId) {
    statsCache.delete('global');
  }
}

async function getCachedConsoleStats(tenantId) {
  const key = getStatsCacheKey(tenantId);
  const now = Date.now();
  const cachedEntry = statsCache.get(key);

  if (cachedEntry && cachedEntry.expiresAt > now && cachedEntry.value) {
    return cachedEntry.value;
  }

  if (cachedEntry?.promise) {
    return cachedEntry.promise;
  }

  const promise = buildConsoleStats(tenantId)
    .then((value) => {
      statsCache.set(key, {
        value,
        expiresAt: Date.now() + STATS_CACHE_TTL_MS,
      });
      return value;
    })
    .catch((error) => {
      statsCache.delete(key);
      throw error;
    });

  statsCache.set(key, {
    promise,
    expiresAt: now + STATS_CACHE_TTL_MS,
  });

  return promise;
}

async function buildConsoleStats(tenantId) {
  try {
    const consoleConfig = readDifyConsoleConfig();
    const apps = readProjectApis();
    const tools = Array.isArray(consoleConfig.tools) ? consoleConfig.tools : [];
    const userFilter = tenantId ? { tenantId } : {};

    const totalUsersPromise = withSoftTimeout(db.countUsers(userFilter), 3000, 0);

    const onlineUsersPromise = (async () => {
      const Session = mongoose.models.Session;
      if (!Session) {
        return 0;
      }
      const sessionFilter = { expiration: { $gt: new Date() } };
      if (tenantId) {
        sessionFilter.tenantId = tenantId;
      }
      const distinctUsers = await withSoftTimeout(
        Session.distinct('user', sessionFilter).maxTimeMS(2500),
        3000,
        [],
      );
      return Array.isArray(distinctUsers) ? distinctUsers.length : 0;
    })();

    const [totalUsers, onlineUsers] = await Promise.all([totalUsersPromise, onlineUsersPromise]);

    const modelCount = apps.reduce((count, app) => {
      const configuredModels = Array.isArray(app?.modelConfigs) && app.modelConfigs.length > 0
        ? app.modelConfigs.map((model) => String(model?.name || '').trim()).filter(Boolean)
        : Array.isArray(app?.models)
          ? app.models.map((model) => String(model || '').trim()).filter(Boolean)
          : [];

      if (configuredModels.length > 0) {
        return count + configuredModels.length;
      }

      const fallbackModel = String(app?.defaultModel || '').trim();
      return count + (fallbackModel ? 1 : 0);
    }, 0);

    return {
      totalUsers,
      onlineUsers,
      modelCount,
      toolCount: tools.filter((item) => item && item.enabled !== false).length,
    };
  } catch (error) {
    return {
      totalUsers: 0,
      onlineUsers: 0,
      modelCount: 0,
      toolCount: 0,
      statsError: error?.message || 'Failed to build console stats',
    };
  }
}

async function buildWorkspacePayload(user) {
  const consoleConfig = readDifyConsoleConfig();
  const system = readSystemSettings();
  const apps = readProjectApis();
  return {
    workspace: consoleConfig.workspace,
    apps,
    workflows: [],
    tools: Array.isArray(consoleConfig.tools) ? consoleConfig.tools : [],
    system,
    codeExecutor: {},
    stats: await getCachedConsoleStats(user?.tenantId),
    updatedAt: consoleConfig.updatedAt || system.updatedAt || new Date().toISOString(),
  };
}

router.use(requireJwtAuth, checkAdminConsoleAccess);
router.use((_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

router.get('/', (_req, res) => {
  return res.status(200).json({ config: readDifyConsoleConfig() });
});

router.put('/', async (req, res) => {
  try {
    const config = writeDifyConsoleConfig(req.body?.config || {});
    await invalidateConfigCaches(req.user?.tenantId);
    invalidateConsoleStatsCache(req.user?.tenantId);
    return res.status(200).json({ config, message: '已保存' });
  } catch (error) {
    return respondWithInternalError(res, '保存 Dify 工作台配置失败');
  }
});

router.get('/workspace', async (req, res) => {
  try {
    return res.status(200).json(await buildWorkspacePayload(req.user));
  } catch (error) {
    return respondWithInternalError(res, '读取后台工作区失败');
  }
});

router.put('/workspace', async (req, res) => {
  try {
    const payload = req.body && typeof req.body === 'object' ? req.body : {};
    let apps = readProjectApis();
    let system = readSystemSettings();
    if (Array.isArray(payload.apps)) {
      apps = normalizeProjectApis(payload.apps);
      writeProjectApis(apps);
    }
    if (payload.system && typeof payload.system === 'object') {
      system = writeSystemSettings(payload.system);
    }
    const currentConfig = readDifyConsoleConfig();
    const config = writeDifyConsoleConfig({
      ...currentConfig,
      workspace: payload.workspace && typeof payload.workspace === 'object' ? payload.workspace : currentConfig.workspace,
      workflows: [],
      tools: Array.isArray(payload.tools) ? payload.tools : currentConfig.tools,
      codeExecutor: {},
    });
    await invalidateConfigCaches(req.user?.tenantId);
    invalidateConsoleStatsCache(req.user?.tenantId);
    return res.status(200).json({
      workspace: config.workspace,
      apps,
      workflows: [],
      tools: config.tools,
      system,
      codeExecutor: {},
      stats: await getCachedConsoleStats(req.user?.tenantId),
      updatedAt: config.updatedAt,
      message: '已保存',
    });
  } catch (error) {
    return respondWithInternalError(res, '保存失败');
  }
});

router.get('/members', checkReadUsers, (req, res, next) => runAdminHandler(req, res, next, handlers.listUsers, '读取用户列表失败'));
router.get('/members/search', checkReadUsers, (req, res, next) => runAdminHandler(req, res, next, handlers.searchUsers, '搜索用户失败'));

router.post('/members', checkManageUsers, async (req, res) => {
  try {
    const email = normalizeEmail(req.body?.email);
    const password = String(req.body?.password || '');
    const role = normalizeRole(req.body?.role);
    const username = normalizeName(req.body?.username, email.split('@')[0] || `user_${Date.now()}`);
    const name = normalizeName(req.body?.name, username);

    if (!email) {
      return respondWithStandardError(res, 400, { message: '邮箱不能为空', error_code: 'EMAIL_REQUIRED' });
    }

    if (!password || password.length < 6) {
      return respondWithStandardError(res, 400, { message: '密码至少需要 6 位', error_code: 'INVALID_PASSWORD' });
    }

    const existingUser = await db.findUser({ email }, '_id');
    if (existingUser) {
      return respondWithStandardError(res, 409, { message: '该邮箱已存在，不能重复创建', error_code: 'EMAIL_ALREADY_EXISTS' });
    }

    const appConfig = await getAppConfig({ baseOnly: true });
    const salt = bcrypt.genSaltSync(10);
    const created = await db.createUser(
      {
        provider: 'local',
        email,
        username,
        name,
        role,
        emailVerified: req.body?.emailVerified !== false,
        avatar: null,
        password: bcrypt.hashSync(password, salt),
      },
      appConfig?.balance,
      true,
      true,
    );

    const createdUser = created && typeof created === 'object' ? created : null;
    invalidateConsoleStatsCache(req.user?.tenantId);
    return res.status(201).json({
      user: {
        id: createdUser?._id?.toString?.() ?? '',
        name: createdUser?.name ?? name,
        username: createdUser?.username ?? username,
        email: createdUser?.email ?? email,
        avatar: createdUser?.avatar ?? '',
        role: createdUser?.role ?? role,
        provider: createdUser?.provider ?? 'local',
        emailVerified: createdUser?.emailVerified ?? true,
        createdAt: createdUser?.createdAt?.toISOString?.(),
        updatedAt: createdUser?.updatedAt?.toISOString?.(),
      },
      message: '用户创建成功',
    });
  } catch (error) {
    return respondWithInternalError(res, '创建用户失败');
  }
});

router.patch('/members/:id', checkManageUsers, async (req, res) => {
  try {
    const { id } = req.params;
    if (!isValidUserId(id)) {
      return respondWithStandardError(res, 400, { message: '用户 ID 无效', error_code: 'INVALID_USER_ID' });
    }

    const [targetUser] = await db.findUsers({ _id: id }, USER_FIELDS, { limit: 1 });
    if (!targetUser) {
      return respondWithStandardError(res, 404, { message: '用户不存在', error_code: 'USER_NOT_FOUND' });
    }

    const nextRole = req.body?.role !== undefined ? normalizeRole(req.body.role) : undefined;
    if (targetUser.role === SystemRoles.ADMIN && nextRole === SystemRoles.USER) {
      const adminCount = await db.countUsers({ role: SystemRoles.ADMIN });
      if (adminCount <= 1) {
        return respondWithStandardError(res, 400, { message: '不能降级最后一个管理员账号', error_code: 'LAST_ADMIN_PROTECTED' });
      }
    }

    const nextEmail = req.body?.email !== undefined ? normalizeEmail(req.body.email) : undefined;
    if (nextEmail && nextEmail !== targetUser.email) {
      const existingUser = await db.findUser({ email: nextEmail }, '_id email');
      if (existingUser && String(existingUser._id) !== id) {
        return respondWithStandardError(res, 409, { message: '该邮箱已被其他账号使用', error_code: 'EMAIL_ALREADY_IN_USE' });
      }
    }

    const update = {};
    if (req.body?.name !== undefined) {
      update.name = normalizeName(req.body.name, targetUser.name || targetUser.username || '用户');
    }
    if (req.body?.username !== undefined) {
      update.username = normalizeName(req.body.username, targetUser.username || targetUser.email);
    }
    if (nextEmail !== undefined) {
      update.email = nextEmail;
    }
    if (nextRole !== undefined) {
      update.role = nextRole;
    }
    if (req.body?.emailVerified !== undefined) {
      update.emailVerified = req.body.emailVerified === true;
    }

    const updated = await db.updateUser(id, update);
    if (!updated) {
      return respondWithStandardError(res, 404, { message: '用户不存在', error_code: 'USER_NOT_FOUND' });
    }

    invalidateConsoleStatsCache(req.user?.tenantId);
    return res.status(200).json({
      user: {
        id: updated._id?.toString?.() ?? '',
        name: updated.name ?? '',
        username: updated.username ?? '',
        email: updated.email ?? '',
        avatar: updated.avatar ?? '',
        role: updated.role ?? SystemRoles.USER,
        provider: updated.provider ?? 'local',
        emailVerified: updated.emailVerified ?? false,
        createdAt: updated.createdAt?.toISOString?.(),
        updatedAt: updated.updatedAt?.toISOString?.(),
      },
      message: '用户信息已更新',
    });
  } catch (error) {
    return respondWithInternalError(res, '更新用户失败');
  }
});

router.post('/members/:id/reset-password', checkManageUsers, async (req, res) => {
  try {
    const { id } = req.params;
    const password = String(req.body?.password || '');
    if (!isValidUserId(id)) {
      return respondWithStandardError(res, 400, { message: '用户 ID 无效', error_code: 'INVALID_USER_ID' });
    }
    if (!password || password.length < 6) {
      return respondWithStandardError(res, 400, { message: '新密码至少需要 6 位', error_code: 'INVALID_PASSWORD' });
    }

    const [targetUser] = await db.findUsers({ _id: id }, '_id provider', { limit: 1 });
    if (!targetUser) {
      return respondWithStandardError(res, 404, { message: '用户不存在', error_code: 'USER_NOT_FOUND' });
    }

    if (targetUser.provider !== 'local') {
      return respondWithStandardError(res, 400, { message: '仅本地账号支持后台重置密码', error_code: 'PASSWORD_RESET_NOT_SUPPORTED' });
    }

    const salt = bcrypt.genSaltSync(10);
    await db.updateUser(id, {
      password: bcrypt.hashSync(password, salt),
      emailVerified: true,
    });

    invalidateConsoleStatsCache(req.user?.tenantId);
    return res.status(200).json({ message: '密码已重置' });
  } catch (error) {
    return respondWithInternalError(res, '重置密码失败');
  }
});

router.delete('/members/:id', checkManageUsers, async (req, res) => {
  const originalJson = res.json.bind(res);
  res.json = (body) => {
    if (res.statusCode >= 200 && res.statusCode < 300) {
      invalidateConsoleStatsCache(req.user?.tenantId);
    }
    return originalJson(body);
  };
  return runAdminHandler(req, res, null, handlers.deleteUser, '删除用户失败');
});

router.all('/code-executor/run', (_req, res) =>
  res.status(410).json({ message: '代码执行器已下线' }));

router.invalidateConsoleStatsCache = invalidateConsoleStatsCache;
module.exports = router;
