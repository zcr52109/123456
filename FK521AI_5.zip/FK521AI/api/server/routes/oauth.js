const express = require('express');
const passport = require('passport');
const { createSetBalanceConfig, isEnabled } = require('@fk521ai/api');
const { createOAuthHandler } = require('~/server/controllers/auth/oauth');
const { findBalanceByUser, upsertBalanceFields } = require('~/models');
const { getAppConfig } = require('~/server/services/Config');
const middleware = require('~/server/middleware');

const router = express.Router();

const setBalanceConfig = createSetBalanceConfig({
  getAppConfig,
  findBalanceByUser,
  upsertBalanceFields,
});

function failureRedirect(provider) {
  const base = process.env.DOMAIN_CLIENT || '/';
  const separator = base.includes('?') ? '&' : '?';
  return `${base}${base.endsWith('/') ? '' : '/'}login${separator}error=oauth_failed&provider=${encodeURIComponent(provider)}`;
}

function ensureStrategy(strategyName, provider) {
  return (_req, res, next) => {
    if (passport._strategy(strategyName)) {
      return next();
    }

    return res.status(404).json({
      error: `${provider} login is not configured.`,
      error_code: 'OAUTH_PROVIDER_NOT_CONFIGURED',
    });
  };
}

function ensurePublicOAuthEnabled(provider) {
  return async (_req, res, next) => {
    try {
      if (process.env.ALLOW_SOCIAL_LOGIN !== undefined && !isEnabled(process.env.ALLOW_SOCIAL_LOGIN)) {
        return res.status(404).json({
          error: 'Social login is disabled.',
          error_code: 'SOCIAL_LOGIN_DISABLED',
        });
      }

      const appConfig = await getAppConfig({ baseOnly: true });
      const socialLogins = Array.isArray(appConfig?.registration?.socialLogins)
        ? appConfig.registration.socialLogins.map((name) => String(name).trim().toLowerCase())
        : [];

      if (!socialLogins.includes(provider)) {
        return res.status(404).json({
          error: `${provider} login is not enabled.`,
          error_code: 'OAUTH_PROVIDER_NOT_ENABLED',
        });
      }

      return next();
    } catch (error) {
      return next(error);
    }
  };
}

function startOAuth(provider, strategyName, options = {}) {
  return [
    ensureStrategy(strategyName, provider),
    ensurePublicOAuthEnabled(provider),
    (req, res, next) => passport.authenticate(strategyName, { session: false, ...options })(req, res, next),
  ];
}

function finishOAuth(provider, strategyName, options = {}) {
  return [
    ensureStrategy(strategyName, provider),
    ensurePublicOAuthEnabled(provider),
    passport.authenticate(strategyName, {
      failureRedirect: failureRedirect(provider),
      failureMessage: true,
      session: false,
      ...options,
    }),
    setBalanceConfig,
    middleware.checkDomainAllowed,
    createOAuthHandler(process.env.DOMAIN_CLIENT || '/'),
  ];
}

router.get('/openid', startOAuth('openid', 'openid'));
router.get('/openid/callback', finishOAuth('openid', 'openid'));

router.get('/google', startOAuth('google', 'google', { scope: ['openid', 'profile', 'email'] }));
router.get('/google/callback', finishOAuth('google', 'google'));

router.get('/github', startOAuth('github', 'github', { scope: ['user:email', 'read:user'] }));
router.get('/github/callback', finishOAuth('github', 'github'));

router.get('/discord', startOAuth('discord', 'discord', { scope: ['identify', 'email'] }));
router.get('/discord/callback', finishOAuth('discord', 'discord'));

router.get('/facebook', startOAuth('facebook', 'facebook', { scope: ['public_profile', 'email'] }));
router.get('/facebook/callback', finishOAuth('facebook', 'facebook'));

router.get('/apple', startOAuth('apple', 'apple'));
router.post('/apple/callback', finishOAuth('apple', 'apple'));

router.get('/saml', startOAuth('saml', 'saml'));
router.post('/saml/callback', finishOAuth('saml', 'saml'));

module.exports = router;
