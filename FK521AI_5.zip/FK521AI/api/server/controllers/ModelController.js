const { logger } = require('@fk521ai/data-schemas');
const { loadDefaultModels, loadConfigModels } = require('~/server/services/Config');

const UI_MODEL_CACHE_TTL_MS = Number(process.env.FK521_UI_MODEL_CACHE_TTL_MS || 5 * 60 * 1000);
const UI_MODEL_FETCH_TIMEOUT_MS = Number(process.env.FK521_UI_MODEL_FETCH_TIMEOUT_MS || 2500);
const uiModelCache = new Map();

const getModelsConfig = (req) => loadModels(req);

function getUICacheKey(req) {
  return [
    req.user?.tenantId || 'default-tenant',
    req.user?.role || 'guest-role',
    req.user?.id || 'guest-user',
  ].join(':');
}


function invalidateUIModelCache(cacheKey = null) {
  if (!cacheKey) {
    uiModelCache.clear();
    return;
  }

  uiModelCache.delete(cacheKey);
}

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      const timer = setTimeout(() => {
        clearTimeout(timer);
        reject(new Error(`Model fetch timed out after ${ms}ms`));
      }, ms);
    }),
  ]);
}

async function loadModels(req) {
  const defaultModelsConfig = await loadDefaultModels(req);
  const customModelsConfig = await loadConfigModels(req);
  return { ...defaultModelsConfig, ...customModelsConfig };
}

async function refreshUIModels(req, cacheKey) {
  const inFlight = (async () => {
    const defaultModelsPromise = withTimeout(loadDefaultModels(req), UI_MODEL_FETCH_TIMEOUT_MS)
      .catch((error) => {
        logger.warn(`[ModelController] Falling back to empty default model list for ${cacheKey}: ${error.message}`);
        return {};
      });

    const customModelsPromise = withTimeout(loadConfigModels(req), UI_MODEL_FETCH_TIMEOUT_MS)
      .catch((error) => {
        logger.warn(`[ModelController] Falling back to empty custom model list for ${cacheKey}: ${error.message}`);
        return {};
      });

    const [defaultModelsConfig, customModelsConfig] = await Promise.all([
      defaultModelsPromise,
      customModelsPromise,
    ]);

    const merged = { ...defaultModelsConfig, ...customModelsConfig };
    uiModelCache.set(cacheKey, {
      value: merged,
      expiresAt: Date.now() + UI_MODEL_CACHE_TTL_MS,
      inFlight: null,
    });
    return merged;
  })();

  const current = uiModelCache.get(cacheKey) || {};
  uiModelCache.set(cacheKey, {
    value: current.value,
    expiresAt: current.expiresAt || 0,
    inFlight,
  });

  try {
    return await inFlight;
  } finally {
    const latest = uiModelCache.get(cacheKey);
    if (latest?.inFlight === inFlight) {
      uiModelCache.set(cacheKey, {
        value: latest.value,
        expiresAt: latest.expiresAt || 0,
        inFlight: null,
      });
    }
  }
}

async function loadModelsForUI(req) {
  const cacheKey = getUICacheKey(req);
  const cached = uiModelCache.get(cacheKey);
  const now = Date.now();

  if (cached?.value && cached.expiresAt > now) {
    return cached.value;
  }

  if (cached?.value) {
    refreshUIModels(req, cacheKey).catch((error) => {
      logger.warn(`[ModelController] Background UI model refresh failed for ${cacheKey}: ${error.message}`);
    });
    return cached.value;
  }

  if (cached?.inFlight) {
    try {
      return await withTimeout(cached.inFlight, UI_MODEL_FETCH_TIMEOUT_MS);
    } catch (error) {
      logger.warn(`[ModelController] Reusing empty UI model config for ${cacheKey}: ${error.message}`);
      return cached.value || {};
    }
  }

  try {
    return await withTimeout(refreshUIModels(req, cacheKey), UI_MODEL_FETCH_TIMEOUT_MS);
  } catch (error) {
    logger.warn(`[ModelController] Returning empty UI model config for ${cacheKey}: ${error.message}`);
    return uiModelCache.get(cacheKey)?.value || {};
  }
}

async function modelController(req, res) {
  try {
    res.setHeader('Cache-Control', 'no-store');
    const modelConfig = await loadModelsForUI(req);
    res.send(modelConfig);
  } catch (error) {
    logger.error('Error fetching models:', error);
    res.status(500).send({ error: error.message });
  }
}

module.exports = {
  modelController,
  loadModels,
  getModelsConfig,
  getUICacheKey,
  invalidateUIModelCache,
};
