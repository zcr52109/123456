const cookies = require('cookie');
const jwt = require('jsonwebtoken');
const { loadOpenIdClient } = require('~/utils/openidClient');
const { logger } = require('@fk521ai/data-schemas');
const { isEnabled, findOpenIDUser } = require('@fk521ai/api');
const {
  requestPasswordReset,
  setOpenIDAuthTokens,
  resetPassword,
  setAuthTokens,
  registerUser,
} = require('~/server/services/AuthService');
const {
  deleteAllUserSessions,
  getUserById,
  findSession,
  updateUser,
  findUser,
} = require('~/models');
const { getGraphApiToken } = require('~/server/services/GraphTokenService');
const { getOpenIdConfig, getOpenIdEmail } = require('~/strategies');

const DEFAULT_GRAPH_SCOPE_ALLOWLIST = [
  'User.Read',
  'People.Read',
  'Files.Read',
  'Files.Read.All',
  'Sites.Read.All',
  'offline_access',
];

function parseScopeList(value) {
  const raw = Array.isArray(value) ? value.join(' ') : String(value || '');
  return raw
    .split(/[\s,]+/)
    .map((scope) => scope.trim())
    .filter(Boolean);
}

function getAllowedGraphScopes() {
  const configured = [
    process.env.GRAPH_API_ALLOWED_SCOPES,
    process.env.SHAREPOINT_PICKER_GRAPH_SCOPE,
    process.env.SHAREPOINT_PICKER_SHAREPOINT_SCOPE,
  ].flatMap(parseScopeList);

  return new Set(configured.length > 0 ? configured : DEFAULT_GRAPH_SCOPE_ALLOWLIST);
}

function validateGraphScopes(scopes) {
  const requestedScopes = parseScopeList(scopes);
  const allowedScopes = getAllowedGraphScopes();
  const forbiddenScopes = requestedScopes.filter((scope) => !allowedScopes.has(scope));
  return { requestedScopes, forbiddenScopes };
}


const registrationController = async (req, res) => {
  try {
    const response = await registerUser(req.body);
    const {
      status,
      message,
      user: registeredUser,
      requiresLogin = false,
      emailVerificationRequired = false,
    } = response;

    if (status < 200 || status >= 300 || !registeredUser || requiresLogin || emailVerificationRequired) {
      return res.status(status).send({
        message,
        requiresLogin: Boolean(requiresLogin || emailVerificationRequired),
        emailVerificationRequired: Boolean(emailVerificationRequired),
      });
    }

    const userId = registeredUser._id?.toString?.() || registeredUser.id?.toString?.();
    if (!userId) {
      logger.error('[registrationController] Registered user was returned without an id');
      return res.status(500).json({ message: 'Registration succeeded but authentication failed' });
    }

    const token = await setAuthTokens(userId, res);
    const rawUser =
      typeof registeredUser.toObject === 'function'
        ? registeredUser.toObject()
        : { ...registeredUser };
    const { password: _password, __v: _v, totpSecret: _totpSecret, backupCodes: _backupCodes, ...safeUser } = rawUser;
    safeUser.id = userId;

    return res.status(status).send({ message, token, user: safeUser });
  } catch (err) {
    logger.error('[registrationController]', err);
    return res.status(500).json({ message: err.message });
  }
};

const resetPasswordRequestController = async (req, res) => {
  try {
    const resetService = await requestPasswordReset(req);
    if (resetService instanceof Error) {
      return res.status(400).json(resetService);
    } else {
      return res.status(200).json(resetService);
    }
  } catch (e) {
    logger.error('[resetPasswordRequestController]', e);
    return res.status(400).json({ message: e.message });
  }
};

const resetPasswordController = async (req, res) => {
  try {
    const resetPasswordService = await resetPassword(
      req.body.userId,
      req.body.token,
      req.body.password,
    );
    if (resetPasswordService instanceof Error) {
      return res.status(400).json(resetPasswordService);
    } else {
      await deleteAllUserSessions({ userId: req.body.userId });
      return res.status(200).json(resetPasswordService);
    }
  } catch (e) {
    logger.error('[resetPasswordController]', e);
    return res.status(400).json({ message: e.message });
  }
};

const refreshController = async (req, res) => {
  const parsedCookies = req.headers.cookie ? cookies.parse(req.headers.cookie) : {};
  const token_provider = parsedCookies.token_provider;

  if (token_provider === 'openid' && isEnabled(process.env.OPENID_REUSE_TOKENS)) {
    /** For OpenID users, read refresh token from session to avoid large cookie issues */
    const refreshToken = req.session?.openidTokens?.refreshToken || parsedCookies.refreshToken;

    if (!refreshToken) {
      return res.status(401).send('Refresh token not provided');
    }

    try {
      const openIdClient = await loadOpenIdClient();
      const openIdConfig = getOpenIdConfig();
      const refreshParams = process.env.OPENID_SCOPE ? { scope: process.env.OPENID_SCOPE } : {};
      const tokenset = await openIdClient.refreshTokenGrant(
        openIdConfig,
        refreshToken,
        refreshParams,
      );
      const claims = tokenset.claims();
      const { user, error, migration } = await findOpenIDUser({
        findUser,
        email: getOpenIdEmail(claims),
        openidId: claims.sub,
        idOnTheSource: claims.oid,
        strategyName: 'refreshController',
      });

      logger.debug(
        `[refreshController] findOpenIDUser result: user=${user?.email ?? 'null'}, error=${error ?? 'null'}, migration=${migration}, userOpenidId=${user?.openidId ?? 'null'}, claimsSub=${claims.sub}`,
      );

      if (error || !user) {
        logger.warn(
          `[refreshController] Redirecting to /login: error=${error ?? 'null'}, user=${user ? 'exists' : 'null'}`,
        );
        return res.status(401).redirect('/login');
      }

      // Handle migration: update user with openidId if found by email without openidId
      // Also handle case where user has mismatched openidId (e.g., after database switch)
      if (migration || user.openidId !== claims.sub) {
        const reason = migration ? 'migration' : 'openidId mismatch';
        await updateUser(user._id.toString(), {
          provider: 'openid',
          openidId: claims.sub,
        });
        logger.info(
          `[refreshController] Updated user ${user.email} openidId (${reason}): ${user.openidId ?? 'null'} -> ${claims.sub}`,
        );
      }

      const token = setOpenIDAuthTokens(tokenset, req, res, user._id.toString(), refreshToken);

      const { password: _pw, __v: _v, totpSecret: _ts, backupCodes: _bc, ...safeUser } = user;
      return res.status(200).send({ token, user: safeUser });
    } catch (error) {
      logger.error('[refreshController] OpenID token refresh error', error);
      return res.status(403).send('Invalid OpenID refresh token');
    }
  }

  /** For non-OpenID users, read refresh token from cookies */
  const refreshToken = parsedCookies.refreshToken;
  if (!refreshToken) {
    return res.status(401).send('Refresh token not provided');
  }

  try {
    const payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user = await getUserById(payload.id, '-password -__v -totpSecret -backupCodes');
    if (!user) {
      return res.status(401).redirect('/login');
    }

    const userId = payload.id;

    if (process.env.NODE_ENV === 'CI') {
      const token = await setAuthTokens(userId, res);
      return res.status(200).send({ token, user });
    }

    /** Session with the hashed refresh token */
    const session = await findSession(
      {
        userId: userId,
        refreshToken: refreshToken,
      },
      { lean: false },
    );

    if (session && session.expiration > new Date()) {
      const token = await setAuthTokens(userId, res, session);

      res.status(200).send({ token, user });
    } else if (req?.query?.retry) {
      // Retrying from a refresh token request that failed (401)
      res.status(403).send('No session found');
    } else if (payload.exp < Date.now() / 1000) {
      res.status(403).redirect('/login');
    } else {
      res.status(401).send('Refresh token expired or not found for this user');
    }
  } catch (err) {
    logger.error(`[refreshController] Invalid refresh token:`, err);
    res.status(403).send('Invalid refresh token');
  }
};

const graphTokenController = async (req, res) => {
  try {
    // Validate user is authenticated via Entra ID
    if (!req.user.openidId || req.user.provider !== 'openid') {
      return res.status(403).json({
        message: 'Microsoft Graph access requires Entra ID authentication',
      });
    }

    // Check if OpenID token reuse is active (required for on-behalf-of flow)
    if (!isEnabled(process.env.OPENID_REUSE_TOKENS)) {
      return res.status(403).json({
        message: 'SharePoint integration requires OpenID token reuse to be enabled',
      });
    }

    const scopes = req.query.scopes;
    const { requestedScopes, forbiddenScopes } = validateGraphScopes(scopes);
    if (requestedScopes.length === 0) {
      return res.status(400).json({
        message: 'Graph API scopes are required as query parameter',
      });
    }

    if (forbiddenScopes.length > 0) {
      logger.warn('[graphTokenController] Blocked unauthorized Graph scopes', {
        userId: req.user?.id,
        forbiddenScopes,
      });
      return res.status(403).json({
        message: 'One or more requested Graph API scopes are not allowed',
        forbiddenScopes,
      });
    }

    const accessToken = req.user.federatedTokens?.access_token;
    if (!accessToken) {
      return res.status(401).json({
        message: 'No federated access token available for token exchange',
      });
    }

    const tokenResponse = await getGraphApiToken(req.user, accessToken, requestedScopes.join(' '));

    res.json(tokenResponse);
  } catch (error) {
    logger.error('[graphTokenController] Failed to obtain Graph API token:', error);
    res.status(500).json({
      message: 'Failed to obtain Microsoft Graph token',
    });
  }
};

module.exports = {
  refreshController,
  registrationController,
  resetPasswordController,
  resetPasswordRequestController,
  graphTokenController,
};
