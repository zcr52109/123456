const { getEndpointsConfig } = require('~/server/services/Config');

async function endpointController(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  const endpointsConfig = await getEndpointsConfig(req);
  res.send(JSON.stringify(endpointsConfig));
}

module.exports = endpointController;
